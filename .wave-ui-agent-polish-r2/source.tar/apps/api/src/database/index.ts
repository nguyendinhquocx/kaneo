import { config } from "dotenv-mono";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import {
  accountTableRelations,
  activityTableRelations,
  agentPrincipalTableRelations,
  apikeyTableRelations,
  assetTableRelations,
  columnTableRelations,
  commentTableRelations,
  documentCommentTableRelations,
  documentTableRelations,
  executionIdempotencyTableRelations,
  executionManifestTableRelations,
  executionScheduleOccurrenceTableRelations,
  executionScheduleTableRelations,
  externalLinkTableRelations,
  githubIntegrationTableRelations,
  goalCheckinTableRelations,
  goalTableRelations,
  integrationTableRelations,
  invitationTableRelations,
  labelTableRelations,
  notificationTableRelations,
  projectTableRelations,
  sessionTableRelations,
  shareActionAuditTableRelations,
  shareLinkTableRelations,
  taskRelationTableRelations,
  taskRunEvidenceTableRelations,
  taskRunTableRelations,
  taskTableRelations,
  teamMemberTableRelations,
  teamTableRelations,
  timeEntryTableRelations,
  userNotificationPreferenceTableRelations,
  userNotificationWorkspaceProjectTableRelations,
  userNotificationWorkspaceRuleTableRelations,
  userTableRelations,
  verificationTableRelations,
  workflowRuleTableRelations,
  workspaceRoleTableRelations,
  workspaceTableRelations,
  workspaceUserTableRelations,
} from "./relations";
import { resolveDatabaseConnectionString } from "./resolve-database-url";
import {
  accountTable,
  activityTable,
  agentPrincipalTable,
  agentSessionBindingTable,
  agentSessionDeliveryTable,
  agentSessionPresenceTable,
  apikeyTable,
  assetTable,
  columnTable,
  commentTable,
  deviceCodeTable,
  documentCommentTable,
  documentTable,
  executionControlRequestTable,
  executionFlagTable,
  executionIdempotencyTable,
  executionManifestTable,
  executionNotificationDeliveryTable,
  executionNotificationEventTable,
  executionPhaseCardTable,
  executionPhaseProgressTable,
  executionPhaseProjectionTable,
  executionScheduleOccurrenceTable,
  executionScheduleTable,
  externalLinkTable,
  githubIntegrationTable,
  goalCheckinTable,
  goalTable,
  integrationTable,
  invitationTable,
  labelTable,
  notificationTable,
  projectTable,
  sessionTable,
  shareActionAuditTable,
  shareLinkTable,
  taskRelationTable,
  taskRunEvidenceTable,
  taskRunTable,
  taskTable,
  teamMemberTable,
  teamTable,
  timeEntryTable,
  userNotificationPreferenceTable,
  userNotificationWorkspaceProjectTable,
  userNotificationWorkspaceRuleTable,
  userTable,
  verificationTable,
  workflowRuleTable,
  workspaceIntegrationSettingsTable,
  workspaceRoleTable,
  workspaceTable,
  workspaceUserTable,
} from "./schema";

config();

export const schema = {
  executionScheduleOccurrenceTable,
  executionScheduleTable,
  executionControlRequestTable,
  accountTable,
  assetTable,
  activityTable,
  agentPrincipalTable,
  agentSessionBindingTable,
  agentSessionDeliveryTable,
  agentSessionPresenceTable,
  apikeyTable,
  columnTable,
  commentTable,
  deviceCodeTable,
  executionFlagTable,
  executionIdempotencyTable,
  externalLinkTable,
  executionManifestTable,
  executionNotificationDeliveryTable,
  executionNotificationEventTable,
  executionPhaseCardTable,
  executionPhaseProgressTable,
  executionPhaseProjectionTable,
  githubIntegrationTable,
  integrationTable,
  invitationTable,
  labelTable,
  notificationTable,
  projectTable,
  sessionTable,
  taskRelationTable,
  taskRunEvidenceTable,
  taskRunTable,
  taskTable,
  teamMemberTable,
  teamTable,
  timeEntryTable,
  userTable,
  userNotificationPreferenceTable,
  userNotificationWorkspaceProjectTable,
  userNotificationWorkspaceRuleTable,
  verificationTable,
  workflowRuleTable,
  workspaceRoleTable,
  workspaceTable,
  workspaceUserTable,
  workspaceIntegrationSettingsTable,
  documentCommentTable,
  documentTable,
  goalCheckinTable,
  goalTable,
  shareActionAuditTable,
  shareLinkTable,
  executionScheduleOccurrenceTableRelations,
  executionScheduleTableRelations,
  accountTableRelations,
  assetTableRelations,
  activityTableRelations,
  agentPrincipalTableRelations,
  apikeyTableRelations,
  columnTableRelations,
  commentTableRelations,
  executionIdempotencyTableRelations,
  executionManifestTableRelations,
  externalLinkTableRelations,
  githubIntegrationTableRelations,
  integrationTableRelations,
  invitationTableRelations,
  labelTableRelations,
  notificationTableRelations,
  projectTableRelations,
  sessionTableRelations,
  taskRelationTableRelations,
  taskRunEvidenceTableRelations,
  taskRunTableRelations,
  taskTableRelations,
  teamMemberTableRelations,
  teamTableRelations,
  timeEntryTableRelations,
  userTableRelations,
  userNotificationPreferenceTableRelations,
  userNotificationWorkspaceProjectTableRelations,
  userNotificationWorkspaceRuleTableRelations,
  verificationTableRelations,
  workflowRuleTableRelations,
  workspaceRoleTableRelations,
  workspaceTableRelations,
  workspaceUserTableRelations,
  documentCommentTableRelations,
  documentTableRelations,
  goalCheckinTableRelations,
  goalTableRelations,
  shareActionAuditTableRelations,
  shareLinkTableRelations,
};

type DatabaseInstance = ReturnType<typeof drizzle<typeof schema>>;

let pool: Pool | undefined;
let dbInstance: DatabaseInstance | undefined;

export function getDatabasePool(): Pool {
  if (!pool) {
    pool = new Pool({
      connectionString: resolveDatabaseConnectionString(),
      // Fail fast when Railway's internal network is slow rather than hanging
      // indefinitely and blocking every API request.
      connectionTimeoutMillis: 5_000,
      idleTimeoutMillis: 30_000,
      // A board drag fans out into several concurrent task PATCHes plus SSE,
      // websocket and auth traffic; 10 connections exhausted in production
      // (SPEC-2026-11-10 R3: pg-pool "timeout exceeded when trying to
      // connect" 500s). Postgres allows far more than this.
      max: 20,
    });
    pool.on("error", (error) => {
      console.error("Unexpected Postgres pool client error", error);
    });
  }

  return pool;
}

export function getDatabase(): DatabaseInstance {
  if (!dbInstance) {
    dbInstance = drizzle(getDatabasePool(), {
      schema,
    });
  }

  return dbInstance;
}

const db = new Proxy({} as DatabaseInstance, {
  get(_target, property, receiver) {
    const value = Reflect.get(getDatabase(), property, receiver);

    if (typeof value === "function") {
      return value.bind(getDatabase());
    }

    return value;
  },
});

export default db;
