import * as v from "valibot";

export const labelSchema = v.object({
  id: v.string(),
  name: v.string(),
  color: v.string(),
  createdAt: v.date(),
  taskId: v.nullable(v.string()),
  workspaceId: v.nullable(v.string()),
});

const taskMarkerCountSchema = v.pipe(
  v.number(),
  v.integer(),
  v.minValue(0),
  v.maxValue(99),
);

export const taskMarkerCountsSchema = v.object({
  redCross: taskMarkerCountSchema,
  boxedRedCross: taskMarkerCountSchema,
  redCircle: taskMarkerCountSchema,
  greenCheck: taskMarkerCountSchema,
});

export const projectSchema = v.object({
  id: v.string(),
  workspaceId: v.string(),
  slug: v.string(),
  icon: v.nullable(v.string()),
  name: v.string(),
  description: v.nullable(v.string()),
  createdAt: v.date(),
  isPublic: v.nullable(v.boolean()),
  archivedAt: v.nullable(v.date()),
  showSubtaskCardsByDefault: v.boolean(),
  showAssigneesByDefault: v.boolean(),
  showPriorityByDefault: v.boolean(),
});

export const taskSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  position: v.nullable(v.number()),
  number: v.nullable(v.number()),
  userId: v.nullable(v.string()),
  title: v.string(),
  description: v.nullable(v.string()),
  status: v.string(),
  priority: v.picklist([
    "no-priority",
    "low",
    "medium",
    "high",
    "urgent",
  ] as const),
  startDate: v.optional(v.date()),
  dueDate: v.optional(v.date()),
  createdAt: v.date(),
  workMarkerCounts: taskMarkerCountsSchema,
});

export const activitySchema = v.object({
  id: v.string(),
  taskId: v.string(),
  type: v.picklist([
    "comment",
    "task",
    "status_changed",
    "priority_changed",
    "unassigned",
    "assignee_changed",
    "due_date_changed",
    "title_changed",
    "description_changed",
    "create",
  ] as const),
  createdAt: v.date(),
  userId: v.nullable(v.string()),
  content: v.nullable(v.string()),
  eventData: v.nullable(v.record(v.string(), v.unknown())),
  externalUserName: v.nullable(v.string()),
  externalUserAvatar: v.nullable(v.string()),
  externalSource: v.nullable(v.string()),
  externalUrl: v.nullable(v.string()),
});

export const timeEntrySchema = v.object({
  id: v.string(),
  taskId: v.string(),
  userId: v.nullable(v.string()),
  description: v.nullable(v.string()),
  startTime: v.date(),
  endTime: v.optional(v.date()),
  duration: v.nullable(v.number()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const notificationSchema = v.object({
  id: v.string(),
  userId: v.string(),
  title: v.nullable(v.string()),
  content: v.nullable(v.string()),
  type: v.picklist([
    "info",
    "task_created",
    "workspace_created",
    "task_status_changed",
    "task_assignee_changed",
    "time_entry_created",
    "due_date_reminder",
    "task_overdue",
    "task_mention",
    "task_comment",
  ] as const),
  eventData: v.nullable(v.record(v.string(), v.unknown())),
  isRead: v.optional(v.boolean()),
  resourceId: v.optional(v.string()),
  resourceType: v.optional(v.picklist(["task", "workspace"] as const)),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const notificationPreferenceWorkspaceRuleSchema = v.object({
  id: v.string(),
  workspaceId: v.string(),
  workspaceName: v.string(),
  isActive: v.boolean(),
  emailEnabled: v.boolean(),
  ntfyEnabled: v.boolean(),
  gotifyEnabled: v.boolean(),
  webhookEnabled: v.boolean(),
  projectMode: v.picklist(["all", "selected"] as const),
  selectedProjectIds: v.array(v.string()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const notificationPreferenceSchema = v.object({
  emailAddress: v.nullable(v.string()),
  emailEnabled: v.boolean(),
  ntfyEnabled: v.boolean(),
  ntfyConfigured: v.boolean(),
  ntfyServerUrl: v.nullable(v.string()),
  ntfyTopic: v.nullable(v.string()),
  ntfyTokenConfigured: v.boolean(),
  maskedNtfyToken: v.nullable(v.string()),
  gotifyEnabled: v.boolean(),
  gotifyConfigured: v.boolean(),
  gotifyServerUrl: v.nullable(v.string()),
  gotifyTokenConfigured: v.boolean(),
  maskedGotifyToken: v.nullable(v.string()),
  webhookEnabled: v.boolean(),
  webhookConfigured: v.boolean(),
  webhookUrl: v.nullable(v.string()),
  webhookSecretConfigured: v.boolean(),
  maskedWebhookSecret: v.nullable(v.string()),
  taskAssignmentEnabled: v.boolean(),
  taskCommentEnabled: v.boolean(),
  taskStatusChangeEnabled: v.boolean(),
  dueDateReminderEnabled: v.boolean(),
  dueDateReminderLeadTimeMinutes: v.number(),
  workspaces: v.array(notificationPreferenceWorkspaceRuleSchema),
  createdAt: v.nullable(v.date()),
  updatedAt: v.nullable(v.date()),
});

export const githubIntegrationSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  repositoryOwner: v.string(),
  repositoryName: v.string(),
  installationId: v.nullable(v.number()),
  branchPattern: v.optional(v.string()),
  commentTaskLinkOnGitHubIssue: v.optional(v.boolean()),
  isActive: v.nullable(v.boolean()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const giteaIntegrationSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  baseUrl: v.string(),
  repositoryOwner: v.string(),
  repositoryName: v.string(),
  maskedAccessToken: v.string(),
  webhookUrl: v.optional(v.string()),
  webhookSecret: v.optional(v.string()),
  branchPattern: v.optional(v.string()),
  commentTaskLinkOnGiteaIssue: v.optional(v.boolean()),
  isActive: v.nullable(v.boolean()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const integrationEventsSchema = v.object({
  taskCreated: v.boolean(),
  taskStatusChanged: v.boolean(),
  taskPriorityChanged: v.boolean(),
  taskTitleChanged: v.boolean(),
  taskDescriptionChanged: v.boolean(),
  taskCommentCreated: v.boolean(),
});

export const slackIntegrationSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  channelName: v.nullable(v.string()),
  webhookConfigured: v.boolean(),
  maskedWebhookUrl: v.string(),
  events: integrationEventsSchema,
  isActive: v.nullable(v.boolean()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const discordIntegrationSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  channelName: v.nullable(v.string()),
  webhookConfigured: v.boolean(),
  maskedWebhookUrl: v.string(),
  events: integrationEventsSchema,
  isActive: v.nullable(v.boolean()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const genericWebhookIntegrationSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  webhookConfigured: v.boolean(),
  maskedWebhookUrl: v.nullable(v.string()),
  secretConfigured: v.boolean(),
  maskedSecret: v.nullable(v.string()),
  events: v.object({
    ...integrationEventsSchema.entries,
    taskDeleted: v.boolean(),
    taskMoved: v.boolean(),
    taskDueDateChanged: v.boolean(),
    taskAssigneeChanged: v.boolean(),
    taskUnassigned: v.boolean(),
    dueDateReminder: v.boolean(),
  }),
  dueDateReminderLeadTimeMinutes: v.number(),
  isActive: v.nullable(v.boolean()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const telegramIntegrationSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  chatId: v.string(),
  threadId: v.nullable(v.number()),
  chatLabel: v.nullable(v.string()),
  botTokenConfigured: v.boolean(),
  maskedBotToken: v.string(),
  events: v.object({
    ...integrationEventsSchema.entries,
    executionRunUpdated: v.boolean(),
  }),
  isActive: v.nullable(v.boolean()),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const commentSchema = v.object({
  id: v.string(),
  taskId: v.string(),
  userId: v.string(),
  content: v.string(),
  createdAt: v.date(),
  updatedAt: v.date(),
  user: v.optional(
    v.object({
      name: v.string(),
      image: v.nullable(v.string()),
    }),
  ),
});

export const agentPrincipalSchema = v.object({
  id: v.string(),
  userId: v.string(),
  runtimeId: v.string(),
  hostId: v.string(),
  scopes: v.array(v.string()),
  isActive: v.boolean(),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const executionManifestSchema = v.object({
  id: v.string(),
  projectId: v.string(),
  repositoryOwner: v.string(),
  repositoryName: v.string(),
  baseBranch: v.string(),
  docs: v.array(v.string()),
  verificationProfile: v.string(),
  allowedAgentIds: v.array(v.string()),
  policy: v.record(v.string(), v.unknown()),
  manifestVersion: v.number(),
  protocolVersion: v.number(),
  createdAt: v.date(),
  updatedAt: v.date(),
});

export const taskRunEvidenceSchema = v.object({
  id: v.string(),
  runId: v.string(),
  agentPrincipalId: v.nullable(v.string()),
  kind: v.string(),
  payload: v.record(v.string(), v.unknown()),
  createdAt: v.date(),
});

export const taskRunSchema = v.object({
  id: v.string(),
  taskId: v.string(),
  scheduleId: v.nullable(v.string()),
  manifestId: v.nullable(v.string()),
  manifestVersion: v.number(),
  protocolVersion: v.number(),
  repositoryOwner: v.string(),
  repositoryName: v.string(),
  baseBranch: v.string(),
  state: v.string(),
  role: v.string(),
  agentPrincipalId: v.nullable(v.string()),
  hostId: v.string(),
  branchName: v.string(),
  scope: v.array(v.string()),
  baseSha: v.nullable(v.string()),
  commitSha: v.nullable(v.string()),
  prNumber: v.nullable(v.number()),
  prUrl: v.nullable(v.string()),
  prState: v.nullable(v.string()),
  evidence: v.record(v.string(), v.unknown()),
  blocker: v.nullable(v.string()),
  nextAction: v.nullable(v.string()),
  // SPEC-kaneo-native-telegram-control-v0-1 typed run fields.
  runRevision: v.number(),
  taskRevisionAtClaim: v.number(),
  scheduleRevision: v.nullable(v.number()),
  parentRunId: v.nullable(v.string()),
  logicalSessionId: v.nullable(v.string()),
  retryAt: v.nullable(v.date()),
  modelFailed: v.nullable(v.string()),
  failureKind: v.nullable(v.string()),
  attempt: v.number(),
  maxAttempts: v.number(),
  lastCheckpointSha: v.nullable(v.string()),
  lastCommitSha: v.nullable(v.string()),
  finalizationReceipt: v.record(v.string(), v.unknown()),
  manualRecoveryRequired: v.boolean(),
  leaseEpoch: v.number(),
  leaseActive: v.boolean(),
  leaseExpiresAt: v.date(),
  lastHeartbeatAt: v.date(),
  createdAt: v.date(),
  updatedAt: v.date(),
  leaseToken: v.optional(v.string()),
});

export const configSchema = v.object({
  disableRegistration: v.nullable(v.boolean()),
  disablePasswordRegistration: v.nullable(v.boolean()),
  disableEmailOtpSignIn: v.nullable(v.boolean()),
  isDemoMode: v.boolean(),
  hasSmtp: v.boolean(),
  hasGithubSignIn: v.nullable(v.boolean()),
  hasGoogleSignIn: v.nullable(v.boolean()),
  hasDiscordSignIn: v.nullable(v.boolean()),
  hasCustomOAuth: v.nullable(v.boolean()),
  hasGuestAccess: v.nullable(v.boolean()),
  disableLoginForm: v.nullable(v.boolean()),
  customOAuthAutoLogin: v.nullable(v.boolean()),
  customOAuthLogoutUrl: v.nullable(v.string()),
});
