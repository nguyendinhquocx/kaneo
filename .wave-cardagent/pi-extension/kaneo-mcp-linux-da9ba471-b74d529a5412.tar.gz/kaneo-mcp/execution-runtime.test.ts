import test from "node:test";
import assert from "node:assert/strict";
import type { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";
import { KaneoApiError } from "./kaneo-client.ts";
import type {
  KaneoAgentPrincipalRecord,
  KaneoExecutionManifestRecord,
  KaneoTaskRecord,
  KaneoTaskRunRecord,
  SecretConfig,
} from "./kaneo-client.ts";
import { KaneoExecutionRuntime, type ExecutionRuntimeClient } from "./execution-runtime.ts";

const task: KaneoTaskRecord = {
  id: "task-123",
  projectId: "project-123",
  title: "Fix the worker flow",
  description: "Implement and verify the bounded worker lifecycle.",
};

const manifest: KaneoExecutionManifestRecord = {
  id: "manifest-123",
  projectId: task.projectId,
  repositoryOwner: "owner",
  repositoryName: "repo",
  baseBranch: "main",
  docs: ["README.md"],
  verificationProfile: "pnpm test",
  allowedAgentIds: ["agent-abc"],
  policy: { dependencies: ["api"] },
  manifestVersion: 1,
  protocolVersion: 1,
};

const principal: KaneoAgentPrincipalRecord = {
  id: "agent-abc",
  userId: "user-123",
  runtimeId: "pi-laptop",
  hostId: "pi-laptop",
  scopes: ["run:claim", "run:heartbeat", "run:report"],
  isActive: true,
};

function makeRun(state = "in_progress", leaseActive = true): KaneoTaskRunRecord {
  return {
    id: "run-123",
    taskId: task.id,
    manifestId: manifest.id,
    manifestVersion: 1,
    protocolVersion: 1,
    repositoryOwner: "owner",
    repositoryName: "repo",
    baseBranch: "main",
    state,
    role: "worker",
    agentPrincipalId: principal.id,
    hostId: principal.hostId,
    branchName: "pi-laptop/task-123-run-123-fix",
    scope: ["apps/api/src/example.ts"],
    leaseEpoch: 1,
    leaseActive,
    leaseExpiresAt: "2099-01-01T00:00:00.000Z",
    lastHeartbeatAt: "2099-01-01T00:00:00.000Z",
  };
}

function makePi(entries: unknown[]) {
  const calls: string[][] = [];
  const notifications: string[] = [];
  const pi = {
    appendEntry(_type: string, data: unknown) {
      entries.push({ type: "custom", customType: "kaneo-execution-state", data });
    },
    async exec(_command: string, args: string[]) {
      calls.push(args);
      const operation = args[args.indexOf("--operation") + 1];
      if (operation === "resolve") {
        return {
          code: 0,
          stdout: JSON.stringify({ status: "PASS", checkout_root: "D:/checkout", worktree_root: "D:/wt-root" }),
          stderr: "",
        };
      }
      if (operation === "worktree-add") {
        return {
          code: 0,
          stdout: JSON.stringify({
            status: "PASS",
            operation: "worktree-add",
            worktree_path: "D:/wt-root/run-123/worktree",
            worktree_created: true,
            branch: "pi-laptop/task-123-run-123-fix",
          }),
          stderr: "",
        };
      }
      if (operation === "status") {
        return { code: 0, stdout: JSON.stringify({ status: "PASS", output: "## main\n" }), stderr: "" };
      }
      if (operation === "create") {
        return {
          code: 0,
          stdout: JSON.stringify({
            status: "PASS",
            operation: "create",
            pr_number: 41,
            pr_url: "https://github.com/owner/repo/pull/41",
            pr_state: "open",
          }),
          stderr: "",
        };
      }
      if (operation === "merge") {
        return {
          code: 0,
          stdout: JSON.stringify({
            status: "PASS",
            operation: "merge",
            pr_number: 41,
            pr_url: "https://github.com/owner/repo/pull/41",
            pr_state: "merged",
            merge_commit_sha: "c".repeat(40),
          }),
          stderr: "",
        };
      }
      if (operation === "review") {
        return {
          code: 0,
          stdout: JSON.stringify({
            status: "PASS",
            base_sha: "a".repeat(40),
            commit_sha: "b".repeat(40),
            changed_files: ["apps/api/src/example.ts"],
            diff_within_scope: true,
            branch_valid: true,
            base_ancestor: true,
            commands: ["git diff --check main...branch"],
          }),
          stderr: "",
        };
      }
      if (operation === "push") {
        return {
          code: 0,
          stdout: JSON.stringify({
            status: "PASS",
            operation: "push",
            guard_receipt: {
              receiptId: "git-push-task-123-run-123-bbbbbbbbbbbb",
              remoteRef: "pi-laptop/task-123-run-123-fix",
              headSha: "b".repeat(40),
              commitSha: "b".repeat(40),
              receiptHash: "d".repeat(64),
            },
          }),
          stderr: "",
        };
      }
      return { code: 0, stdout: JSON.stringify({ status: "PASS", output: operation }), stderr: "" };
    },
  } as unknown as ExtensionAPI;
  const ctx = {
    sessionManager: { getEntries: () => entries },
    ui: { notify(message: string) { notifications.push(message); } },
  } as unknown as ExtensionContext;
  return { pi, ctx, calls, notifications };
}

function makeClient(overrides: Partial<ExecutionRuntimeClient> = {}): ExecutionRuntimeClient {
  const secret: SecretConfig = {
    apiKey: "api-key-must-not-escape",
    endpoint: "https://kaneo.example",
    agentPrincipalId: principal.id,
    hostId: "pi-laptop",
    gitAllowlistPath: "D:/private/allowlist.json",
    gitGuardPath: "D:/private/git_guard.py",
  };
  let currentRun = makeRun();
  return {
    readSecret: async () => secret,
    getKaneoTask: async () => task,
    getExecutionManifest: async () => manifest,
    getTaskRelations: async () => [{ id: "relation-1", sourceTaskId: task.id, targetTaskId: "task-456", relationType: "blocks" }],
    getTaskRun: async () => currentRun,
    listTaskComments: async () => [],
    createTaskComment: async () => ({ id: "comment-1", taskId: task.id, content: "checkpoint" }),
    listTaskRunEvidence: async () => [],
    listExecutionAgents: async () => [principal],
    listTaskRuns: async () => [currentRun],
    claimTaskRun: async () => ({ ...currentRun, leaseToken: "lease-token-must-not-escape" }),
    heartbeatTaskRun: async () => currentRun,
    createTaskRunCheckpoint: async (_taskId, _runId, _epoch, _token, input) => {
      currentRun = {
        ...currentRun,
        state: "checkpointed",
        leaseActive: true,
        lastCheckpointSha: input.headSha as string,
        lastCommitSha: input.commitSha as string,
      };
      return currentRun;
    },
    reportTaskRun: async (_taskId, _runId, _epoch, _token, input) => {
      currentRun = makeRun(String(input.state), input.state !== "in_review");
      return currentRun;
    },
    releaseTaskRun: async (_taskId, _runId, _epoch, _token, state) => {
      currentRun = makeRun(String(state ?? "blocked_input"), false);
      return currentRun;
    },
    reviewTaskRun: async (_taskId, _runId, input) => {
      currentRun = makeRun(input.decision === "approve" ? "done" : "rejected", false);
      return currentRun;
    },
    ...overrides,
  };
}

test("context and guarded lifecycle keep lease token out of worker output", async () => {
  const entries: unknown[] = [];
  const { pi, ctx, calls } = makePi(entries);
  const runtime = new KaneoExecutionRuntime(pi, ctx, makeClient());

  const context = await runtime.getContext(task.id);
  assert.equal(context.hostBinding.status, "configured");
  assert.equal(context.hostBinding.checkoutRoot, "D:/checkout");
  assert.equal(context.manifest.verificationProfile, "pnpm test");
  assert.equal(context.verification.profile, "pnpm test");
  assert.equal(context.relations[0]?.relationType, "blocks");
  assert.deepEqual(context.verification.policy.dependencies, ["api"]);
  assert.equal(context.currentRun, null);
  assert.equal(context.worker.configuredRuntimeId, "pi-laptop");
  assert.equal(JSON.stringify(context).includes("api-key-must-not-escape"), false);

  const claimed = await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  assert.equal(claimed.branchName, "pi-laptop/task-123-run-123-fix");
  assert.equal("leaseToken" in claimed, false);
  const claimedContext = await runtime.getContext(task.id);
  assert.equal(claimedContext.currentRun?.id, claimed.id);
  assert.equal("leaseToken" in (claimedContext.currentRun ?? {}), false);

  await assert.rejects(
    () => runtime.report(task.id, { state: "done" }),
    /worker may report only in_progress, in_review, blocked_quota, blocked_input/,
  );

  const prepared = await runtime.prepareCheckout(task.id);
  assert.equal(prepared.currentBranch, claimed.branchName);
  assert.equal(prepared.worktreePath, "D:/wt-root/run-123/worktree");
  const prepareOps = calls.map((args) => args[args.indexOf("--operation") + 1]);
  assert.deepEqual(prepareOps.slice(prepareOps.lastIndexOf("resolve")), ["resolve", "fetch", "worktree-add"]);
  assert.equal(prepareOps.includes("status"), true);
  assert.equal(prepareOps.includes("branch"), false);
  const worktreeAddArgs = calls.find((args) => args.includes("worktree-add"));
  assert.equal(worktreeAddArgs?.includes("--yes"), true);

  const heartbeat = await runtime.heartbeat(task.id);
  assert.equal(heartbeat.leaseEpoch, 1);
  const blocked = await runtime.report(task.id, {
    state: "blocked_input",
    blocker: "fixture blocker",
    evidence: { checks: ["typecheck"] },
  });
  assert.equal(blocked.state, "blocked_input");
  const review = await runtime.report(task.id, { state: "in_review" });
  assert.equal(review.leaseActive, false);
  assert.equal("leaseToken" in review, false);
  await assert.rejects(() => runtime.heartbeat(task.id), /no lease token|no active/);
});

test("worker Git mutations fence commit and push without exposing credentials", async () => {
  const entries: unknown[] = [];
  const { pi, ctx, calls } = makePi(entries);
  const runtime = new KaneoExecutionRuntime(pi, ctx, makeClient());

  await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  const committed = await runtime.commitTaskBranch(task.id, "task-123: checkpoint");
  const pushed = await runtime.pushTaskBranch(task.id);

  assert.equal(committed.operation, "commit");
  assert.equal(pushed.operation, "push");
  assert.equal(committed.commitSha, "b".repeat(40));
  assert.equal(pushed.commitSha, "b".repeat(40));
  const mutationCalls = calls.filter((args) => {
    const operationIndex = args.indexOf("--operation");
    const operation = operationIndex >= 0 ? args[operationIndex + 1] : undefined;
    return operation === "commit" || operation === "push";
  });
  assert.equal(mutationCalls.length, 2);
  for (const args of mutationCalls) {
    assert.equal(args.includes("--run-id"), true);
    assert.equal(args.includes("--lease-epoch"), true);
    assert.equal(args.includes("--fence-base-url"), true);
    assert.equal(args.includes("--api-key-file"), true);
    assert.equal(args.includes("--lease-token-file"), true);
    assert.equal(args.includes("--worktree"), true);
  }
  assert.equal(JSON.stringify(calls).includes("api-key-must-not-escape"), false);
  assert.equal(JSON.stringify(calls).includes("lease-token-must-not-escape"), false);
  assert.equal(JSON.stringify(entries).includes("api-key-must-not-escape"), false);
  assert.equal(JSON.stringify(entries).includes("lease-token-must-not-escape"), false);
});

test("durable checkpoint fences push receipt, records a milestone comment and supports retry", async () => {
  const entries: unknown[] = [];
  const { pi, ctx } = makePi(entries);
  const comments: Array<{ id: string; taskId: string; content: string }> = [];
  let checkpointInput: Record<string, unknown> | undefined;
  const runtime = new KaneoExecutionRuntime(
    pi,
    ctx,
    makeClient({
      listTaskComments: async () => comments,
      createTaskComment: async (_taskId, content) => {
        const comment = { id: `comment-${comments.length + 1}`, taskId: task.id, content };
        comments.push(comment);
        return comment;
      },
      createTaskRunCheckpoint: async (_taskId, _runId, _epoch, _token, input) => {
        checkpointInput = input;
        return {
          ...makeRun("checkpointed", true),
          lastCheckpointSha: input.headSha as string,
          lastCommitSha: input.commitSha as string,
        };
      },
    }),
  );

  await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  const first = await runtime.checkpointTaskRun(task.id, {
    message: "task-123: implementation phase",
    commands: ["node --test"],
    artifactHashes: { source: "a".repeat(64) },
    verifyResult: { phase: "implementation", passed: true },
  });
  assert.equal(first.run.state, "checkpointed");
  assert.equal(first.commitSha, "b".repeat(40));
  assert.equal(first.branch, "pi-laptop/task-123-run-123-fix");
  assert.equal(first.commentCreated, true);
  // The claim flow posts a fire-and-forget [⭕ DOING] marker first; assert on
  // the checkpoint milestone comment itself, not on list order.
  const checkpointComment = comments.find((comment) => comment.content.includes("kaneo-checkpoint:run-123:"));
  assert.match(checkpointComment?.content ?? "", /kaneo-checkpoint:run-123:/);
  assert.match(checkpointComment?.content ?? "", /Phase: implementation/);
  assert.equal(checkpointInput?.headSha, "b".repeat(40));
  assert.equal((checkpointInput?.guardReceipt as Record<string, unknown>)?.remoteRef, "pi-laptop/task-123-run-123-fix");

  const retry = await runtime.checkpointTaskRun(task.id, {
    baseSha: first.baseSha,
    headSha: first.commitSha,
    commitSha: first.commitSha,
    guardReceipt: first.guardReceipt,
    verifyResult: { phase: "implementation", passed: true },
  });
  assert.equal(retry.commentCreated, false);
  // No second checkpoint milestone comment on stored-replay retry (the claim
  // DOING marker comment also lives in this list).
  assert.equal(
    comments.filter((comment) => comment.content.includes("kaneo-checkpoint:run-123:")).length,
    1,
  );
});

test("parent PR adapter evidence is sent to Kaneo without finalizing on PR creation", async () => {
  const entries: unknown[] = [];
  const reviewRun = {
    ...makeRun("in_review", false),
    baseSha: "a".repeat(40),
    commitSha: "b".repeat(40),
  };
  const { pi, ctx, calls } = makePi(entries);
  let reviewInput: Record<string, unknown> | undefined;
  const runtime = new KaneoExecutionRuntime(
    pi,
    ctx,
    makeClient({
      readSecret: async () => ({
        apiKey: "api-key-must-not-escape",
        endpoint: "https://kaneo.example",
        agentPrincipalId: principal.id,
        hostId: "pi-laptop",
        gitAllowlistPath: "D:/private/allowlist.json",
        gitGuardPath: "D:/private/git_guard.py",
        prGuardPath: "D:/private/pr_guard.py",
      }),
      getExecutionManifest: async () => ({ ...manifest, policy: { allowPrCreate: true } }),
      getTaskRun: async () => reviewRun,
      listTaskRuns: async () => [reviewRun],
      listTaskRunEvidence: async () => [],
      reviewTaskRun: async (_taskId, _runId, input) => {
        reviewInput = input;
        return {
          ...reviewRun,
          state: "in_review",
          prNumber: 41,
          prUrl: "https://github.com/owner/repo/pull/41",
          prState: "open",
        };
      },
    }),
  );

  const result = await runtime.review(task.id, reviewRun.id, {
    decision: "approve",
    action: "create_pr",
    testsPassed: true,
    testCommands: ["pnpm test"],
  });
  assert.equal(result.run.state, "in_review");
  assert.equal(result.run.prNumber, 41);
  assert.equal(reviewInput?.reviewHeadSha, "b".repeat(40));
  assert.deepEqual((reviewInput?.prResult as Record<string, unknown>).status, "PASS");
  assert.deepEqual(
    calls.map((args) => args[args.indexOf("--operation") + 1]),
    ["resolve", "fetch", "review", "create"],
  );
});

test("parent merge review forwards verified head and merge commit evidence", async () => {
  const entries: unknown[] = [];
  const reviewRun = {
    ...makeRun("in_review", false),
    baseSha: "a".repeat(40),
    commitSha: "b".repeat(40),
    prNumber: 41,
    prUrl: "https://github.com/owner/repo/pull/41",
    prState: "open",
  };
  const { pi, ctx, calls } = makePi(entries);
  let reviewInput: Record<string, unknown> | undefined;
  const runtime = new KaneoExecutionRuntime(
    pi,
    ctx,
    makeClient({
      readSecret: async () => ({
        apiKey: "api-key-must-not-escape",
        endpoint: "https://kaneo.example",
        agentPrincipalId: principal.id,
        hostId: "pi-laptop",
        gitAllowlistPath: "D:/private/allowlist.json",
        gitGuardPath: "D:/private/git_guard.py",
        prGuardPath: "D:/private/pr_guard.py",
      }),
      getExecutionManifest: async () => ({ ...manifest, policy: { allowMerge: true } }),
      getTaskRun: async () => reviewRun,
      listTaskRuns: async () => [reviewRun],
      listTaskRunEvidence: async () => [],
      reviewTaskRun: async (_taskId, _runId, input) => {
        reviewInput = input;
        return { ...reviewRun, state: "finalized", leaseActive: false };
      },
    }),
  );

  const result = await runtime.review(task.id, reviewRun.id, {
    decision: "approve",
    action: "merge",
    testsPassed: true,
    testCommands: ["pnpm test"],
  });
  assert.equal(result.run.state, "finalized");
  assert.equal(reviewInput?.reviewHeadSha, "b".repeat(40));
  const prResult = reviewInput?.prResult as Record<string, unknown>;
  assert.equal(prResult.status, "PASS");
  assert.equal(prResult.prState, "merged");
  assert.equal(prResult.mergeCommitSha, "c".repeat(40));
  assert.deepEqual(
    calls.map((args) => args[args.indexOf("--operation") + 1]),
    ["resolve", "fetch", "review", "merge"],
  );
});

test("release fences the worker lease without exposing the token or finalizing the task", async () => {
  const entries: unknown[] = [];
  const { pi, ctx } = makePi(entries);
  const runtime = new KaneoExecutionRuntime(pi, ctx, makeClient());

  await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  const released = await runtime.release(task.id, "blocked_input");
  assert.equal(released.state, "blocked_input");
  assert.equal(released.leaseActive, false);
  assert.equal("leaseToken" in released, false);
  assert.equal(JSON.stringify(entries).includes("lease-token-must-not-escape"), false);
  await assert.rejects(() => runtime.heartbeat(task.id), /previous run but no lease token/);
});

test("a stale CAS 409 keeps the in-memory lease for safe retry", async () => {
  const entries: unknown[] = [];
  const { pi, ctx, notifications } = makePi(entries);
  let heartbeatCalls = 0;
  const runtime = new KaneoExecutionRuntime(pi, ctx, makeClient({
    heartbeatTaskRun: async () => {
      heartbeatCalls += 1;
      throw new KaneoApiError("stale fence: run revision drifted", 409);
    },
  }));
  await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  await assert.rejects(() => runtime.heartbeat(task.id), /stale fence/);
  assert.equal(notifications.length, 0);
  // Revision drift is not an ownership transfer. Keep the lease in memory so
  // the worker can refresh state and retry instead of losing authority.
  await assert.rejects(() => runtime.heartbeat(task.id), /stale fence/);
  assert.equal(heartbeatCalls, 2);
  assert.equal(JSON.stringify(entries).includes("lease-token-must-not-escape"), false);
});

test("prepareCheckout fails closed when the host binding has no worktreeRoot", async () => {
  const entries: unknown[] = [];
  const { pi, ctx } = makePi(entries);
  const runtime = new KaneoExecutionRuntime(
    pi,
    ctx,
    makeClient(),
  );
  // Force the guard resolve result to omit worktree_root (legacy binding).
  const originalExec = (pi as unknown as { exec: (command: string, args: string[]) => Promise<{ code: number; stdout: string; stderr: string }> }).exec;
  (pi as unknown as { exec: typeof originalExec }).exec = async (command, args) => {
    const result = await originalExec(command, args);
    if (args.includes("resolve")) {
      const payload = JSON.parse(result.stdout);
      delete payload.worktree_root;
      return { ...result, stdout: JSON.stringify(payload) };
    }
    return result;
  };

  await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  await assert.rejects(
    () => runtime.prepareCheckout(task.id),
    /no worktreeRoot; worker runs require a run worktree/,
  );
});

test("a new runtime restores only public state and requires server reconciliation", async () => {
  const entries: unknown[] = [];
  const first = makePi(entries);
  const runtime = new KaneoExecutionRuntime(first.pi, first.ctx, makeClient());
  await runtime.claim(task.id, ["apps/api/src/example.ts"]);
  runtime.stop();

  const second = makePi(entries);
  const resumed = new KaneoExecutionRuntime(second.pi, second.ctx, makeClient());
  const context = await resumed.getContext(task.id);
  assert.equal(context.worker.resumeRequired, true);
  await assert.rejects(
    () => resumed.heartbeat(task.id),
    /previous run but no lease token/,
  );
  assert.equal(JSON.stringify(entries).includes("lease-token-must-not-escape"), false);
});

test("parent review uses independent guarded diff evidence and keeps lease credentials private", async () => {
  const entries: unknown[] = [];
  const reviewRun = {
    ...makeRun("in_review", false),
    baseSha: "a".repeat(40),
    commitSha: "b".repeat(40),
  };
  const { pi, ctx, calls } = makePi(entries);
  let reviewInput: Record<string, unknown> | undefined;
  const runtime = new KaneoExecutionRuntime(
    pi,
    ctx,
    makeClient({
      getTaskRun: async () => reviewRun,
      listTaskRuns: async () => [reviewRun],
      listTaskRunEvidence: async () => [],
      reviewTaskRun: async (_taskId, _runId, input) => {
        reviewInput = input;
        return { ...reviewRun, state: "done", leaseActive: false };
      },
    }),
  );

  const result = await runtime.review(task.id, reviewRun.id, {
    decision: "approve",
    testsPassed: true,
    testCommands: ["pnpm test"],
  });
  assert.equal(result.run.state, "done");
  assert.equal(result.verification?.diff_within_scope, true);
  assert.equal(reviewInput?.reviewHeadSha, "b".repeat(40));
  assert.deepEqual(
    calls.map((args) => args[args.indexOf("--operation") + 1]),
    ["resolve", "fetch", "review"],
  );
  assert.equal(JSON.stringify(result).includes("lease-token-must-not-escape"), false);
});
