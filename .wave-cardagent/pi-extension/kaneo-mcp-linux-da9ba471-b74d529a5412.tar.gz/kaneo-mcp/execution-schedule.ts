// Parent-only schedule planner — SPEC-kaneo-native-telegram-control-v0-1 (T2).
//
// Pure preview/confirm logic for the fixed `kaneo_create_execution_schedule`
// tool. This file contains no REST calls and no secrets: execution-tools.ts
// wires the plan to the authenticated Kaneo client after the parent confirms
// the preview. The plan hash + expected revisions implement the envelope
// protocol: resolve → preview → confirm plan → execute.
//
// CLI (tests/kaneo_agent_schedule_test.py):
//   node --experimental-strip-types execution-schedule.ts plan <input.json>
//   node --experimental-strip-types execution-schedule.ts confirm <plan.json> <confirmation.json>

import { createHash } from "node:crypto";
import { readFileSync, realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";

export const SCHEDULE_TOOL_NAME = "kaneo_create_execution_schedule";
export const NATIVE_HOST_ID = "pi-prodesk";
/** `prodesk-home` is an SSH/target alias only — never a schedule host. */
export const FORBIDDEN_HOST_ALIASES = ["prodesk-home"] as const;
export const SCHEDULE_NOTIFICATION_ROUTES = ["prodesk-telegram"] as const;
export const SCHEDULE_QUOTA_RESUME_MODES = [
  "disabled",
  "allowed_same_model_after_reset",
] as const;
/** v0.1 freezes dependencyPolicy=reject; hold/deferred is a later spec. */
export const SCHEDULE_DEPENDENCY_POLICY = "reject";
const MODEL_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/;
const TASK_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{1,63}$/;

// SPEC-kaneo-wavefix-v0-2 (T1): worker contract validation for schedule
// preview. Mirror of the dispatcher's strict parser (kaneo_agent_dispatcher
// .py::extract_worker_contract): only the FIRST parseable JSON object counts;
// escaped markup (\[, &amp;) or missing semantic fields hard-reject so a
// corrupt contract can never reach dispatch as a silent no-op.
const CONTRACT_ESCAPE_PATTERNS = ["\\[", "&amp;", "&lt;", "&gt;", "&quot;"] as const;
const REPO_PATTERN = /^[A-Za-z0-9_.-]{1,100}\/[A-Za-z0-9_.-]{1,100}$/;

export interface WorkerContractCheck {
  ok: boolean;
  scope?: string[];
  reason?: string;
}

function isSafeScopeEntry(entry: unknown): entry is string {
  return (
    typeof entry === "string" &&
    entry.length > 0 &&
    entry !== "laptop-only" &&
    !entry.startsWith("/") &&
    !entry.startsWith("\\") &&
    entry !== "." &&
    entry !== ".." &&
    !entry.includes("\\") &&
    !entry.includes("*") &&
    !entry.includes("\0") &&
    !entry.split("/").includes("..")
  );
}

function extractFirstJsonObject(text: string): string | undefined {
  const start = text.indexOf("{");
  if (start === -1) return undefined;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return undefined;
}

export function parseWorkerContract(description: string | null | undefined): WorkerContractCheck {
  if (!description) return { ok: false, reason: "contract_missing_description" };
  const rawBlock = extractFirstJsonObject(description);
  if (rawBlock === undefined) {
    return { ok: false, reason: "contract_no_json_block" };
  }
  let payload: unknown;
  try {
    payload = JSON.parse(rawBlock);
  } catch {
    return { ok: false, reason: "contract_no_json_block" };
  }
  for (const pattern of CONTRACT_ESCAPE_PATTERNS) {
    if (rawBlock.includes(pattern)) {
      return { ok: false, reason: `contract_escaped_markup:${pattern}` };
    }
  }
  if (typeof payload !== "object" || payload === null || Array.isArray(payload)) {
    return { ok: false, reason: "contract_not_object" };
  }
  const contract = payload as Record<string, unknown>;
  if (contract.laptop_only === true) {
    return { ok: false, reason: "contract_laptop_only" };
  }
  if (contract.schema !== 1) return { ok: false, reason: "contract_schema_unsupported" };
  if (typeof contract.agent !== "string" || contract.agent.trim() === "") {
    return { ok: false, reason: "contract_agent_missing" };
  }
  if (typeof contract.repo !== "string" || !REPO_PATTERN.test(contract.repo)) {
    return { ok: false, reason: "contract_repo_invalid" };
  }
  if (typeof contract.spec_id !== "string" || contract.spec_id.trim() === "") {
    return { ok: false, reason: "contract_spec_id_missing" };
  }
  if (typeof contract.task_id !== "string" || contract.task_id.trim() === "") {
    return { ok: false, reason: "contract_task_id_missing" };
  }
  if (
    contract.depends_on !== undefined &&
    (!Array.isArray(contract.depends_on) || !contract.depends_on.every((e) => typeof e === "string"))
  ) {
    return { ok: false, reason: "contract_depends_on_invalid" };
  }
  if (typeof contract.wave !== "number" || !Number.isInteger(contract.wave) || contract.wave < 1) {
    return { ok: false, reason: "contract_wave_invalid" };
  }
  if (
    !Array.isArray(contract.verify) ||
    contract.verify.length === 0 ||
    !contract.verify.every((entry) => typeof entry === "string" && entry.trim() !== "")
  ) {
    return { ok: false, reason: "contract_verify_missing" };
  }
  const files = contract.files;
  if (!Array.isArray(files) || files.length === 0 || !files.every((entry) => isSafeScopeEntry(entry))) {
    return { ok: false, reason: "contract_scope_unsafe" };
  }
  return { ok: true, scope: files };
}

export interface ScheduleRetryPolicy {
  maxAttempts?: number;
  backoffSeconds?: number;
}

export interface SchedulePlanInput {
  taskId: string;
  taskTitle?: string | null;
  /** "YYYY-MM-DD HH:MM" in `timezone`, or an ISO timestamp with Z/offset. */
  localTime: string;
  timezone: string;
  model: string;
  host?: string;
  notificationRoute?: string;
  telegramQuotaResume?: string;
  dependencyPolicy?: string;
  retryPolicy?: ScheduleRetryPolicy;
  expectedTaskRevision: number;
  manifestVersion?: number | null;
  planNote?: string | null;
}

export interface SchedulePlan {
  schemaVersion: 1;
  tool: typeof SCHEDULE_TOOL_NAME;
  taskId: string;
  taskTitle: string | null;
  notBeforeUtc: string;
  timezone: string;
  model: string;
  host: string;
  notificationRoute: string;
  telegramQuotaResume: string;
  dependencyPolicy: typeof SCHEDULE_DEPENDENCY_POLICY;
  retryPolicy: { maxAttempts: number; backoffSeconds: number };
  expectedTaskRevision: number;
  manifestVersion: number | null;
  planNote: string | null;
  planHash: string;
  createdAt: string;
}

export interface PlanConfirmation {
  planHash: string;
  currentTaskRevision: number;
  currentManifestVersion?: number | null;
}

export type ScheduleConfirmResult =
  | {
      ok: true;
      executed: true;
      request: {
        path: string;
        body: Record<string, unknown>;
        idempotencyKey: string;
      };
    }
  | { ok: false; executed: false; reason: string };

function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, entry]) => [key, canonicalize(entry)]),
    );
  }
  return value;
}

export function stablePlanHash(value: unknown): string {
  return createHash("sha256")
    .update(JSON.stringify(canonicalize(value)))
    .digest("hex");
}

function assertValidTimezone(timezone: string): void {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: timezone });
  } catch {
    throw new Error(`invalid timezone: ${timezone}`);
  }
}

function timeZoneOffsetMs(date: Date, timeZone: string): number {
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const parts = formatter.formatToParts(date);
  const values: Record<string, number> = {};
  for (const part of parts) {
    if (part.type !== "literal") values[part.type] = Number(part.value);
  }
  const hour = values.hour === 24 ? 0 : values.hour;
  const asUtc = Date.UTC(
    values.year,
    values.month - 1,
    values.day,
    hour,
    values.minute,
    values.second,
  );
  return asUtc - date.getTime();
}

/**
 * Resolve a wall-clock time in `timezone` (or an explicit ISO instant) to a
 * UTC Date. DST boundaries are resolved by iterating the offset twice.
 */
export function resolveNotBeforeUtc(
  localTime: string,
  timezone: string,
  now: Date = new Date(),
): Date {
  assertValidTimezone(timezone);
  const trimmed = localTime.trim();
  const zoned = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})$/.exec(trimmed);
  if (zoned) {
    const [, year, month, day, hour, minute] = zoned;
    const naive = Date.UTC(
      Number(year),
      Number(month) - 1,
      Number(day),
      Number(hour),
      Number(minute),
    );
    let timestamp = naive - timeZoneOffsetMs(new Date(naive), timezone);
    timestamp = naive - timeZoneOffsetMs(new Date(timestamp), timezone);
    return new Date(timestamp);
  }
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(
      "localTime must be 'YYYY-MM-DD HH:MM' in timezone or an ISO timestamp with Z/offset",
    );
  }
  if (!/[Zz]|[+-]\d{2}:?\d{2}$/.test(trimmed)) {
    // No explicit offset: interpret the wall clock in `timezone`.
    let timestamp =
      parsed.getTime() - timeZoneOffsetMs(parsed, timezone);
    timestamp =
      parsed.getTime() - timeZoneOffsetMs(new Date(timestamp), timezone);
    return new Date(timestamp);
  }
  return parsed;
}

function validateRetryBounds(
  retryPolicy: ScheduleRetryPolicy | undefined,
): { maxAttempts: number; backoffSeconds: number } {
  const maxAttempts = retryPolicy?.maxAttempts ?? 1;
  const backoffSeconds = retryPolicy?.backoffSeconds ?? 60;
  if (
    !Number.isInteger(maxAttempts) ||
    maxAttempts < 1 ||
    maxAttempts > 10
  ) {
    throw new Error("retryPolicy.maxAttempts must be an integer 1-10");
  }
  if (
    !Number.isInteger(backoffSeconds) ||
    backoffSeconds < 10 ||
    backoffSeconds > 86_400
  ) {
    throw new Error("retryPolicy.backoffSeconds must be an integer 10-86400");
  }
  return { maxAttempts, backoffSeconds };
}

/** Build a schedule plan from validated parent intent. Throws on bad input. */
export function buildSchedulePlan(
  input: SchedulePlanInput,
  now: Date = new Date(),
): SchedulePlan {
  if (!TASK_ID_PATTERN.test(input.taskId)) {
    throw new Error(`invalid taskId: ${input.taskId}`);
  }
  if (!MODEL_ID_PATTERN.test(input.model.trim())) {
    throw new Error(`invalid model id: ${input.model}`);
  }
  const host = input.host === undefined || input.host === "" ? NATIVE_HOST_ID : input.host;
  if ((FORBIDDEN_HOST_ALIASES as readonly string[]).includes(host)) {
    throw new Error(
      "host 'prodesk-home' is an SSH/target alias; native schedules must use 'pi-prodesk'",
    );
  }
  if (host !== NATIVE_HOST_ID) {
    throw new Error(`host must be '${NATIVE_HOST_ID}' for native schedules, got '${host}'`);
  }
  const notificationRoute =
    input.notificationRoute === undefined || input.notificationRoute === ""
      ? SCHEDULE_NOTIFICATION_ROUTES[0]
      : input.notificationRoute;
  if (!(SCHEDULE_NOTIFICATION_ROUTES as readonly string[]).includes(notificationRoute)) {
    throw new Error(
      `notificationRoute must be one of: ${SCHEDULE_NOTIFICATION_ROUTES.join(", ")}`,
    );
  }
  const telegramQuotaResume =
    input.telegramQuotaResume === undefined || input.telegramQuotaResume === ""
      ? "disabled"
      : input.telegramQuotaResume;
  if (!(SCHEDULE_QUOTA_RESUME_MODES as readonly string[]).includes(telegramQuotaResume)) {
    throw new Error(
      `telegramQuotaResume must be one of: ${SCHEDULE_QUOTA_RESUME_MODES.join(", ")}`,
    );
  }
  if (
    input.dependencyPolicy !== undefined &&
    input.dependencyPolicy !== SCHEDULE_DEPENDENCY_POLICY
  ) {
    throw new Error(`dependencyPolicy must be '${SCHEDULE_DEPENDENCY_POLICY}' in v0.1`);
  }
  if (
    !Number.isInteger(input.expectedTaskRevision) ||
    input.expectedTaskRevision < 1
  ) {
    throw new Error("expectedTaskRevision must be a positive integer");
  }
  const retryPolicy = validateRetryBounds(input.retryPolicy);
  const notBeforeUtc = resolveNotBeforeUtc(input.localTime, input.timezone, now);

  const withoutHash: Omit<SchedulePlan, "planHash"> = {
    schemaVersion: 1 as const,
    tool: SCHEDULE_TOOL_NAME,
    taskId: input.taskId,
    taskTitle: input.taskTitle ?? null,
    notBeforeUtc: notBeforeUtc.toISOString(),
    timezone: input.timezone,
    model: input.model.trim(),
    host,
    notificationRoute,
    telegramQuotaResume,
    dependencyPolicy: SCHEDULE_DEPENDENCY_POLICY,
    retryPolicy,
    expectedTaskRevision: input.expectedTaskRevision,
    manifestVersion: input.manifestVersion ?? null,
    planNote: input.planNote ?? null,
    createdAt: now.toISOString(),
  };
  // `createdAt` records when this preview was built, not what the parent
  // approved. Excluding it keeps the hash reproducible for the stateless
  // preview → confirm calls while the plan still retains the audit timestamp.
  const { createdAt: _createdAt, ...hashablePlan } = withoutHash;
  return { ...withoutHash, planHash: stablePlanHash(hashablePlan) };
}

/** Bounded Vietnamese preview the parent must confirm before execute. */
export function buildSchedulePreviewText(plan: SchedulePlan): string {
  return [
    `[Kaneo schedule preview] ${plan.tool}`,
    `- task: ${plan.taskId}${plan.taskTitle ? ` (${plan.taskTitle})` : ""}`,
    `- chạy lúc: ${plan.notBeforeUtc} (UTC, tz=${plan.timezone})`,
    `- host: ${plan.host} · model: ${plan.model}`,
    `- notification: ${plan.notificationRoute} · quota resume: ${plan.telegramQuotaResume}`,
    `- dependencyPolicy: ${plan.dependencyPolicy} · retry: max=${plan.retryPolicy.maxAttempts}, backoff=${plan.retryPolicy.backoffSeconds}s`,
    `- expectedTaskRevision: ${plan.expectedTaskRevision} · manifestVersion: ${plan.manifestVersion ?? "?"}`,
    `- planHash: ${plan.planHash}`,
    "Chưa tạo schedule. Confirm bằng planHash + expectedTaskRevision hiện tại.",
  ].join("\n");
}

/**
 * Confirmation binding: plan hash + current task revision must both still
 * match; the schedule must also still be in the future. Returns the exact
 * REST request execution-tools should send.
 */
export function confirmSchedulePlan(
  plan: SchedulePlan,
  confirmation: PlanConfirmation,
  now: Date = new Date(),
): ScheduleConfirmResult {
  if (confirmation.planHash !== plan.planHash) {
    return { ok: false, executed: false, reason: "plan_hash_mismatch" };
  }
  if (confirmation.currentTaskRevision !== plan.expectedTaskRevision) {
    return {
      ok: false,
      executed: false,
      reason: "state_changed_after_preview_must_preview_again",
    };
  }
  if (
    plan.manifestVersion !== null &&
    confirmation.currentManifestVersion !== undefined &&
    confirmation.currentManifestVersion !== null &&
    confirmation.currentManifestVersion !== plan.manifestVersion
  ) {
    return {
      ok: false,
      executed: false,
      reason: "manifest_version_changed",
    };
  }
  if (new Date(plan.notBeforeUtc).getTime() < now.getTime() - 60_000) {
    return { ok: false, executed: false, reason: "not_before_in_the_past" };
  }
  return {
    ok: true,
    executed: true,
    request: {
      path: `/api/execution/task/${plan.taskId}/schedules`,
      body: {
        notBefore: plan.notBeforeUtc,
        timezone: plan.timezone,
        host: plan.host,
        preferredModel: plan.model,
        fallbackMode: "manual",
        maxRuntimeSeconds: 3_600,
        retryPolicy: plan.retryPolicy,
        dependencyPolicy: plan.dependencyPolicy,
        notificationRoute: plan.notificationRoute,
        telegramQuotaResume: plan.telegramQuotaResume,
        planHash: plan.planHash,
        expectedTaskRevision: confirmation.currentTaskRevision,
      },
      idempotencyKey: `schedule:${plan.taskId}:${plan.planHash.slice(0, 32)}`,
    },
  };
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

function isMainModule(): boolean {
  const entry = process.argv[1];
  if (!entry) {
    return false;
  }
  try {
    return realpathSync(entry) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

function cliMain(): void {
  const [command, ...rest] = process.argv.slice(2);
  if (command === "plan" && rest[0]) {
    try {
      const input = JSON.parse(readFileSync(rest[0], "utf8")) as SchedulePlanInput;
      const plan = buildSchedulePlan(input);
      console.log(
        JSON.stringify({ ok: true, plan, preview: buildSchedulePreviewText(plan) }),
      );
    } catch (error) {
      console.log(
        JSON.stringify({
          ok: false,
          reason: error instanceof Error ? error.message : String(error),
        }),
      );
    }
    return;
  }
  if (command === "confirm" && rest.length >= 2) {
    try {
      const plan = JSON.parse(readFileSync(rest[0], "utf8")) as SchedulePlan;
      const confirmation = JSON.parse(readFileSync(rest[1], "utf8")) as PlanConfirmation;
      console.log(JSON.stringify(confirmSchedulePlan(plan, confirmation)));
    } catch (error) {
      console.log(
        JSON.stringify({
          ok: false,
          executed: false,
          reason: error instanceof Error ? error.message : String(error),
        }),
      );
    }
    return;
  }
  if (command === "contract-check" && rest.length >= 1) {
    try {
      const input = JSON.parse(readFileSync(rest[0], "utf8")) as { description?: string | null };
      console.log(JSON.stringify(parseWorkerContract(input.description ?? null)));
    } catch (error) {
      console.log(
        JSON.stringify({
          ok: false,
          reason: error instanceof Error ? error.message : String(error),
        }),
      );
    }
    return;
  }
  console.error(
    "Usage: execution-schedule.ts plan <input.json> | confirm <plan.json> <confirmation.json> | contract-check <input.json>",
  );
  process.exit(2);
}

if (isMainModule()) {
  cliMain();
}
