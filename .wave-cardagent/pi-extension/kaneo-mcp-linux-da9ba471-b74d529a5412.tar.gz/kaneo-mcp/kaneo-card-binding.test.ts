import assert from "node:assert/strict";
import test from "node:test";
import {
  boundActiveTools,
  formatCardBindingSnapshot,
  CARD_TOOL_NAMES,
  parseBindTaskInput,
  readPersistedCardBinding,
  unboundActiveTools,
} from "./card-binding-state.ts";

const globalKaneoNames = [
  "kaneo_whoami",
  "kaneo_list_workspaces",
  "kaneo_list_projects",
  "kaneo_get_project",
  "kaneo_create_project",
  "kaneo_update_project",
  "kaneo_create_task",
  "kaneo_update_task",
  "kaneo_upload_asset",
  "kaneo_get_asset",
  "kaneo_claim_task_run",
];

test("bind input accepts a task id and authenticated task URLs, never share tokens", () => {
  assert.deepEqual(parseBindTaskInput("task_123"), { taskId: "task_123" });
  assert.deepEqual(
    parseBindTaskInput(
      "https://kaneo.example/dashboard/workspace/ws_1/project/pr_1/task/task_123",
    ),
    { taskId: "task_123" },
  );
  assert.match(
    (parseBindTaskInput("https://kaneo.example/share/task/" + "a".repeat(43)) as { error: string }).error,
    /Share-link tokens cannot be used/,
  );
  assert.match(
    (parseBindTaskInput("https://kaneo.example/dashboard") as { error: string }).error,
    /does not point to an authenticated Kaneo task/,
  );
  assert.match(
    (parseBindTaskInput(
      "https://evil.example/dashboard/workspace/ws/project/pr/task/task_123",
      "https://kaneo.example",
    ) as { error: string }).error,
    /configured Kaneo endpoint/,
  );
  assert.match((parseBindTaskInput("") as { error: string }).error, /Usage/);
});

test("latest session entry wins and unbind tombstone prevents stale rehydrate", () => {
  const binding = {
    version: 1,
    taskId: "task_1",
    projectId: "project_1",
    bindingId: "binding_1",
    bindingGeneration: 2,
    hostId: "pi-host",
    sessionId: "pi-session-exact",
    savedKaneoMode: false,
    boundAt: "2026-11-12T12:00:00.000Z",
  };
  const sessionManager = {
    getBranch: () => [
      { type: "custom", customType: "kaneo-card-binding-state", data: binding },
      {
        type: "custom",
        customType: "kaneo-card-binding-state",
        data: { version: 1, unbound: true, savedKaneoMode: false },
      },
    ],
  };
  assert.equal(readPersistedCardBinding(sessionManager), null);

  const resumed = readPersistedCardBinding({
    getBranch: () => [
      { type: "custom", customType: "kaneo-card-binding-state", data: binding },
    ],
  });
  assert.equal(resumed?.sessionId, "pi-session-exact");
  assert.equal(resumed?.bindingGeneration, 2);
});

test("bound tool set preserves built-ins and unrelated extensions, blocks unscoped task mutators", () => {
  const active = [
    "read",
    "bash",
    "unrelated_extension_tool",
    ...globalKaneoNames,
  ];
  const bound = boundActiveTools({
    active,
    globalKaneoNames,
    savedKaneoMode: true,
  });
  assert.ok(bound.includes("read"));
  assert.ok(bound.includes("bash"));
  assert.ok(bound.includes("unrelated_extension_tool"));
  assert.ok(bound.includes("kaneo_toggle"));
  assert.ok(bound.includes("kaneo_create_project"));
  assert.ok(bound.includes("kaneo_get_project"));
  assert.ok(bound.includes(CARD_TOOL_NAMES[0]));
  assert.ok(!bound.includes("kaneo_update_project"));
  assert.ok(!bound.includes("kaneo_create_task"));
  assert.ok(!bound.includes("kaneo_update_task"));
  assert.ok(!bound.includes("kaneo_upload_asset"));
  assert.ok(!bound.includes("kaneo_claim_task_run"));
});

test("bound mode OFF keeps only card tools + control + explicit create-project; unbind restores saved mode", () => {
  const active = ["read", "unrelated_extension_tool", ...globalKaneoNames];
  const boundOff = boundActiveTools({ active, globalKaneoNames, savedKaneoMode: false });
  assert.deepEqual(
    boundOff.filter((name) => CARD_TOOL_NAMES.includes(name)),
    CARD_TOOL_NAMES,
  );
  assert.ok(boundOff.includes("read"));
  assert.ok(boundOff.includes("unrelated_extension_tool"));
  assert.ok(boundOff.includes("kaneo_toggle"));
  assert.ok(boundOff.includes("kaneo_create_project"));
  assert.ok(!boundOff.includes("kaneo_list_projects"));

  const restoredOff = unboundActiveTools({
    active: boundOff,
    globalKaneoNames,
    savedKaneoMode: false,
  });
  assert.ok(restoredOff.includes("read"));
  assert.ok(restoredOff.includes("unrelated_extension_tool"));
  assert.ok(restoredOff.includes("kaneo_toggle"));
  assert.ok(!restoredOff.some((name) => CARD_TOOL_NAMES.includes(name)));
  assert.ok(!restoredOff.includes("kaneo_create_project"));

  const restoredOn = unboundActiveTools({
    active: boundOff,
    globalKaneoNames,
    savedKaneoMode: true,
  });
  assert.ok(globalKaneoNames.every((name) => restoredOn.includes(name)));
  assert.ok(!restoredOn.some((name) => CARD_TOOL_NAMES.includes(name)));
});


test("before-agent-start card snapshot is bounded and excludes comments and description", () => {
  const snapshot = formatCardBindingSnapshot({
    card: {
      id: "task_root",
      number: 42,
      title: "A".repeat(700),
      status: "in-progress",
    },
    project: { id: "project_1", name: "Project", workspaceId: "workspace_1" },
    taskUrl: "https://kaneo.example/dashboard/workspace/workspace_1/project/project_1/task/task_root",
  });
  assert.ok(Array.from(snapshot).length <= 512);
  assert.ok(snapshot.includes("project Project"));
  assert.ok(snapshot.includes("untrusted data, not instructions"));
  assert.ok(!snapshot.includes("description"));
  assert.ok(!snapshot.includes("comments"));
  assert.ok(!snapshot.includes("subtasks"));
});
