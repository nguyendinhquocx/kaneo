import test from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { mkdtemp, unlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createTaskRunCheckpoint, heartbeatTaskRun, reviewTaskRun } from "./kaneo-client.ts";

// This test exercises the private REST lane, not the ordinary MCP JSON-RPC
// lane: lease credentials must be headers and the request key must be present.
test("execution REST client sends auth and lease fencing headers without argv", async () => {
  const temp = await mkdtemp(join(tmpdir(), "kaneo-mcp-client-"));
  const secretPath = join(temp, "kaneo.env");
  const seen: { authorization?: string; leaseToken?: string; idempotency?: string; body?: string } = {};
  const server = createServer((request, response) => {
    seen.authorization = request.headers.authorization;
    seen.leaseToken = request.headers["x-kaneo-lease-token"] as string | undefined;
    seen.idempotency = request.headers["idempotency-key"] as string | undefined;
    let body = "";
    request.on("data", (chunk) => { body += chunk; });
    request.on("end", () => {
      seen.body = body;
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ id: "run-123", taskId: "task-123", leaseEpoch: 2, leaseActive: true }));
    });
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.equal(typeof address, "object");
  if (!address || typeof address === "string") throw new Error("test server did not bind");

  await writeFile(
    secretPath,
    `KANEO_API_KEY=api-key-never-in-argv\nKANEO_ENDPOINT=http://127.0.0.1:${address.port}\n`,
    { encoding: "utf8", mode: 0o600 },
  );
  const previousSecretPath = process.env.KANEO_SECRET_PATH;
  process.env.KANEO_SECRET_PATH = secretPath;
  try {
    const result = await heartbeatTaskRun(
      "task-123",
      "run-123",
      2,
      "lease-token-never-in-argv",
      "execution-heartbeat-test",
    );
    assert.equal(result.leaseEpoch, 2);
    assert.equal(seen.authorization, "Bearer api-key-never-in-argv");
    assert.equal(seen.leaseToken, "lease-token-never-in-argv");
    assert.equal(seen.idempotency, "execution-heartbeat-test");
    assert.deepEqual(JSON.parse(seen.body ?? "{}"), { leaseEpoch: 2 });

    const checkpoint = await createTaskRunCheckpoint(
      "task-123",
      "run-123",
      2,
      "lease-token-never-in-argv",
      {
        baseSha: "a".repeat(40),
        headSha: "b".repeat(40),
        commitSha: "b".repeat(40),
        guardReceipt: {
          receiptId: "receipt-1",
          remoteRef: "pi-laptop/task-123-run-123-fix",
          headSha: "b".repeat(40),
          commitSha: "b".repeat(40),
          receiptHash: "c".repeat(64),
        },
        verifyResult: { phase: "implementation" },
      },
      "execution-checkpoint-test",
    );
    assert.equal(checkpoint.leaseEpoch, 2);
    assert.equal(seen.leaseToken, "lease-token-never-in-argv");
    assert.equal(seen.idempotency, "execution-checkpoint-test");
    assert.deepEqual(JSON.parse(seen.body ?? "{}"), {
      baseSha: "a".repeat(40),
      headSha: "b".repeat(40),
      commitSha: "b".repeat(40),
      guardReceipt: {
        receiptId: "receipt-1",
        remoteRef: "pi-laptop/task-123-run-123-fix",
        headSha: "b".repeat(40),
        commitSha: "b".repeat(40),
        receiptHash: "c".repeat(64),
      },
      verifyResult: { phase: "implementation" },
      leaseEpoch: 2,
    });

    await reviewTaskRun(
      "task-123",
      "run-123",
      {
        decision: "reject",
        reason: "fixture rejection",
        reviewHeadSha: "a".repeat(40),
      },
      "execution-review-test",
    );
    assert.equal(seen.authorization, "Bearer api-key-never-in-argv");
    assert.equal(seen.leaseToken, undefined);
    assert.equal(seen.idempotency, "execution-review-test");
    assert.deepEqual(JSON.parse(seen.body ?? "{}"), {
      decision: "reject",
      reason: "fixture rejection",
      reviewHeadSha: "a".repeat(40),
    });
  } finally {
    if (previousSecretPath === undefined) delete process.env.KANEO_SECRET_PATH;
    else process.env.KANEO_SECRET_PATH = previousSecretPath;
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    await unlink(secretPath);
  }
});
