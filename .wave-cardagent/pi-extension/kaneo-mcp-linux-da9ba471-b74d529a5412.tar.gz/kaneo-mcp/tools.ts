// Tool schema table for the kaneo-mcp extension.
// Each entry mirrors the reviewed Kaneo MCP input schema (apps/api/src/mcp/tools.ts)
// so the LLM sees the same contract whether it calls via TelePi or this extension.
// Schemas intentionally stay permissive for server-validated enums (priority,
// status) because Kaneo is the single source of truth and rejects bad values.
import { Type, type TSchema } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";

const Req = (description?: string): TSchema => Type.String({ minLength: 1, description });
const Opt = <T extends TSchema>(schema: T): T => Type.Optional(schema);

export interface KaneoToolSpec {
  name: string;
  description: string;
  params: TSchema;
}

const relationType = StringEnum(["subtask", "blocks", "related"] as const, {
  description: "'subtask' (source is parent, target child), 'blocks' (source blocks target), or 'related' (bidirectional)",
});

export const KANEO_TOOLS: KaneoToolSpec[] = [
  {
    name: "whoami",
    description: "Return the current Kaneo session and signed-in user.",
    params: Type.Object({}),
  },
  {
    name: "list_workspaces",
    description: "List workspaces the signed-in user can access.",
    params: Type.Object({}),
  },
  {
    name: "list_projects",
    description: "List projects in a workspace (optionally include archived).",
    params: Type.Object({
      workspaceId: Req("Workspace ID"),
      includeArchived: Opt(Type.Boolean({ description: "Include archived projects" })),
    }),
  },
  {
    name: "get_project",
    description: "Get a single project by ID.",
    params: Type.Object({ id: Req("Project ID") }),
  },
  {
    name: "create_project",
    description: "Create a project in a workspace.",
    params: Type.Object({
      name: Req("Project name"),
      workspaceId: Req("Workspace ID"),
      icon: Req("Icon name (Kaneo icon set, e.g. 'Layout')"),
      slug: Req("URL-safe slug"),
    }),
  },
  {
    name: "update_project",
    description: "Update project metadata (PATCH-style: only provided fields change).",
    params: Type.Object({
      id: Req("Project ID"),
      name: Opt(Req()),
      icon: Opt(Type.String()),
      slug: Opt(Type.String()),
      description: Opt(Type.String()),
      isPublic: Opt(Type.Boolean()),
    }),
  },
  {
    name: "list_tasks",
    description: "List tasks for a project, optionally filtered/sorted/paginated.",
    params: Type.Object({
      projectId: Req("Project ID"),
      status: Opt(Type.String({ description: "Status column name" })),
      priority: Opt(Type.String({ description: "Priority value (server-validated)" })),
      assigneeId: Opt(Type.String()),
      page: Opt(Type.Integer({ minimum: 1 })),
      limit: Opt(Type.Integer({ minimum: 1 })),
      sortBy: Opt(StringEnum(["createdAt", "priority", "dueDate", "position", "title", "number"] as const)),
      sortOrder: Opt(StringEnum(["asc", "desc"] as const)),
      dueBefore: Opt(Type.String({ description: "ISO date-time" })),
      dueAfter: Opt(Type.String({ description: "ISO date-time" })),
    }),
  },
  {
    name: "get_task",
    description: "Get a single task by ID.",
    params: Type.Object({ taskId: Req("Task ID") }),
  },
  {
    name: "create_task",
    description: "Create a task in a project.",
    params: Type.Object({
      projectId: Req("Project ID"),
      title: Req("Task title"),
      description: Type.String({ description: "Task description (markdown). Empty string is allowed." }),
      priority: Req("Priority value (server-validated, e.g. 'low'|'medium'|'high'|'urgent')"),
      status: Req("Status column name (must exist in the project)"),
      startDate: Opt(Type.String({ description: "ISO date-time" })),
      dueDate: Opt(Type.String({ description: "ISO date-time" })),
      userId: Opt(Type.String({ description: "Assignee user ID" })),
    }),
  },
  {
    name: "update_task",
    description: "Update a task (merges with current task then full update).",
    params: Type.Object({
      taskId: Req("Task ID"),
      title: Opt(Type.String()),
      description: Opt(Type.Union([Type.String(), Type.Null()])),
      status: Opt(Type.String()),
      priority: Opt(Type.String()),
      projectId: Opt(Type.String({ description: "Use move_task to change project; this field only re-anchors the task" })),
      position: Opt(Type.Number()),
      startDate: Opt(Type.Union([Type.String(), Type.Null()])),
      dueDate: Opt(Type.Union([Type.String(), Type.Null()])),
      userId: Opt(Type.Union([Type.String(), Type.Null()])),
    }),
  },
  {
    name: "move_task",
    description: "Move a task to another project (and optional destination status).",
    params: Type.Object({
      taskId: Req("Task ID"),
      destinationProjectId: Req("Destination project ID"),
      destinationStatus: Opt(Type.String({ description: "Status column in the destination project" })),
    }),
  },
  {
    name: "update_task_status",
    description: "Update only the status (column) of a task.",
    params: Type.Object({
      taskId: Req("Task ID"),
      status: Req("New status column name"),
    }),
  },
  {
    name: "list_task_comments",
    description: "List comments on a task.",
    params: Type.Object({ taskId: Req("Task ID") }),
  },
  {
    name: "create_task_comment",
    description: "Add a comment to a task.",
    params: Type.Object({
      taskId: Req("Task ID"),
      content: Req("Comment content (markdown)"),
    }),
  },
  {
    name: "update_task_comment",
    description: "Update one of your own comments on a task.",
    params: Type.Object({
      commentId: Req("Comment ID"),
      content: Req("New comment content (markdown)"),
    }),
  },
  {
    name: "delete_task_comment",
    description: "Delete one of your own comments from a task.",
    params: Type.Object({ commentId: Req("Comment ID") }),
  },
  {
    name: "list_workspace_labels",
    description: "List labels defined in a workspace.",
    params: Type.Object({ workspaceId: Req("Workspace ID") }),
  },
  {
    name: "create_label",
    description: "Create a label in a workspace (optionally attach to a task).",
    params: Type.Object({
      name: Req("Label name"),
      color: Req("Hex color, e.g. '#3b82f6'"),
      workspaceId: Req("Workspace ID"),
      taskId: Opt(Type.String({ description: "If provided, attach the new label to this task" })),
    }),
  },
  {
    name: "attach_label_to_task",
    description: "Attach an existing label to a task.",
    params: Type.Object({
      labelId: Req("Label ID"),
      taskId: Req("Task ID"),
    }),
  },
  {
    name: "detach_label_from_task",
    description: "Detach a label from its current task.",
    params: Type.Object({ labelId: Req("Label ID") }),
  },
  {
    name: "create_task_relation",
    description: "Create a relation between two tasks.",
    params: Type.Object({
      sourceTaskId: Req("Source task ID"),
      targetTaskId: Req("Target task ID"),
      relationType,
    }),
  },
  {
    name: "get_task_relations",
    description: "List all relations (subtask/blocks/related) involving a task.",
    params: Type.Object({ taskId: Req("Task ID") }),
  },
  {
    name: "delete_task_relation",
    description: "Delete a task relation by its relation ID.",
    params: Type.Object({ id: Req("Relation ID") }),
  },
  {
    name: "delete_label",
    description:
      "Delete a label by ID. Only task-associated labels can be deleted; workspace-level labels are rejected by the API.",
    params: Type.Object({ id: Req("Label ID") }),
  },
];
