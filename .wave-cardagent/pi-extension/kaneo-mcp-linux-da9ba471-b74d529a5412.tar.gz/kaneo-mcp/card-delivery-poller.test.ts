import assert from "node:assert/strict";
import test from "node:test";
import {
  formatBoundCommentMessage,
  runBoundDeliveryPoller,
  type BoundDelivery,
  type DeliveryBinding,
} from "./card-delivery-poller.ts";

const binding: DeliveryBinding = {
  bindingId: "binding-1",
  bindingGeneration: 3,
  sessionId: "pi-session-1",
  hostId: "pi-prodesk",
  taskId: "task-root",
};

const delivery: BoundDelivery = {
  deliveryId: "delivery-1",
  bindingId: binding.bindingId,
  bindingGeneration: binding.bindingGeneration,
  sessionId: binding.sessionId,
  hostId: binding.hostId,
  commentId: "comment-1",
  content: "Please review this change.",
  attachmentAssetIds: ["asset-1"],
};

test("forwarded comment is bounded as untrusted context with attachment IDs", () => {
  const message = formatBoundCommentMessage(binding, delivery);
  assert.match(message, /explicitly sent this existing Kaneo comment/);
  assert.match(message, /untrusted discussion context/);
  assert.match(message, /Please review this change/);
  assert.match(message, /asset-1/);
  assert.match(message, /task-root/);
});

test("claim sends a steer to the exact binding and acks enqueued, not read", async () => {
  const abort = new AbortController();
  const calls: Array<{ path: string; options?: unknown }> = [];
  const messages: Array<{ message: unknown; options: unknown }> = [];
  await runBoundDeliveryPoller({
    binding,
    signal: abort.signal,
    callApi: async <T>(path: string, options?: unknown) => {
      calls.push({ path, options });
      if (path.includes("/claim?")) {
        return { delivery } as T;
      }
      if (path.endsWith("/ack")) {
        abort.abort();
        return { receipt: { state: "enqueued" } } as T;
      }
      throw new Error(`unexpected ${path}`);
    },
    sendMessage: (message, options) => messages.push({ message, options }),
  });
  assert.equal(messages.length, 1);
  assert.deepEqual(messages[0]?.options, {
    triggerTurn: true,
    deliverAs: "steer",
  });
  assert.equal(calls.length, 2);
  assert.equal(calls[1]?.path.endsWith("/ack"), true);
  assert.deepEqual((calls[1]?.options as { body: unknown }).body, {
    sessionId: binding.sessionId,
    generation: binding.bindingGeneration,
    outcome: "enqueued",
  });
});

test("mismatched generation is stale and never steers or acks", async () => {
  const abort = new AbortController();
  let sent = false;
  let stale = false;
  const callPaths: string[] = [];
  await runBoundDeliveryPoller({
    binding,
    signal: abort.signal,
    callApi: async <T>(path: string) => {
      callPaths.push(path);
      return {
        delivery: { ...delivery, bindingGeneration: 4 },
      } as T;
    },
    sendMessage: () => {
      sent = true;
    },
    onStale: () => {
      stale = true;
      abort.abort();
    },
  });
  assert.equal(stale, true);
  assert.equal(sent, false);
  assert.equal(callPaths.length, 1);
});

test("a failed steer is acked failed_before_send; an ack loss never replays the comment", async () => {
  const abort = new AbortController();
  const failedOutcomes: string[] = [];
  let sendAttempts = 0;
  await runBoundDeliveryPoller({
    binding,
    signal: abort.signal,
    callApi: async <T>(path: string, options?: unknown) => {
      if (path.includes("/claim?")) return { delivery } as T;
      failedOutcomes.push(
        String((options as { body: { outcome: string } }).body.outcome),
      );
      abort.abort();
      return {} as T;
    },
    sendMessage: () => {
      sendAttempts += 1;
      throw new Error("Pi queue rejected before send");
    },
  });
  assert.equal(sendAttempts, 1);
  assert.deepEqual(failedOutcomes, ["failed_before_send"]);

  const ackAbort = new AbortController();
  let claimCount = 0;
  let sendCount = 0;
  await runBoundDeliveryPoller({
    binding,
    signal: ackAbort.signal,
    callApi: async <T>(path: string) => {
      if (path.includes("/claim?")) {
        claimCount += 1;
        if (claimCount === 1) return { delivery } as T;
        ackAbort.abort();
        return { delivery: null } as T;
      }
      throw new Error("ack network loss");
    },
    sendMessage: () => {
      sendCount += 1;
    },
  });
  assert.equal(sendCount, 1);
  // The next poll may happen, but the server does not requeue a claimed
  // delivery; the same comment is never steered a second time.
  assert.equal(claimCount, 2);
});
