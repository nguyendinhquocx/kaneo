import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { StringEnum } from "@earendil-works/pi-ai";
import { Type } from "typebox";
import {
  cancelExecutionSchedule,
  createExecutionSchedule,
  getChainPaused,
  getFullRunGraphByRequest,
  getKaneoTask,
  readyFullRunGraph,
  resumeChainSchedules,
  resumeRunAttempt,
  setChainPaused,
  updateExecutionSchedule,
  buildFullRunDescription,
  publishFullRunGraph,
  type FullRunGraphPublishBody,
} from "./kaneo-client.ts";
import type { WorkerContractCheck } from "./execution-schedule.ts";
import {
  buildSchedulePlan,
  buildSchedulePreviewText,
  confirmSchedulePlan,
  parseWorkerContract,
  SCHEDULE_TOOL_NAME,
} from "./execution-schedule.ts";
import { KaneoExecutionRuntime } from "./execution-runtime.ts";
import {
  PHASE_FAILURE_KINDS,
  validatePhaseProgressArgs,
} from "./execution-runtime.ts";

const MAX_TOOL_OUTPUT_BYTES = 48 * 1024;

function formatToolText(value: unknown): string {
  const text = JSON.stringify(value, null, 2);
  if (Buffer.byteLength(text, "utf8") <= MAX_TOOL_OUTPUT_BYTES) return text;
  return `${text.slice(0, MAX_TOOL_OUTPUT_BYTES - 80)}\n… [output truncated by kaneo execution tool]`;
}

export function registerExecutionTools(
  pi: ExtensionAPI,
  runtime: KaneoExecutionRuntime | (() => KaneoExecutionRuntime),
): void {
  const getRuntime = typeof runtime === "function" ? runtime : () => runtime;
  pi.registerTool({
    name: "kaneo_get_execution_context",
    label: "Kaneo execution context",
    description: "Read a task's durable execution context: task/spec, project manifest, trusted agents, runs, and the host-local checkout binding. Does not claim or mutate a run.",
    promptSnippet: "Read Kaneo task execution context before starting worker work",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID" }),
      projectId: Type.Optional(Type.String({ minLength: 1, description: "Optional expected project ID; server task mapping remains authoritative" })),
    }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string; projectId?: string };
      const result = await getRuntime().getContext(input.taskId, input.projectId, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "get_execution_context", ok: true, taskId: input.taskId } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_claim_task_run",
    label: "Kaneo claim task run",
    description: "Claim one durable worker lease using this machine's configured server-side agent principal and host binding. The model cannot supply agent identity, host identity, lease token, branch, or local path.",
    promptSnippet: "Claim a Kaneo worker lease only after reading execution context",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID" }),
      scope: Type.Array(Type.String({ minLength: 1 }), { minItems: 1, maxItems: 100, description: "Explicit relative paths this run may change; '*' and traversal are rejected" }),
    }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string; scope: string[] };
      const result = await getRuntime().claim(input.taskId, input.scope, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "claim_task_run", ok: true, taskId: input.taskId, runId: result.id, leaseTokenReturned: false } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_prepare_task_checkout",
    label: "Kaneo prepare task checkout",
    description: "Use the host-local Git guard to inspect the allowlisted checkout, fetch remotes, and create the server-issued task branch from the manifest base branch. No arbitrary repository path or branch is accepted.",
    promptSnippet: "Fetch and create the guarded Kaneo task branch for the active lease",
    parameters: Type.Object({ taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }) }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string };
      const result = await getRuntime().prepareCheckout(input.taskId, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "prepare_task_checkout", ok: true, taskId: input.taskId, runId: result.run.id, branch: result.currentBranch } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_commit_task_branch",
    label: "Kaneo commit task branch",
    description:
      "Commit the active task branch through the source-owned Git guard. The extension writes short-lived 0600 credential files internally and fences the commit against the current server lease; lease credentials never reach the model.",
    promptSnippet:
      "Commit only the active Kaneo task scope through the fenced Git guard; do not use generic git commit",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }),
      message: Type.String({ minLength: 1, maxLength: 500, description: "Commit message; it must include the Kaneo task ID" }),
    }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string; message: string };
      const result = await getRuntime().commitTaskBranch(input.taskId, input.message, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: {
          kaneo: {
            tool: "commit_task_branch",
            ok: true,
            taskId: input.taskId,
            runId: result.run.id,
            commitSha: result.commitSha,
            changedFiles: result.changedFiles,
          },
        },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_push_task_branch",
    label: "Kaneo push task branch",
    description:
      "Push the active task branch through the source-owned Git guard. The push is fenced against the current server lease and never uses force push; lease credentials stay inside the extension.",
    promptSnippet:
      "Push the active Kaneo task branch through the fenced Git guard; do not use generic git push",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }),
    }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string };
      const result = await getRuntime().pushTaskBranch(input.taskId, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: {
          kaneo: {
            tool: "push_task_branch",
            ok: true,
            taskId: input.taskId,
            runId: result.run.id,
            commitSha: result.commitSha,
            changedFiles: result.changedFiles,
            ...(result.guardReceipt ? { guardReceipt: result.guardReceipt } : {}),
          },
        },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_checkpoint_task_run",
    label: "Kaneo durable task checkpoint",
    description:
      "Commit and push the active Kaneo task branch through the fenced Git guard, record a durable checkpoint with the verified remote HEAD, add one bounded milestone comment, and emit the checkpoint notification. For a retry after a network error, pass the exact headSha, commitSha and guardReceipt returned by the first attempt.",
    promptSnippet:
      "Create a durable Kaneo checkpoint: commit, push, verify remote HEAD, comment milestone and notify Telegram",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }),
      message: Type.Optional(Type.String({ minLength: 1, maxLength: 500, description: "Commit message for a new checkpoint; must include the task ID" })),
      baseSha: Type.Optional(Type.String({ minLength: 40, maxLength: 40 })),
      headSha: Type.Optional(Type.String({ minLength: 40, maxLength: 40 })),
      commitSha: Type.Optional(Type.String({ minLength: 40, maxLength: 40 })),
      guardReceipt: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
      commands: Type.Optional(Type.Array(Type.String({ maxLength: 500 }), { maxItems: 100 })),
      artifactHashes: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
      verifyResult: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
    }),
    async execute(_id, params, signal) {
      const input = params as Record<string, unknown> & { taskId: string };
      const { taskId, ...checkpointInput } = input;
      const result = await getRuntime().checkpointTaskRun(taskId, checkpointInput, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: {
          kaneo: {
            tool: "checkpoint_task_run",
            ok: true,
            taskId,
            runId: result.run.id,
            state: result.run.state,
            branch: result.branch,
            commitSha: result.commitSha,
            commentCreated: result.commentCreated,
          },
        },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_heartbeat_task_run",
    label: "Kaneo heartbeat task run",
    description: "Renew the current in-memory worker lease. The lease token stays inside the extension and is never returned to the model.",
    promptSnippet: "Renew the current Kaneo worker lease",
    parameters: Type.Object({ taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }) }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string };
      const result = await getRuntime().heartbeat(input.taskId, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "heartbeat_task_run", ok: true, taskId: input.taskId, runId: result.id } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_report_task_run",
    label: "Kaneo report task run",
    description: "Append worker evidence and report in_progress, in_review, blocked_* or failed with a failureKind. Only the parent review gate can finalize/reject; lease credentials are internal.",
    promptSnippet: "Report bounded Kaneo worker evidence without finalizing the task",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }),
      state: StringEnum([
        "in_progress",
        "in_review",
        "blocked_quota",
        "blocked_input",
        "blocked_clarification",
        "blocked_branch_drift",
        "failed",
      ] as const),
      baseSha: Type.Optional(Type.String({ minLength: 7, maxLength: 64 })),
      commitSha: Type.Optional(Type.String({ minLength: 7, maxLength: 64 })),
      prNumber: Type.Optional(Type.Integer({ minimum: 1 })),
      prUrl: Type.Optional(Type.String({ maxLength: 2048 })),
      prState: Type.Optional(Type.String({ maxLength: 64 })),
      evidence: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
      blocker: Type.Optional(Type.String({ maxLength: 4000 })),
      nextAction: Type.Optional(Type.String({ maxLength: 4000 })),
    }),
    async execute(_id, params, signal) {
      const input = params as Record<string, unknown> & { taskId: string; state: string };
      const { taskId, ...reportInput } = input;
      const result = await getRuntime().report(taskId, reportInput, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "report_task_run", ok: true, taskId, runId: result.id, state: result.state } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_get_task_review",
    label: "Kaneo task review evidence",
    description: "Read one worker run and its append-only evidence for parent review. This is read-only and never returns a lease token.",
    promptSnippet: "Read the exact Kaneo run/evidence bundle before approving or rejecting it",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID" }),
      runId: Type.String({ minLength: 1, description: "Kaneo worker run ID" }),
    }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string; runId: string };
      const result = await getRuntime().getReview(input.taskId, input.runId, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "get_task_review", ok: true, taskId: input.taskId, runId: input.runId } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_review_task_run",
    label: "Kaneo parent review task run",
    description: "Run the guarded parent diff review, then approve/reject through Kaneo. Approval requires parent-supplied passing test evidence; create_pr records an open PR and merge requires a passing reviewed host adapter plus manifest policy.",
    promptSnippet: "Review a worker run with independent diff/scope checks before finalization",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID" }),
      runId: Type.String({ minLength: 1, description: "Kaneo worker run ID" }),
      decision: StringEnum(["approve", "reject"] as const),
      action: Type.Optional(StringEnum(["none", "create_pr", "merge"] as const)),
      reason: Type.Optional(Type.String({ maxLength: 4000 })),
      testsPassed: Type.Optional(Type.Boolean()),
      testCommands: Type.Optional(Type.Array(Type.String({ minLength: 1, maxLength: 500 }), { minItems: 1, maxItems: 100 })),
    }),
    async execute(_id, params, signal) {
      const input = params as Record<string, unknown> & { taskId: string; runId: string; decision: string };
      const { taskId, runId, ...reviewInput } = input;
      const result = await getRuntime().review(taskId, runId, reviewInput, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "review_task_run", ok: true, taskId, runId, state: result.run.state } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_release_task_run",
    label: "Kaneo release task run",
    description: "Release the current worker lease as blocked_*/failed/cancelled/superseded/orphaned/in_progress/in_review. Never finalizes or rejects a run; lease credentials are internal.",
    promptSnippet: "Release the current Kaneo worker lease without finalizing it",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID of the active lease" }),
      state: Type.Optional(
        StringEnum([
          "blocked_quota",
          "blocked_input",
          "blocked_clarification",
          "blocked_branch_drift",
          "failed",
          "cancelled",
          "superseded",
          "orphaned",
          "in_progress",
          "in_review",
        ] as const),
      ),
    }),
    async execute(_id, params, signal) {
      const input = params as { taskId: string; state?: string };
      const result = await getRuntime().release(input.taskId, input.state, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText(result) }],
        details: { kaneo: { tool: "release_task_run", ok: true, taskId: input.taskId, runId: result.id, state: result.state } },
      };
    },
  });

  // SPEC-kaneo-native-telegram-control-v0-1 (T2): fixed parent-only tool.
  // Two-phase: a call without confirm=true only returns the preview + planHash
  // (no mutation); confirmation requires the same planHash plus the current
  // task revision, so any drift between preview and execute is rejected.
  pi.registerTool({
    name: "kaneo_update_execution_schedule",
    label: "Kaneo update schedule (CAS)",
    description: "Parent-only: update a PENDING schedule (notBefore/model/maxRuntime/notification/quotaResume) with expectedScheduleRevision CAS. Already-dispatched schedules are immutable (409 schedule_already_dispatched_use_run_control).",
    promptSnippet: "Update a pending Kaneo schedule with CAS revision",
    parameters: Type.Object({
      scheduleId: Type.String({ minLength: 1 }),
      expectedScheduleRevision: Type.Number({ minimum: 1 }),
      notBefore: Type.Optional(Type.String({ description: "ISO with Z/offset" })),
      preferredModel: Type.Optional(Type.Union([Type.String(), Type.Null()])), // typebox 1.x: Type.Nullable da bi xoa
      maxRuntimeSeconds: Type.Optional(Type.Number()),
      notificationRoute: Type.Optional(Type.String()),
      telegramQuotaResume: Type.Optional(Type.String()),
      planHash: Type.Optional(Type.String()),
      enabled: Type.Optional(Type.Boolean({ description: "false pauses the pending schedule (nextDispatchAt parked); true re-arms it" })),
    }),
    async execute(_id, params, signal) {
      const input = params as Record<string, unknown> & { scheduleId: string; expectedScheduleRevision: number };
      const { scheduleId, expectedScheduleRevision, ...patch } = input;
      const patchBody = Object.fromEntries(
        Object.entries(patch).filter(([, value]) => value !== undefined),
      );
      const updated = await updateExecutionSchedule(
        scheduleId,
        { expectedScheduleRevision, ...patchBody },
        signal,
      );
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, scheduleId, scheduleRevision: updated.scheduleRevision }) }],
        details: { kaneo: { tool: "update_execution_schedule", ok: true, scheduleId, scheduleRevision: updated.scheduleRevision } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_chain_control",
    label: "Kaneo chain pause/resume",
    description:
      "Parent-only: pause or re-kick the auto-chain pipeline. pause sets the global chain_paused kill-switch (already-scheduled nodes still dispatch, no NEW chain schedules); resume clears the flag and creates schedules for dependants whose blockers are all done; status reports the flag. Requires projectId for resume.",
    promptSnippet: "Pause or re-kick the Kaneo auto-chain",
    parameters: Type.Object({
      action: StringEnum(["pause", "resume", "status"] as const),
      projectId: Type.Optional(
        Type.String({ minLength: 1, description: "Project to re-kick (required for resume)" }),
      ),
    }),
    async execute(_id, params, signal) {
      const input = params as { action: "pause" | "resume" | "status"; projectId?: string };
      if (input.action === "pause") {
        const flag = await setChainPaused(true, signal);
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, chainPaused: flag.enabled }) }],
          details: { kaneo: { tool: "chain_control", ok: true, action: "pause", chainPaused: flag.enabled, scheduledTaskIds: [] as string[] } },
        };
      }
      if (input.action === "resume") {
        if (!input.projectId) {
          return {
            content: [{ type: "text" as const, text: formatToolText({ ok: false, error: "resume requires projectId" }) }],
            details: { kaneo: { tool: "chain_control", ok: false, action: "resume", chainPaused: true, scheduledTaskIds: [] as string[] } },
          };
        }
        const flag = await setChainPaused(false, signal);
        const result = await resumeChainSchedules(input.projectId, signal);
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, chainPaused: flag.enabled, scheduledTaskIds: result.scheduledTaskIds }) }],
          details: { kaneo: { tool: "chain_control", ok: true, action: "resume", chainPaused: flag.enabled, scheduledTaskIds: result.scheduledTaskIds } },
        };
      }
      const chainPaused = await getChainPaused(signal);
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, chainPaused }) }],
        details: { kaneo: { tool: "chain_control", ok: true, action: "status", chainPaused, scheduledTaskIds: [] as string[] } },
      };
    },
  });

  pi.registerTool({
    name: "kaneo_cancel_execution_schedule",
    label: "Kaneo cancel schedule (CAS)",
    description: "Parent-only: cancel a PENDING schedule idempotently with expectedScheduleRevision CAS. 409 schedule_already_dispatched_use_run_control when already dispatched — use run control instead.",
    promptSnippet: "Cancel a pending Kaneo schedule with CAS revision",
    parameters: Type.Object({
      scheduleId: Type.String({ minLength: 1 }),
      expectedScheduleRevision: Type.Number({ minimum: 1 }),
    }),
    async execute(_id, params, signal) {
      const input = params as { scheduleId: string; expectedScheduleRevision: number };
      const cancelled = await cancelExecutionSchedule(
        input.scheduleId,
        { expectedScheduleRevision: input.expectedScheduleRevision },
        signal,
      );
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, scheduleId: input.scheduleId, scheduleRevision: cancelled.scheduleRevision }) }],
        details: { kaneo: { tool: "cancel_execution_schedule", ok: true, scheduleId: input.scheduleId, scheduleRevision: cancelled.scheduleRevision } },
      };
    },
  });

  pi.registerTool<any, any>({
    name: "kaneo_resume_task_run",
    label: "Kaneo resume task run",
    description: "Parent-only: create a new fenced attempt from a blocked/stale run, optionally with a different model and a bounded contextNote. The old lease epoch is revoked; the new attempt links back via parentRunId.",
    promptSnippet: "Resume a blocked Kaneo run with a new model/context",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1 }),
      runId: Type.String({ minLength: 1 }),
      preferredModel: Type.Optional(Type.String({ description: "Exact worker model id from the manifest allowlist" })),
      contextNote: Type.Optional(Type.String({ maxLength: 2000, description: "Bounded untrusted note injected as the first worker message; cannot override the contract" })),
    }),
    async execute(_id, params, signal) {
      const input = params as {
        taskId: string;
        runId: string;
        preferredModel?: string;
        contextNote?: string;
      };
      const config = await getRuntime().getConfig();
      if (!config?.agentPrincipalId) {
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason: "resume requires a configured agent principal on this host" }) }],
          details: { kaneo: { tool: "resume_task_run", ok: false } },
        };
      }
      // SPEC-kaneo-phase-cards-full-run: deterministic resume key — the runtime
      // GETs the run to read the current epoch + latest checkpoint; empty
      // segments collapse to `none`. Never Date.now().
      const requestKey = await getRuntime().buildResumeRequestKey(input.taskId, input.runId, signal);
      const run = await resumeRunAttempt(
        input.taskId,
        input.runId,
        {
          agentPrincipalId: config.agentPrincipalId,
          preferredModel: input.preferredModel ?? undefined,
          initiatedBy: "parent",
          contextNote: input.contextNote ?? undefined,
        },
        requestKey,
        signal,
      );
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, runId: run.id, parentRunId: input.runId, state: run.state, requestKey }) }],
        details: { kaneo: { tool: "resume_task_run", ok: true, taskId: input.taskId, runId: run.id, parentRunId: input.runId, requestKey } },
      };
    },
  });

  // SPEC-kaneo-phase-cards-full-run-runtime-v0-1: fenced phase-progress
  // operation. Model-facing args are ONLY taskId/phaseId/action (+ checkpointId
  // for complete, failureKind/reason/retryAt for block). runId, leaseEpoch,
  // lease token, status strings, markers and free hashes are runtime-derived
  // or forbidden — validatePhaseProgressArgs fails closed on any of them.
  pi.registerTool({
    name: "kaneo_phase_progress",
    label: "Kaneo phase progress (fenced)",
    description: "FULL-run phase ledger operation: get (map+ledger snapshot), begin, complete (requires checkpointId), block (requires failureKind; atomic blocker+release). The runtime derives runId, leaseEpoch and the lease token from the active lease; never pass or compute hashes yourself.",
    promptSnippet: "Drive FULL-run phase state: get ledger, begin phase, complete with checkpoint proof, or block atomically",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "FULL task ID of the active lease" }),
      phaseId: Type.String({ minLength: 2, maxLength: 8, description: "Phase ID from the ledger map, e.g. P1" }),
      action: StringEnum(["get", "begin", "complete", "block"] as const),
      checkpointId: Type.Optional(Type.String({ minLength: 1, maxLength: 128, description: "Required for action=complete — checkpointId from kaneo_phase_checkpoint" })),
      failureKind: Type.Optional(StringEnum(PHASE_FAILURE_KINDS, { description: "Required for action=block" })),
      reason: Type.Optional(Type.String({ maxLength: 4000, description: "block only: bounded human-readable blocker" })),
      retryAt: Type.Optional(Type.String({ maxLength: 64, description: "block only: proposed ISO retry time" })),
    }),
    async execute(_id, params, signal) {
      const input = params as Record<string, unknown>;
      const check = validatePhaseProgressArgs(input);
      if (!check.ok || !check.taskId || !check.phaseId || !check.action) {
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason: check.reason ?? "invalid_phase_progress_args" }) }],
          details: { kaneo: { tool: "phase_progress", ok: false, reason: check.reason } },
        };
      }
      const runtime = getRuntime();
      const taskId = check.taskId;
      if (check.action === "get") {
        const snapshot = await runtime.getPhaseLedger(taskId, signal);
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, snapshot }) }],
          details: { kaneo: { tool: "phase_progress", ok: true, taskId, action: "get" } },
        };
      }
      if (check.action === "begin") {
        const snapshot = await runtime.beginPhase(taskId, check.phaseId, signal);
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, snapshot }) }],
          details: { kaneo: { tool: "phase_progress", ok: true, taskId, action: "begin", phaseId: check.phaseId } },
        };
      }
      if (check.action === "complete") {
        const snapshot = await runtime.completePhase(taskId, check.phaseId, check.checkpointId!, signal);
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, snapshot }) }],
          details: { kaneo: { tool: "phase_progress", ok: true, taskId, action: "complete", phaseId: check.phaseId, checkpointId: check.checkpointId } },
        };
      }
      const snapshot = await runtime.blockPhase(taskId, check.phaseId, check.failureKind!, check.reason, check.retryAt, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, snapshot }) }],
        details: { kaneo: { tool: "phase_progress", ok: true, taskId, action: "block", phaseId: check.phaseId, failureKind: check.failureKind } },
      };
    },
  });

  // Dedicated fenced phase checkpoint. Model supplies structured phase proof
  // (phaseId, headSha, commitSha, guardReceipt, commands, artifactHashes); the
  // runtime adds lease epoch/token and spec/source-map hashes from the map
  // snapshot. The response — fresh or stored replay — always exposes
  // checkpointId, which kaneo_phase_progress(action=complete) consumes.
  pi.registerTool({
    name: "kaneo_phase_checkpoint",
    label: "Kaneo phase checkpoint (fenced)",
    description: "Record a durable FULL-run phase checkpoint on the dedicated fenced route after commit+push. Requires phaseId, headSha, commitSha, baseSha and the push guardReceipt; returns checkpointId. Do not pass spec/map hashes — the runtime binds them from the phase ledger snapshot.",
    promptSnippet: "Record the fenced FULL-run phase checkpoint, then complete the phase with the returned checkpointId",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "FULL task ID of the active lease" }),
      phaseId: Type.String({ minLength: 2, maxLength: 8, description: "Phase ID, e.g. P1" }),
      headSha: Type.String({ minLength: 40, maxLength: 40 }),
      commitSha: Type.String({ minLength: 40, maxLength: 40 }),
      baseSha: Type.Optional(Type.String({ minLength: 40, maxLength: 40 })),
      guardReceipt: Type.Record(Type.String(), Type.Unknown()),
      commands: Type.Optional(Type.Array(Type.String({ maxLength: 500 }), { maxItems: 100 })),
      artifactHashes: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
    }),
    async execute(_id, params, signal) {
      const input = params as Record<string, unknown> & { taskId: string };
      const { taskId, ...checkpointInput } = input;
      const record = await getRuntime().createPhaseCheckpoint(taskId, checkpointInput, signal);
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, checkpointId: record.checkpointId, checkpoint: record }) }],
        details: {
          kaneo: {
            tool: "phase_checkpoint",
            ok: true,
            taskId,
            phaseId: checkpointInput.phaseId,
            checkpointId: record.checkpointId,
            commitSha: checkpointInput.commitSha,
          },
        },
      };
    },
  });

  // Parent graph publish: ONE server operation with receipt reconcile. No
  // generic create-task/create-relation fallback. Response-loss retries read
  // the stored receipt by graphId or by-request (requestKey = idempotency key).
  pi.registerTool({
    name: "kaneo_publish_full_run_graph",
    label: "Kaneo publish full-run graph",
    description: "Parent-only: publish the FULL + phase-card graph in one server operation. Requires the deterministic preview fields (planHash/changeSetId/spec hashes/expected project revision). On network loss, reconciles via GET by graphId or requestKey instead of recreating cards. No generic task-creation fallback.",
    promptSnippet: "Publish the FULL-run graph (1 FULL + N phase cards) from the /add-kaneo preview, then ready-CAS it",
    parameters: Type.Object({
      projectId: Type.String({ minLength: 1 }),
      planHash: Type.String({ minLength: 16, maxLength: 128 }),
      expectedProjectRevision: Type.Number({ minimum: 1, description: "Server-read project revision; never a placeholder" }),
      changeSetId: Type.String({ minLength: 1, maxLength: 200 }),
      specId: Type.String({ minLength: 1, maxLength: 200 }),
      specSha256: Type.String({ minLength: 64, maxLength: 64 }),
      sourcePhaseMapSha256: Type.String({ minLength: 64, maxLength: 64 }),
      baseBranch: Type.String({ minLength: 1, maxLength: 200 }),
      fullTitle: Type.String({ minLength: 1, maxLength: 500 }),
      fullContract: Type.Record(Type.String(), Type.Unknown(), { description: "Legacy worker-contract JSON (schema:1) object from the /add-kaneo preview full_task.contract" }),
      fullScope: Type.Array(Type.String({ minLength: 1 }), { minItems: 1, maxItems: 200 }),
      fullVerify: Type.Array(Type.String({ minLength: 1 }), { maxItems: 200 }),
      phases: Type.Array(
        Type.Object({
          phaseId: Type.String({ minLength: 1 }),
          parserTaskId: Type.String({ minLength: 1 }),
          ordinal: Type.Number({ minimum: 1 }),
          required: Type.Boolean(),
          title: Type.String({ minLength: 1 }),
          description: Type.Optional(Type.String({ maxLength: 4000 })),
          files: Type.Array(Type.String({ minLength: 1 }), { maxItems: 200 }),
          verify: Type.Array(Type.String({ minLength: 1 }), { maxItems: 200 }),
        }),
        { minItems: 1, maxItems: 30 },
      ),
    }),
    async execute(_id, params, signal) {
      const input = params as {
        projectId: string;
        planHash: string;
        expectedProjectRevision: number;
        changeSetId: string;
        specId: string;
        specSha256: string;
        sourcePhaseMapSha256: string;
        baseBranch: string;
        fullTitle: string;
        fullContract: Record<string, unknown>;
        fullScope: string[];
        fullVerify: string[];
        phases: Array<{
          phaseId: string;
          parserTaskId: string;
          ordinal: number;
          required: boolean;
          title: string;
          description?: string;
          files: string[];
          verify: string[];
        }>;
      };
      // Fail-closed contract checks: FULL description must start the legacy
      // worker-contract JSON (schema:1, state ready, task_id FULL) with scope
      // exactly equal to the sorted union of phase files.
      const contract = input.fullContract;
      if (
        contract.schema !== 1 ||
        contract.state !== "ready" ||
        contract.task_id !== "FULL" ||
        typeof contract.repo !== "string"
      ) {
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason: "full_contract_invalid: schema:1 + state:ready + task_id:FULL required" }) }],
          details: { kaneo: { tool: "publish_full_run_graph", ok: false, reason: "full_contract_invalid" } },
        };
      }
      const contractScope = Array.isArray(contract.scope) ? contract.scope : [];
      const sortedScope = [...input.fullScope].sort();
      if (
        contractScope.length !== sortedScope.length ||
        ![...contractScope].sort().some((value, index) => value === sortedScope[index])
      ) {
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason: "full_contract_scope_must_equal_union_of_phase_files" }) }],
          details: { kaneo: { tool: "publish_full_run_graph", ok: false, reason: "full_contract_scope_mismatch" } },
        };
      }
      const phaseMapBlock = {
        execution_mode: "full_run",
        phase_map_version: 1,
        change_set_id: input.changeSetId,
        spec_id: input.specId,
        spec_sha256: input.specSha256,
        source_phase_map_sha256: input.sourcePhaseMapSha256,
        full_task_id: "FULL",
        phases: input.phases.map((phase) => ({
          phase_id: phase.phaseId,
          parser_task_id: phase.parserTaskId,
          ordinal: phase.ordinal,
          required: phase.required,
          title: phase.title,
          description: phase.description ?? phase.title,
          files: [...phase.files],
          verify: [...phase.verify],
        })),
      };
      const body: FullRunGraphPublishBody = {
        planHash: input.planHash,
        expectedProjectRevision: input.expectedProjectRevision,
        changeSetId: input.changeSetId,
        specId: input.specId,
        specSha256: input.specSha256,
        sourcePhaseMapSha256: input.sourcePhaseMapSha256,
        baseBranch: input.baseBranch,
        full: {
          title: input.fullTitle,
          description: buildFullRunDescription(contract, phaseMapBlock),
          scope: [...input.fullScope],
          verify: [...input.fullVerify],
          taskExecutionState: "published",
        },
        phases: input.phases.map((phase) => ({
          phaseId: phase.phaseId,
          parserTaskId: phase.parserTaskId,
          ordinal: phase.ordinal,
          required: phase.required,
          title: phase.title,
          description: phase.description ?? phase.title,
          files: [...phase.files],
          verify: [...phase.verify],
        })),
      };
      const requestKey = `full-run-graph:${input.projectId}:${input.changeSetId}:${input.planHash}`;
      try {
        const receipt = await publishFullRunGraph(input.projectId, body, requestKey, signal);
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, reconciled: false, receipt }) }],
          details: { kaneo: { tool: "publish_full_run_graph", ok: true, graphId: receipt.graphId, fullTaskId: receipt.fullTaskId } },
        };
      } catch (error) {
        // Response-loss reconcile: same requestKey MUST return the stored
        // receipt; never recreate cards manually.
        const message = error instanceof Error ? error.message : String(error);
        try {
          const receipt = await getFullRunGraphByRequest(input.projectId, requestKey, signal);
          return {
            content: [{ type: "text" as const, text: formatToolText({ ok: true, reconciled: true, reconcileReason: message.slice(0, 300), receipt }) }],
            details: { kaneo: { tool: "publish_full_run_graph", ok: true, reconciled: true, graphId: receipt.graphId } },
          };
        } catch {
          return {
            content: [{ type: "text" as const, text: formatToolText({ ok: false, reason: message.slice(0, 500), requestKey }) }],
            details: { kaneo: { tool: "publish_full_run_graph", ok: false, reason: "publish_failed_no_stored_receipt" } },
          };
        }
      }
    },
  });

  // Parent ready-CAS: FULL stays published (unschedulable) until this passes.
  pi.registerTool({
    name: "kaneo_ready_full_run_graph",
    label: "Kaneo ready full-run graph (CAS)",
    description: "Parent-only: ready-CAS the published FULL graph with planHash + expectedProjectRevision + expectedTaskRevision from the graph receipt. Only a pass makes the FULL schedulable; drift returns 409 and the preview must be regenerated.",
    promptSnippet: "Ready-CAS the FULL task after graph publish; only then schedule it",
    parameters: Type.Object({
      projectId: Type.String({ minLength: 1 }),
      graphId: Type.String({ minLength: 1, maxLength: 200 }),
      planHash: Type.String({ minLength: 16, maxLength: 128 }),
      expectedProjectRevision: Type.Number({ minimum: 1 }),
      expectedTaskRevision: Type.Number({ minimum: 1, description: "taskRevision from the graph receipt" }),
    }),
    async execute(_id, params, signal) {
      const input = params as {
        projectId: string;
        graphId: string;
        planHash: string;
        expectedProjectRevision: number;
        expectedTaskRevision: number;
      };
      const requestKey = `full-run-ready:${input.graphId}:${input.planHash}:${input.expectedTaskRevision}`;
      const receipt = await readyFullRunGraph(
        input.projectId,
        input.graphId,
        {
          planHash: input.planHash,
          expectedProjectRevision: input.expectedProjectRevision,
          expectedTaskRevision: input.expectedTaskRevision,
        },
        requestKey,
        signal,
      );
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, graphId: receipt.graphId, projectRevision: receipt.projectRevision, taskRevision: receipt.taskRevision }) }],
        details: { kaneo: { tool: "ready_full_run_graph", ok: true, graphId: receipt.graphId } },
      };
    },
  });

  pi.registerTool({
    name: SCHEDULE_TOOL_NAME,
    label: "Kaneo create execution schedule",
    description:
      "Parent-only: preview then create a durable one-shot native schedule on host pi-prodesk. Without confirm=true this returns the preview + planHash and mutates nothing; pass confirm=true with that exact planHash to execute. Host 'prodesk-home' is rejected (SSH alias only).",
    promptSnippet: "Create a Kaneo native execution schedule with preview/confirmation",
    parameters: Type.Object({
      taskId: Type.String({ minLength: 1, description: "Kaneo task ID" }),
      taskTitle: Type.Optional(Type.String({ description: "Human-readable task title for the preview" })),
      localTime: Type.String({ minLength: 5, description: "Wall clock 'YYYY-MM-DD HH:MM' in timezone, or ISO with Z/offset" }),
      timezone: Type.String({ minLength: 1, description: "IANA timezone, e.g. Asia/Ho_Chi_Minh" }),
      model: Type.String({ minLength: 1, description: "Exact worker model id from the manifest allowlist, e.g. zai/glm-5.3-flash" }),
      host: Type.Optional(Type.String({ description: "Must be pi-prodesk (default); prodesk-home is rejected" })),
      notificationRoute: Type.Optional(Type.String({ description: "Logical route; only prodesk-telegram is allowed" })),
      telegramQuotaResume: Type.Optional(StringEnum(["disabled", "allowed_same_model_after_reset"] as const)),
      retryPolicy: Type.Optional(
        Type.Object({
          maxAttempts: Type.Optional(Type.Number({ minimum: 1, maximum: 10 })),
          backoffSeconds: Type.Optional(Type.Number({ minimum: 10, maximum: 86400 })),
        }),
      ),
      expectedTaskRevision: Type.Number({ minimum: 1, description: "Task revision observed at preview; confirmation fails if the server revision differs" }),
      manifestVersion: Type.Optional(Type.Number({ description: "Optional expected execution manifest version" })),
      confirm: Type.Optional(Type.Boolean({ description: "true executes the mutation; false/omitted only previews" })),
      planHash: Type.Optional(Type.String({ description: "planHash returned by the preview call; required when confirm=true" })),
    }),
    async execute(_id, params, signal) {
      const input = params as {
        taskId: string;
        taskTitle?: string;
        localTime: string;
        timezone: string;
        model: string;
        host?: string;
        notificationRoute?: string;
        telegramQuotaResume?: string;
        retryPolicy?: { maxAttempts?: number; backoffSeconds?: number };
        expectedTaskRevision: number;
        manifestVersion?: number;
        confirm?: boolean;
        planHash?: string;
      };
      let plan;
      type ScheduleToolDetails = {
        kaneo: {
          tool: string;
          ok: boolean;
          executed?: boolean;
          taskId?: string;
          scheduleId?: string;
          planHash?: string;
          notBeforeUtc?: string;
          reason?: string;
        };
      };
      let details: ScheduleToolDetails;
      try {
        plan = buildSchedulePlan({
          taskId: input.taskId,
          taskTitle: input.taskTitle ?? null,
          localTime: input.localTime,
          timezone: input.timezone,
          model: input.model,
          host: input.host,
          notificationRoute: input.notificationRoute,
          telegramQuotaResume: input.telegramQuotaResume,
          retryPolicy: input.retryPolicy,
          expectedTaskRevision: input.expectedTaskRevision,
          manifestVersion: input.manifestVersion ?? null,
        });
      } catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        details = { kaneo: { tool: SCHEDULE_TOOL_NAME, ok: false, reason } };
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason }) }],
          details,
        };
      }
      // SPEC-kaneo-wavefix-v0-2 (T1): reject schedules whose task contract
      // is missing/corrupt BEFORE anything is created — mirrors the
      // dispatcher's strict parser so a broken contract fails at preview
      // time with a durable reason instead of dispatching a silent no-op.
      let contractCheck: WorkerContractCheck;
      try {
        const task = await getKaneoTask(input.taskId, signal);
        contractCheck = parseWorkerContract(task.description ?? null);
      } catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        details = { kaneo: { tool: SCHEDULE_TOOL_NAME, ok: false, reason: `task_fetch_failed: ${reason}` } };
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason: details.kaneo.reason }) }],
          details,
        };
      }
      if (!contractCheck.ok) {
        const reason = `contract_rejected: ${contractCheck.reason}`;
        details = { kaneo: { tool: SCHEDULE_TOOL_NAME, ok: false, reason } };
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: false, reason }) }],
          details,
        };
      }
      if (!input.confirm) {
        const preview = buildSchedulePreviewText(plan);
        details = {
          kaneo: {
            tool: SCHEDULE_TOOL_NAME,
            ok: true,
            executed: false,
            taskId: input.taskId,
            planHash: plan.planHash,
            notBeforeUtc: plan.notBeforeUtc,
          },
        };
        return {
          content: [{ type: "text" as const, text: formatToolText({ ok: true, executed: false, planHash: plan.planHash, preview }) }],
          details,
        };
      }
      const confirmation = confirmSchedulePlan(
        plan,
        {
          planHash: input.planHash ?? "",
          currentTaskRevision: input.expectedTaskRevision,
          currentManifestVersion: input.manifestVersion ?? null,
        },
      );
      if (!confirmation.ok) {
        details = { kaneo: { tool: SCHEDULE_TOOL_NAME, ok: false, reason: confirmation.reason } };
        return {
          content: [{ type: "text" as const, text: formatToolText(confirmation) }],
          details,
        };
      }
      const schedule = await createExecutionSchedule(
        input.taskId,
        confirmation.request.body,
        confirmation.request.idempotencyKey,
        signal,
      );
      details = {
        kaneo: {
          tool: SCHEDULE_TOOL_NAME,
          ok: true,
          executed: true,
          taskId: input.taskId,
          scheduleId: schedule.id,
          planHash: plan.planHash,
        },
      };
      return {
        content: [{ type: "text" as const, text: formatToolText({ ok: true, executed: true, scheduleId: schedule.id }) }],
        details,
      };
    },
  });
}
