// kaneo-card — bind one exact Pi session to one Kaneo card.
//
// SPEC-2026-11-10-kaneo-card-agent-collaboration T4. `/kaneo-card <task>`
// activates ONLY the card-scoped tool subset (plus kaneo_toggle and
// kaneo_create_project); generic task mutators never appear while bound.
// The agentPrincipalId comes from the local secret file (KANEO_AGENT_PRINCIPAL_ID),
// never from model arguments. `sessionId` is a routing assertion persisted in
// a session custom entry: resume/model switch keeps it, a new Pi session
// starts unbound.
import { readFile, stat } from "node:fs/promises";
import { basename } from "node:path";
import { Type } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";
import type { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";
import {
  callKaneoApi,
  KaneoApiError,
  readSecret,
  type KaneoApiRequestOptions,
  type SecretConfig,
} from "./kaneo-client.ts";
import { KANEO_TOOLS } from "./tools.ts";
import { EXECUTION_TOOL_NAMES } from "./execution-runtime.ts";
import {
  boundActiveTools,
  CARD_STATE_ENTRY,
  CARD_TOOL_NAMES,
  formatCardBindingSnapshot,
  parseBindTaskInput,
  readPersistedCardBinding,
  unboundActiveTools,
  type PersistedCardBinding,
} from "./card-binding-state.ts";
import { runBoundDeliveryPoller } from "./card-delivery-poller.ts";

export type BindingServerResponse = {
  bindingId: string;
  bindingGeneration: number;
  taskId: string;
  projectId: string;
  sessionId: string;
  hostId: string;
  status: string;
  revision: number;
};


function describeBinding(binding: PersistedCardBinding): string {
  return [
    `Bound card : ${binding.taskId}`,
    `Project    : ${binding.projectId}`,
    `Binding    : ${binding.bindingId} (generation ${binding.bindingGeneration})`,
    `Session    : ${binding.sessionId}`,
    `Host       : ${binding.hostId}`,
    `Saved /kaneo mode for unbind: ${binding.savedKaneoMode ? "on" : "off"}`,
    `Bound at   : ${binding.boundAt}`,
  ].join("\n");
}

// Parse the bind input. Share-link tokens are rejected: a bearer capability
// is a different credential and must never become a binding.

type CardBindingDependencies = {
  readSecret?: () => Promise<SecretConfig>;
  callApi?: <T>(path: string, options?: KaneoApiRequestOptions) => Promise<T>;
};

export class CardBindingRuntime {
  private pi: ExtensionAPI;
  private binding: PersistedCardBinding | null = null;
  private readSecretConfig: () => Promise<SecretConfig>;
  private apiCall: <T>(path: string, options?: KaneoApiRequestOptions) => Promise<T>;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private heartbeatBusy = false;
  private deliveryPollAbort: AbortController | null = null;

  constructor(pi: ExtensionAPI, dependencies: CardBindingDependencies = {}) {
    this.pi = pi;
    this.readSecretConfig = dependencies.readSecret ?? readSecret;
    this.apiCall = dependencies.callApi ?? callKaneoApi;
  }

  // Rehydrate from the session custom entry during session_start. A stale
  // binding (revoked server-side) is kept visible until a scoped call reports
  // it; no silent auto-rebind to another session/card.
  restore(ctx: ExtensionContext): void {
    this.stopHeartbeat();
    this.stopDeliveryPoller();
    this.binding = readPersistedCardBinding(ctx.sessionManager);
    if (this.binding) {
      this.applyToolSet();
      this.startHeartbeat();
      this.startDeliveryPoller();
      return;
    }
    // New Pi sessions start unbound. The card tools are registered globally
    // by the extension but must not be model-visible until explicit bind.
    const cardSet = new Set(CARD_TOOL_NAMES);
    this.pi.setActiveTools(
      this.pi.getActiveTools().filter((name) => !cardSet.has(name)),
    );
  }

  stopHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
    this.heartbeatBusy = false;
  }

  private startHeartbeat(): void {
    this.stopHeartbeat();
    if (!this.binding) return;
    const tick = async () => {
      const binding = this.binding;
      if (!binding || this.heartbeatBusy) return;
      this.heartbeatBusy = true;
      try {
        await this.apiCall(
          `/api/agent-session/bindings/${encodeURIComponent(binding.bindingId)}/heartbeat`,
          {
            method: "POST",
            body: {
              sessionId: binding.sessionId,
              generation: binding.bindingGeneration,
            },
          },
        );
      } catch (error) {
        if (
          error instanceof KaneoApiError &&
          error.message.includes("stale_binding")
        ) {
          this.stopHeartbeat();
        }
      } finally {
        this.heartbeatBusy = false;
      }
    };
    void tick();
    this.heartbeatTimer = setInterval(() => void tick(), 30_000);
    this.heartbeatTimer.unref?.();
  }

  stopDeliveryPoller(): void {
    this.deliveryPollAbort?.abort();
    this.deliveryPollAbort = null;
  }

  private startDeliveryPoller(): void {
    this.stopDeliveryPoller();
    const binding = this.binding;
    if (!binding) return;
    const controller = new AbortController();
    this.deliveryPollAbort = controller;
    void runBoundDeliveryPoller({
      binding,
      signal: controller.signal,
      callApi: this.apiCall,
      sendMessage: (message, options) => this.pi.sendMessage(message, options),
      onStale: () => {
        this.stopHeartbeat();
        this.stopDeliveryPoller();
      },
    });
  }

  get active(): PersistedCardBinding | null {
    return this.binding;
  }

  private sessionId(ctx: ExtensionContext): string {
    // Pi session identity is the stable session id (not the path/hash and not
    // a newly generated id). It survives resume/model switch, while a new Pi
    // session gets a new id and starts unbound.
    return ctx.sessionManager.getSessionId();
  }

  private applyToolSet(): void {
    const { KANEO_TOOL_NAMES } = safeToolNames();
    this.pi.setActiveTools(
      boundActiveTools({
        active: this.pi.getActiveTools(),
        globalKaneoNames: KANEO_TOOL_NAMES,
        savedKaneoMode: this.binding?.savedKaneoMode ?? false,
      }),
    );
  }

  async bind(rawInput: string, ctx: ExtensionContext): Promise<string> {
    const secret = await this.readSecretConfig();
    const parsed = parseBindTaskInput(rawInput, secret.endpoint);
    if ("error" in parsed) return parsed.error;
    if (!secret.agentPrincipalId) {
      return "KANEO_AGENT_PRINCIPAL_ID missing in the Kaneo secret file — add it (mode 0600) before binding a card.";
    }
    const sessionId = this.sessionId(ctx);
    const savedKaneoMode = this.binding?.savedKaneoMode ?? this.pi
      .getActiveTools()
      .some((name) => safeToolNames().KANEO_TOOL_NAMES.includes(name));
    const binding = await this.apiCall<BindingServerResponse>(
      "/api/agent-session/bindings",
      {
        method: "POST",
        body: {
          taskId: parsed.taskId,
          agentPrincipalId: secret.agentPrincipalId,
          sessionId,
        },
      },
    );
    this.binding = {
      version: 1,
      taskId: binding.taskId,
      projectId: binding.projectId,
      bindingId: binding.bindingId,
      bindingGeneration: binding.bindingGeneration,
      hostId: binding.hostId,
      sessionId: binding.sessionId,
      savedKaneoMode,
      boundAt: new Date().toISOString(),
    };
    this.pi.appendEntry(CARD_STATE_ENTRY, this.binding);
    this.applyToolSet();
    this.startHeartbeat();
    this.startDeliveryPoller();
    return `Bound to card ${binding.taskId}\n${describeBinding(this.binding)}\nCard tools active: ${CARD_TOOL_NAMES.length}. Generic task mutators are hidden until /kaneo-card off.`;
  }

  show(): string {
    if (!this.binding) {
      return "No card binding in this session. Use /kaneo-card <task-id | task URL>.";
    }
    return describeBinding(this.binding);
  }

  async unbind(ctx: ExtensionContext): Promise<string> {
    const binding = this.binding;
    if (!binding) {
      return "No card binding to clear.";
    }
    try {
      await this.apiCall(
        `/api/agent-session/bindings/${encodeURIComponent(binding.bindingId)}?sessionId=${encodeURIComponent(binding.sessionId)}&generation=${binding.bindingGeneration}`,
        { method: "DELETE" },
      );
    } catch (error) {
      // Already revoked server-side is fine; anything else still clears the
      // local state but tells the operator what the server said.
      const message = error instanceof Error ? error.message : String(error);
      if (!message.includes("404") && !message.includes("409")) {
        // Fail closed: if the server could not revoke, keep the local card
        // boundary and let the operator retry; otherwise a remote active
        // writer would be orphaned while this Pi exposes generic mutators.
        return `Could not clear the server binding: ${message}`;
      }
    }
    void ctx;
    this.stopHeartbeat();
    this.stopDeliveryPoller();
    this.binding = null;
    this.pi.appendEntry(CARD_STATE_ENTRY, {
      version: 1,
      unbound: true,
      savedKaneoMode: binding.savedKaneoMode,
      clearedAt: new Date().toISOString(),
    });
    this.restoreSavedMode(binding.savedKaneoMode);
    return `Card binding cleared. Restored /kaneo ${binding.savedKaneoMode ? "on" : "off"}.`;
  }

  private restoreSavedMode(savedKaneoMode: boolean): void {
    const { KANEO_TOOL_NAMES } = safeToolNames();
    this.pi.setActiveTools(
      unboundActiveTools({
        active: this.pi.getActiveTools(),
        globalKaneoNames: KANEO_TOOL_NAMES,
        savedKaneoMode,
      }),
    );
  }

  setSavedKaneoMode(on: boolean, persist = true): void {
    if (this.binding) {
      this.binding.savedKaneoMode = on;
      if (persist) this.pi.appendEntry(CARD_STATE_ENTRY, this.binding);
      this.applyToolSet();
    }
  }

  private requireBinding(): PersistedCardBinding {
    if (!this.binding) {
      throw new Error("kaneo-card: session is not bound. Use /kaneo-card <task> first.");
    }
    return this.binding;
  }

  private scopedBody(extra: Record<string, unknown> = {}): Record<string, unknown> {
    const binding = this.requireBinding();
    return {
      bindingId: binding.bindingId,
      sessionId: binding.sessionId,
      generation: binding.bindingGeneration,
      ...extra,
    };
  }

  private async scopedCall<T>(path: string, body: Record<string, unknown>): Promise<T> {
    try {
      return await this.apiCall<T>(path, { method: "POST", body });
    } catch (error) {
      if (error instanceof KaneoApiError && error.message.includes("stale_binding")) {
        this.stopHeartbeat();
        this.stopDeliveryPoller();
        throw new Error(
          "kaneo-card: binding is stale (revoked, rebound, or fenced by a formal run). Run /kaneo-card again to rebind.",
        );
      }
      throw error;
    }
  }

  cardGet() {
    return this.scopedCall<Record<string, unknown>>("/api/agent-session/card/get", this.scopedBody());
  }

  cardUpdate(patch: Record<string, unknown>, expectedContentRevision: number) {
    return this.scopedCall<Record<string, unknown>>("/api/agent-session/card/update", {
      ...this.scopedBody(),
      patch,
      expectedContentRevision,
    });
  }

  cardCreateSubtask(input: {
    title: string;
    description?: string;
    status?: string;
    priority?: string;
    expectedParentContentRevision: number;
  }) {
    return this.scopedCall<Record<string, unknown>>("/api/agent-session/card/subtasks", {
      ...this.scopedBody(),
      ...input,
    });
  }

  cardUpdateSubtask(subtaskId: string, patch: Record<string, unknown>, expectedContentRevision: number) {
    return this.scopedCall<Record<string, unknown>>(
      `/api/agent-session/card/subtasks/${encodeURIComponent(subtaskId)}/update`,
      { ...this.scopedBody(), patch, expectedContentRevision },
    );
  }

  cardDeleteSubtask(subtaskId: string, expectedParentContentRevision: number) {
    return this.scopedCall<Record<string, unknown>>(
      `/api/agent-session/card/subtasks/${encodeURIComponent(subtaskId)}/delete`,
      { ...this.scopedBody(), expectedParentContentRevision },
    );
  }

  cardListComments(limit?: number, cursor?: string) {
    return this.scopedCall<Record<string, unknown>>("/api/agent-session/card/comments", {
      ...this.scopedBody(),
      limit,
      cursor,
    });
  }

  cardCreateComment(content: string) {
    return this.scopedCall<Record<string, unknown>>("/api/agent-session/card/comments/create", {
      ...this.scopedBody(),
      content,
    });
  }

  cardUpdateWorkMarkers(workMarkerCounts: Record<string, number>, expectedContentRevision: number) {
    return this.scopedCall<Record<string, unknown>>("/api/agent-session/card/work-markers", {
      ...this.scopedBody(),
      workMarkerCounts,
      expectedContentRevision,
    });
  }

  cardUploadTicket(input: {
    ownerType: "task_description" | "task_comment";
    ownerId: string;
    filename: string;
    contentType: string;
    size: number;
  }) {
    return this.scopedCall<{ key: string; uploadUrl: string; headers: Record<string, string> }>(
      "/api/agent-session/card/assets/upload-ticket",
      { ...this.scopedBody(), ...input },
    );
  }

  cardFinalizeUpload(input: {
    ownerType: "task_description" | "task_comment";
    ownerId: string;
    key: string;
    filename: string;
    contentType: string;
    size: number;
  }) {
    return this.scopedCall<{ id: string; url?: string }>(
      "/api/agent-session/card/assets/finalize",
      { ...this.scopedBody(), ...input },
    );
  }

  // ≤512 UTF-8 chars: card ID/code, title, project, status, task URL. Details
  // are fetched on demand through the tools; never description/comments/tree.
  async snapshotForPrompt(): Promise<string | null> {
    if (!this.binding) return null;
    try {
      const payload = (await this.cardGet()) as {
        project?: { id: string; name: string; slug: string; workspaceId: string };
        card?: { id: string; number: number | null; title: string; status: string };
      };
      const card = payload.card;
      const project = payload.project;
      if (!card || !project) return null;
      const secret = await this.readSecretConfig();
      const url = `${secret.endpoint}/dashboard/workspace/${project.workspaceId}/project/${project.id}/task/${card.id}`;
      const text = formatCardBindingSnapshot({
        card,
        project,
        taskUrl: url,
      });
      return text;
    } catch {
      // A stale/offline binding must not break the run start.
      return null;
    }
  }

  registerTools(pi: ExtensionAPI): void {
    const numberRev = Type.Number({
      minimum: 1,
      description: "expectedContentRevision read from the latest card/subtask state",
    });

    pi.registerTool({
      name: "kaneo_card_get",
      label: "Kaneo card get",
      description:
        "Read the bound card snapshot: fields, contentRevision, statusOptions, subtask list, subtaskCount. Root actions accept no target ID.",
      parameters: Type.Object({}),
      async execute() {
        return textResult(await runtime()?.cardGet());
      },
    });

    pi.registerTool({
      name: "kaneo_card_update",
      label: "Kaneo card update",
      description:
        "Update bound-card fields (title/description/status/priority/startDate/dueDate) with CAS. Read the card first; stale revisions return 409.",
      parameters: Type.Object({
        patch: Type.Object({
          title: Type.Optional(Type.String()),
          description: Type.Optional(Type.String()),
          status: Type.Optional(Type.String()),
          priority: Type.Optional(Type.String()),
          startDate: Type.Optional(Type.Union([Type.String(), Type.Null()])),
          dueDate: Type.Optional(Type.Union([Type.String(), Type.Null()])),
        }),
        expectedContentRevision: numberRev,
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as {
          patch: Record<string, unknown>;
          expectedContentRevision: number;
        };
        return textResult(await runtime()?.cardUpdate(args.patch, args.expectedContentRevision));
      },
    });

    pi.registerTool({
      name: "kaneo_card_create_subtask",
      label: "Kaneo card create subtask",
      description:
        "Create one subtask under the bound card. CAS-guards the parent contentRevision.",
      parameters: Type.Object({
        title: Type.String({ minLength: 1 }),
        description: Type.Optional(Type.String()),
        status: Type.Optional(Type.String()),
        priority: Type.Optional(Type.String()),
        expectedParentContentRevision: numberRev,
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as {
          title: string;
          description?: string;
          status?: string;
          priority?: string;
          expectedParentContentRevision: number;
        };
        return textResult(await runtime()?.cardCreateSubtask(args));
      },
    });

    pi.registerTool({
      name: "kaneo_card_update_subtask",
      label: "Kaneo card update subtask",
      description:
        "Update a subtask of the bound card (the API rechecks subtree membership). CAS on the subtask contentRevision.",
      parameters: Type.Object({
        subtaskId: Type.String({ minLength: 1 }),
        patch: Type.Object({
          title: Type.Optional(Type.String()),
          description: Type.Optional(Type.String()),
          status: Type.Optional(Type.String()),
          priority: Type.Optional(Type.String()),
          startDate: Type.Optional(Type.Union([Type.String(), Type.Null()])),
          dueDate: Type.Optional(Type.Union([Type.String(), Type.Null()])),
        }),
        expectedContentRevision: numberRev,
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as {
          subtaskId: string;
          patch: Record<string, unknown>;
          expectedContentRevision: number;
        };
        return textResult(
          await runtime()?.cardUpdateSubtask(args.subtaskId, args.patch, args.expectedContentRevision),
        );
      },
    });

    pi.registerTool({
      name: "kaneo_card_delete_subtask",
      label: "Kaneo card delete subtask",
      description:
        "Delete a descendant subtask of the bound card. Root deletion is rejected; CAS-guards the parent.",
      parameters: Type.Object({
        subtaskId: Type.String({ minLength: 1 }),
        expectedParentContentRevision: numberRev,
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as {
          subtaskId: string;
          expectedParentContentRevision: number;
        };
        return textResult(
          await runtime()?.cardDeleteSubtask(
            args.subtaskId,
            args.expectedParentContentRevision,
          ),
        );
      },
    });

    pi.registerTool({
      name: "kaneo_card_list_comments",
      label: "Kaneo card list comments",
      description:
        "List bound-card comments, latest first (default 10, max 50, cursor pagination). Bounded output — do not request unbounded history.",
      parameters: Type.Object({
        limit: Type.Optional(Type.Number({ minimum: 1, maximum: 50 })),
        cursor: Type.Optional(Type.String()),
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as { limit?: number; cursor?: string };
        return textResult(await runtime()?.cardListComments(args.limit, args.cursor));
      },
    });

    pi.registerTool({
      name: "kaneo_card_create_comment",
      label: "Kaneo card create comment",
      description: "Post one comment on the bound card as the bound session.",
      parameters: Type.Object({
        content: Type.String({ minLength: 1 }),
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as { content: string };
        return textResult(await runtime()?.cardCreateComment(args.content));
      },
    });

    pi.registerTool({
      name: "kaneo_card_upload_asset",
      label: "Kaneo card upload asset",
      description:
        "Upload a local file to the bound card (presign -> PUT -> finalize through the binding scope). Returns the asset URL.",
      parameters: Type.Object({
        path: Type.String({ minLength: 1 }),
        ownerType: StringEnum(["task_description", "task_comment"] as const),
        ownerId: Type.String({
          minLength: 1,
          description: "Card or subtask id that owns the asset (must be inside the bound subtree)",
        }),
        contentType: Type.Optional(Type.String()),
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as {
          path: string;
          ownerType: "task_description" | "task_comment";
          ownerId: string;
          contentType?: string;
        };
        const info = await stat(args.path);
        if (info.size > 10 * 1024 * 1024) {
          throw new Error("kaneo-card: asset exceeds the 10 MiB upload limit");
        }
        const bytes = await readFile(args.path);
        const filename = basename(args.path);
        const contentType =
          args.contentType ||
          guessContentType(filename);
        const ticket = await runtime()?.cardUploadTicket({
          ownerType: args.ownerType,
          ownerId: args.ownerId,
          filename,
          contentType,
          size: bytes.byteLength,
        });
        if (!ticket) throw new Error("kaneo-card: not bound");
        const put = await fetch(ticket.uploadUrl, {
          method: "PUT",
          headers: { ...(ticket.headers ?? {}) },
          body: bytes,
        });
        if (!put.ok) {
          throw new Error(`kaneo-card: storage PUT failed (${put.status})`);
        }
        const asset = await runtime()?.cardFinalizeUpload({
          ownerType: args.ownerType,
          ownerId: args.ownerId,
          key: ticket.key,
          filename,
          contentType,
          size: bytes.byteLength,
        });
        return textResult(asset);
      },
    });

    pi.registerTool({
      name: "kaneo_card_get_asset",
      label: "Kaneo card get asset",
      description:
        "Read/download an asset inside the bound subtree. Returns base64 content for text assets; pass savePath for binaries.",
      parameters: Type.Object({
        assetId: Type.String({ minLength: 1 }),
        savePath: Type.Optional(Type.String()),
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as { assetId: string; savePath?: string };
        const binding = runtime()?.active;
        if (!binding) throw new Error("kaneo-card: not bound");
        const secret = await this.readSecretConfig();
        const url = `${secret.endpoint}/api/agent-session/bindings/${encodeURIComponent(binding.bindingId)}/card/assets/${encodeURIComponent(args.assetId)}?sessionId=${encodeURIComponent(binding.sessionId)}&generation=${binding.bindingGeneration}`;
        const response = await fetch(url, {
          headers: { Authorization: `Bearer ${secret.apiKey}` },
        });
        if (!response.ok) {
          const body = await response.text().catch(() => "");
          if (response.status === 409 && body.includes("stale_binding")) {
            throw new Error(
              "kaneo-card: binding is stale (revoked, rebound, or fenced by a formal run). Run /kaneo-card again to rebind.",
            );
          }
          throw new Error(`kaneo-card: asset read failed (${response.status})`);
        }
        const buffer = Buffer.from(await response.arrayBuffer());
        const mimeType = response.headers.get("content-type") ?? "application/octet-stream";
        if (args.savePath) {
          const { writeFile } = await import("node:fs/promises");
          await writeFile(args.savePath, buffer);
          return textResult({ assetId: args.assetId, savedTo: args.savePath, size: buffer.byteLength });
        }
        if (/^(text\/|application\/(?:json|xml|javascript|x-www-form-urlencoded|csv))/i.test(mimeType)) {
          return textResult({
            assetId: args.assetId,
            mimeType,
            size: buffer.byteLength,
            text: buffer.toString("utf8").slice(0, 128_000),
          });
        }
        return textResult({
          assetId: args.assetId,
          mimeType,
          size: buffer.byteLength,
          contentBase64: buffer.toString("base64").slice(0, 200_000),
        });
      },
    });

    pi.registerTool({
      name: "kaneo_card_update_work_markers",
      label: "Kaneo card update work markers",
      description:
        "Replace the full work-marker count map on the bound card. CAS on contentRevision; never touches execution state.",
      parameters: Type.Object({
        workMarkerCounts: Type.Object({
          redCross: Type.Number(),
          boxedRedCross: Type.Number(),
          redCircle: Type.Number(),
          greenCheck: Type.Number(),
        }),
        expectedContentRevision: numberRev,
      }),
      async execute(_id, params) {
        const args = (params ?? {}) as {
          workMarkerCounts: Record<string, number>;
          expectedContentRevision: number;
        };
        return textResult(
          await runtime()?.cardUpdateWorkMarkers(args.workMarkerCounts, args.expectedContentRevision),
        );
      },
    });
  }
}

// Generic Kaneo tool names (prefixed) — card mode never activates these.


function safeToolNames(): { KANEO_TOOL_NAMES: string[] } {
  return {
    KANEO_TOOL_NAMES: [
      ...KANEO_TOOLS.map((tool) => `kaneo_${tool.name}`),
      "kaneo_upload_asset",
      "kaneo_get_asset",
      ...EXECUTION_TOOL_NAMES,
    ],
  };
}

let activeRuntime: CardBindingRuntime | null = null;

export function setCardRuntime(runtime: CardBindingRuntime | null) {
  activeRuntime = runtime;
}

export function runtime(): CardBindingRuntime | null {
  return activeRuntime;
}

function textResult(payload: unknown) {
  const text = typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
  return {
    content: [{ type: "text" as const, text }],
    details: { kaneo: { card: true, ok: true } },
  };
}

function guessContentType(filename: string) {
  const lower = filename.toLowerCase();
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".pdf")) return "application/pdf";
  if (lower.endsWith(".txt") || lower.endsWith(".md")) return "text/plain";
  return "application/octet-stream";
}
