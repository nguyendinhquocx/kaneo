import type { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";
import { createHash, randomUUID } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { realpathSync } from "node:fs";
import { tmpdir } from "node:os";
import { isAbsolute, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  claimTaskRun,
  createPhaseCheckpoint as createPhaseCheckpointApi,
  createTaskComment,
  createTaskRunCheckpoint,
  getExecutionManifest,
  getPhaseProgress as getPhaseProgressApi,
  getTaskRelations,
  getTaskRun,
  listTaskComments,
  listTaskRunEvidence,
  KaneoApiError,
  getKaneoTask,
  heartbeatTaskRun,
  listExecutionAgents,
  listTaskRuns,
  postPhaseProgress as postPhaseProgressApi,
  readSecret,
  releaseTaskRun,
  reportTaskRun,
  reviewTaskRun,
  type KaneoAgentPrincipalRecord,
  type KaneoExecutionManifestRecord,
  type KaneoTaskRecord,
  type KaneoTaskRelationRecord,
  type KaneoTaskRunEvidenceRecord,
  type KaneoTaskRunRecord,
  type PhaseCheckpointRecord,
  type PhaseProgressSnapshot,
} from "./kaneo-client.ts";
import { canonicalJsonSorted } from "../kaneo-agent-control/manifest.ts";

export interface ExecutionRuntimeClient {
  readSecret: typeof readSecret;
  getKaneoTask: typeof getKaneoTask;
  getExecutionManifest: typeof getExecutionManifest;
  getTaskRelations: typeof getTaskRelations;
  getTaskRun: typeof getTaskRun;
  listTaskComments: typeof listTaskComments;
  createTaskComment: typeof createTaskComment;
  listTaskRunEvidence: typeof listTaskRunEvidence;
  listExecutionAgents: typeof listExecutionAgents;
  listTaskRuns: typeof listTaskRuns;
  claimTaskRun: typeof claimTaskRun;
  heartbeatTaskRun: typeof heartbeatTaskRun;
  createTaskRunCheckpoint: typeof createTaskRunCheckpoint;
  reportTaskRun: typeof reportTaskRun;
  releaseTaskRun: typeof releaseTaskRun;
  reviewTaskRun: typeof reviewTaskRun;
  getPhaseProgress: typeof getPhaseProgressApi;
  postPhaseProgress: typeof postPhaseProgressApi;
  createPhaseCheckpoint: typeof createPhaseCheckpointApi;
}

const DEFAULT_CLIENT: ExecutionRuntimeClient = {
  readSecret,
  getKaneoTask,
  getExecutionManifest,
  getTaskRelations,
  getTaskRun,
  listTaskComments,
  createTaskComment,
  listTaskRunEvidence,
  listExecutionAgents,
  listTaskRuns,
  claimTaskRun,
  heartbeatTaskRun,
  createTaskRunCheckpoint,
  reportTaskRun,
  releaseTaskRun,
  reviewTaskRun,
  getPhaseProgress: getPhaseProgressApi,
  postPhaseProgress: postPhaseProgressApi,
  createPhaseCheckpoint: createPhaseCheckpointApi,
};

const EXECUTION_STATE_ENTRY = "kaneo-execution-state";
const HEARTBEAT_INTERVAL_MS = 20_000;
const NATIVE_HOSTS = new Set(["pi-laptop", "pi-prodesk"]);
// Canonical worker-reportable states (SPEC-kaneo-native-telegram-control-v0-1).
// Generic "blocked" is rejected by the API on new writes; workers must report
// the specific blocked_* state plus a failureKind.
const WORKER_REPORT_STATES = new Set([
  "in_progress",
  "in_review",
  "blocked_quota",
  "blocked_input",
  "blocked_clarification",
  "blocked_branch_drift",
  "failed",
]);
const REPORT_FIELDS = [
  "baseSha",
  "commitSha",
  "prNumber",
  "prUrl",
  "prState",
  "evidence",
  "blocker",
  "nextAction",
] as const;
const SAFE_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

export const EXECUTION_TOOL_NAMES = [
  "kaneo_get_execution_context",
  "kaneo_claim_task_run",
  "kaneo_prepare_task_checkout",
  "kaneo_commit_task_branch",
  "kaneo_push_task_branch",
  "kaneo_checkpoint_task_run",
  "kaneo_heartbeat_task_run",
  "kaneo_report_task_run",
  "kaneo_get_task_review",
  "kaneo_review_task_run",
  "kaneo_release_task_run",
  "kaneo_phase_progress",
  "kaneo_phase_checkpoint",
  "kaneo_publish_full_run_graph",
  "kaneo_ready_full_run_graph",
] as const;

interface PersistedExecutionState {
  version: 1 | 2;
  taskId: string;
  projectId: string;
  runId: string;
  state: string;
  agentPrincipalId: string;
  hostId: string;
  branchName: string;
  scope: string[];
  worktreePath?: string | null;
  updatedAt: string;
}

interface ActiveLease {
  run: KaneoTaskRunRecord;
  leaseToken: string;
  runtimeId: string;
  projectId: string;
  worktreePath: string | null;
}

interface ExecutionConfig {
  agentPrincipalId: string;
  hostId: "pi-laptop" | "pi-prodesk";
  gitAllowlistPath: string;
  gitGuardPath: string;
  fenceBaseUrl: string;
  prGuardPath?: string;
}

interface HostBindingResult {
  status: "configured" | "blocked";
  hostId: string | null;
  projectId: string;
  repository: string;
  checkoutRoot?: string;
  worktreeRoot?: string | null;
  reason?: string;
}

export interface GuardReceipt {
  receiptId: string;
  remoteRef: string;
  headSha: string;
  commitSha: string;
  receiptHash: string;
  [key: string]: unknown;
}

interface GuardResult {
  status: string;
  checkout_root?: string;
  worktree_root?: string;
  worktree_path?: string;
  worktree_created?: boolean;
  output?: string;
  base_sha?: string;
  commit_sha?: string;
  changed_files?: string[];
  diff_within_scope?: boolean;
  branch_valid?: boolean;
  base_ancestor?: boolean;
  commands?: string[];
  guard_receipt?: GuardReceipt;
}

export interface GitMutationResult {
  operation: "commit" | "push";
  run: Omit<KaneoTaskRunRecord, "leaseToken">;
  baseSha: string;
  commitSha: string;
  changedFiles: string[];
  diffWithinScope: true;
  branchValid: true;
  commands: string[];
  guardReceipt?: GuardReceipt;
}

export interface CheckpointResult {
  run: Omit<KaneoTaskRunRecord, "leaseToken">;
  baseSha: string;
  commitSha: string;
  branch: string;
  guardReceipt: GuardReceipt;
  commentCreated: boolean;
  commentId?: string;
}

interface PrGuardResult {
  status: string;
  operation?: string;
  blocker?: string;
  reason?: string;
  pr_number?: number;
  pr_url?: string;
  pr_state?: string;
  merge_commit_sha?: string;
  branch?: string;
  base_branch?: string;
}

export interface ExecutionContextPack {
  task: Pick<KaneoTaskRecord, "id" | "projectId" | "title" | "description" | "status" | "priority">;
  manifest: Pick<
    KaneoExecutionManifestRecord,
    | "id"
    | "projectId"
    | "repositoryOwner"
    | "repositoryName"
    | "baseBranch"
    | "docs"
    | "verificationProfile"
    | "allowedAgentIds"
    | "policy"
    | "manifestVersion"
    | "protocolVersion"
  >;
  agents: Array<Pick<KaneoAgentPrincipalRecord, "id" | "runtimeId" | "hostId" | "scopes" | "isActive">>;
  runs: Array<Omit<KaneoTaskRunRecord, "leaseToken">>;
  relations: KaneoTaskRelationRecord[];
  currentRun: Omit<KaneoTaskRunRecord, "leaseToken"> | null;
  verification: {
    profile: string;
    docs: string[];
    policy: Record<string, unknown>;
  };
  hostBinding: HostBindingResult;
  worker: {
    configuredAgentPrincipalId: string | null;
    configuredHostId: string | null;
    configuredRuntimeId: string | null;
    resumeRequired: boolean;
    blocker: string | null;
  };
}

function safeId(value: string, label: string): string {
  if (!SAFE_ID_PATTERN.test(value)) throw new Error(`kaneo-execution: invalid ${label}`);
  return value;
}

function safeSha(value: unknown, label: string): string {
  if (typeof value !== "string" || !/^[0-9a-f]{40}$/i.test(value)) {
    throw new Error(`kaneo-execution: ${label} must be a full Git SHA`);
  }
  return value;
}

function sanitizeTask(task: KaneoTaskRecord): ExecutionContextPack["task"] {
  return {
    id: task.id,
    projectId: task.projectId,
    title: task.title,
    description: typeof task.description === "string" ? task.description : null,
    status: typeof task.status === "string" ? task.status : undefined,
    priority: typeof task.priority === "string" ? task.priority : undefined,
  };
}

function sanitizeManifest(manifest: KaneoExecutionManifestRecord): ExecutionContextPack["manifest"] {
  return {
    id: manifest.id,
    projectId: manifest.projectId,
    repositoryOwner: manifest.repositoryOwner,
    repositoryName: manifest.repositoryName,
    baseBranch: manifest.baseBranch,
    docs: [...manifest.docs],
    verificationProfile: manifest.verificationProfile,
    allowedAgentIds: [...manifest.allowedAgentIds],
    policy: { ...manifest.policy },
    manifestVersion: manifest.manifestVersion,
    protocolVersion: manifest.protocolVersion,
  };
}

function sanitizeAgent(agent: KaneoAgentPrincipalRecord): ExecutionContextPack["agents"][number] {
  return {
    id: agent.id,
    runtimeId: agent.runtimeId,
    hostId: agent.hostId,
    scopes: [...agent.scopes],
    isActive: agent.isActive,
  };
}

function sanitizeRun(run: KaneoTaskRunRecord): Omit<KaneoTaskRunRecord, "leaseToken"> {
  const { leaseToken: _leaseToken, ...safeRun } = run;
  return safeRun;
}

function validateScope(scope: string[]): string[] {
  if (!Array.isArray(scope) || scope.length === 0 || scope.length > 100) {
    throw new Error("kaneo-execution: scope must contain 1-100 relative paths");
  }
  const normalized = scope.map((value) => {
    if (typeof value !== "string") throw new Error("kaneo-execution: scope paths must be strings");
    const path = value.trim().replaceAll("\\", "/");
    if (
      !path ||
      path === "*" ||
      path === "**" ||
      path.startsWith("/") ||
      /^[A-Za-z]:\//.test(path) ||
      path.split("/").some((segment) => !segment || segment === "." || segment === "..")
    ) {
      throw new Error("kaneo-execution: scope must use explicit relative paths; '*' is not allowed");
    }
    const wildcard = [...path].findIndex((character) => "*?[".includes(character));
    if (wildcard >= 0 && !path.slice(0, wildcard).replace(/\/+$/, "")) {
      throw new Error("kaneo-execution: wildcard scope must be anchored below a directory");
    }
    return path;
  });
  return [...new Set(normalized)];
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message.slice(0, 800) : String(error).slice(0, 800);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// ---------------------------------------------------------------------------
// FULL-run phase protocol — pure helpers (SPEC-kaneo-phase-cards-full-run)
// Deterministic keys, model-facing args surface fence, canonical request
// hash. No timestamps, no request randomness, no lease secrets in outputs.
// ---------------------------------------------------------------------------

export type PhaseProgressAction = "get" | "begin" | "complete" | "block";

export const PHASE_PROGRESS_ACTIONS: readonly PhaseProgressAction[] = ["get", "begin", "complete", "block"];

export const PHASE_FAILURE_KINDS = [
  "malformed_phase_map",
  "provider_quota",
  "provider_timeout",
  "provider_5xx",
  "test_failure",
  "worker_crash",
  "input_missing",
  "clarification_needed",
  "branch_drift",
] as const;

export type PhaseFailureKind = (typeof PHASE_FAILURE_KINDS)[number];

const PHASE_ID_RUNTIME_PATTERN = /^P[0-9]+$/;
/** Model-facing args allowlist. Anything else — especially runId, leaseEpoch,
 * lease token, status string, marker, or free hashes — is fail-closed. */
const PHASE_PROGRESS_ALLOWED_ARGS = new Set([
  "taskId",
  "phaseId",
  "action",
  "checkpointId",
  "failureKind",
  "reason",
  "retryAt",
]);
const PHASE_PROGRESS_FORBIDDEN_ARGS = [
  "runId",
  "run_id",
  "leaseEpoch",
  "lease_epoch",
  "leaseToken",
  "lease_token",
  "token",
  "state",
  "status",
  "marker",
  "comment",
  "specSha256",
  "spec_sha256",
  "sourcePhaseMapSha256",
  "source_phase_map_sha256",
];

export interface PhaseProgressArgsCheck {
  ok: boolean;
  reason?: string;
  taskId?: string;
  phaseId?: string;
  action?: PhaseProgressAction;
  checkpointId?: string;
  failureKind?: PhaseFailureKind;
  reason?: string;
  retryAt?: string;
}

/** Validate the model-facing kaneo_phase_progress args surface. runId/epoch/
 * token/status/marker/hash are runtime-derived or forbidden; complete requires
 * checkpointId; block requires failureKind (and only block may carry
 * reason/retryAt). */
export function validatePhaseProgressArgs(args: Record<string, unknown>): PhaseProgressArgsCheck {
  for (const key of Object.keys(args)) {
    if (!PHASE_PROGRESS_ALLOWED_ARGS.has(key)) {
      return { ok: false, reason: `forbidden_arg:${key}` };
    }
  }
  for (const forbidden of PHASE_PROGRESS_FORBIDDEN_ARGS) {
    if (Object.hasOwn(args, forbidden)) {
      return { ok: false, reason: `forbidden_arg:${forbidden}` };
    }
  }
  const taskId = args.taskId;
  if (typeof taskId !== "string" || !SAFE_ID_PATTERN.test(taskId)) {
    return { ok: false, reason: "invalid_taskId" };
  }
  const phaseId = args.phaseId;
  if (typeof phaseId !== "string" || !PHASE_ID_RUNTIME_PATTERN.test(phaseId)) {
    return { ok: false, reason: "invalid_phaseId" };
  }
  const action = args.action;
  if (typeof action !== "string" || !PHASE_PROGRESS_ACTIONS.includes(action as PhaseProgressAction)) {
    return { ok: false, reason: "invalid_action" };
  }
  const check: PhaseProgressArgsCheck = { ok: true, taskId, phaseId, action: action as PhaseProgressAction };
  if (action === "complete") {
    const checkpointId = args.checkpointId;
    if (typeof checkpointId !== "string" || !SAFE_ID_PATTERN.test(checkpointId)) {
      return { ok: false, reason: "complete_requires_checkpointId" };
    }
    check.checkpointId = checkpointId;
  } else if (Object.hasOwn(args, "checkpointId")) {
    return { ok: false, reason: "checkpointId_only_allowed_for_complete" };
  }
  if (action === "block") {
    const failureKind = args.failureKind;
    if (typeof failureKind !== "string" || !(PHASE_FAILURE_KINDS as readonly string[]).includes(failureKind)) {
      return { ok: false, reason: "block_requires_failureKind" };
    }
    check.failureKind = failureKind as PhaseFailureKind;
    if (args.reason !== undefined) {
      if (typeof args.reason !== "string" || args.reason.length > 4000) {
        return { ok: false, reason: "invalid_reason" };
      }
      check.reason = args.reason;
    }
    if (args.retryAt !== undefined) {
      if (typeof args.retryAt !== "string" || Number.isNaN(Date.parse(args.retryAt))) {
        return { ok: false, reason: "invalid_retryAt" };
      }
      check.retryAt = args.retryAt;
    }
  } else if (Object.hasOwn(args, "failureKind") || Object.hasOwn(args, "reason") || Object.hasOwn(args, "retryAt")) {
    return { ok: false, reason: "block_fields_only_allowed_for_block" };
  }
  return check;
}

const EMPTY_KEY_SEGMENT = "none";

function keySegment(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return EMPTY_KEY_SEGMENT;
  const text = String(value);
  return text.length > 0 ? text : EMPTY_KEY_SEGMENT;
}

export function phaseBeginKey(runId: string, phaseId: string): string {
  return `phase-begin:${runId}:${phaseId}`;
}

export function phaseCompleteKey(runId: string, phaseId: string, checkpointId: string): string {
  return `phase-complete:${runId}:${phaseId}:${checkpointId}`;
}

export function phaseBlockKey(runId: string, phaseId: string, failureKind: string): string {
  return `phase-block:${runId}:${phaseId}:${failureKind}`;
}

export function phaseCheckpointKey(runId: string, phaseId: string, commitSha: string): string {
  return `phase-checkpoint:${runId}:${phaseId}:${commitSha}`;
}

/** `resume:<taskId>:<sourceRunId>:<sourceLeaseEpoch>:<sourceCheckpointId>` —
 * empty segments collapse to `none`; never Date.now(). */
export function resumeTaskRunKey(
  taskId: string,
  sourceRunId: string,
  sourceLeaseEpoch: string | number | null | undefined,
  sourceCheckpointId: string | null | undefined,
): string {
  return `resume:${keySegment(taskId)}:${keySegment(sourceRunId)}:${keySegment(sourceLeaseEpoch)}:${keySegment(sourceCheckpointId)}`;
}

/** Server-matching canonicalization: begin/block request hashes drop
 * `leaseEpoch` (fence, not identity) and free-text `reason`; phase/action/
 * failureKind/checkpointId stay identity. */
export function canonicalPhaseProgressRequest(action: PhaseProgressAction, body: Record<string, unknown>): string {
  const clone: Record<string, unknown> = { ...body };
  delete clone.leaseEpoch;
  if (action === "begin" || action === "block") {
    delete clone.reason;
  }
  return canonicalJsonSorted(clone);
}

export function canonicalPhaseProgressRequestHash(action: PhaseProgressAction, body: Record<string, unknown>): string {
  return createHash("sha256").update(canonicalPhaseProgressRequest(action, body), "utf8").digest("hex");
}

function boundedStringArray(value: unknown, label: string): string[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 100 || !value.every((item) => typeof item === "string" && item.length <= 500)) {
    throw new Error(`kaneo-execution: ${label} must contain at most 100 strings of <= 500 chars`);
  }
  return [...value];
}

function boundedRecord(value: unknown, label: string): Record<string, unknown> {
  if (value === undefined) return {};
  if (!isRecord(value)) throw new Error(`kaneo-execution: ${label} must be an object`);
  return value;
}

function validateGuardReceipt(value: unknown): GuardReceipt {
  if (
    !isRecord(value) ||
    typeof value.receiptId !== "string" ||
    typeof value.remoteRef !== "string" ||
    typeof value.headSha !== "string" ||
    typeof value.commitSha !== "string" ||
    typeof value.receiptHash !== "string"
  ) {
    throw new Error("kaneo-execution: checkpoint requires a complete Git push durability receipt");
  }
  return value as GuardReceipt;
}

function parseCurrentBranch(output: string | undefined): string {
  const firstLine = output?.split(/\r?\n/, 1)[0]?.trim() ?? "";
  if (!firstLine.startsWith("## ")) return "";
  return firstLine.slice(3).split("...", 1)[0].trim();
}

function requestKey(operation: string, taskId: string): string {
  return `pi-execution-${operation}-${taskId}-${randomUUID()}`.slice(0, 200);
}

export class KaneoExecutionRuntime {
  private activeLease: ActiveLease | null = null;
  private lastPersisted: PersistedExecutionState | null = null;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private gitMutationTail: Promise<void> = Promise.resolve();
  private heartbeatFailureNotified = false;

  private readonly client: ExecutionRuntimeClient;

  constructor(
    private readonly pi: ExtensionAPI,
    private readonly ctx: ExtensionContext,
    client: Partial<ExecutionRuntimeClient> = {},
  ) {
    this.client = { ...DEFAULT_CLIENT, ...client };
    this.restoreState();
  }

  restoreState(): void {
    const entries = this.ctx.sessionManager.getEntries();
    for (let index = entries.length - 1; index >= 0; index -= 1) {
      const entry = entries[index];
      if (entry.type !== "custom" || entry.customType !== EXECUTION_STATE_ENTRY) continue;
      const data = entry.data as Partial<PersistedExecutionState> | undefined;
      if (
        (data?.version === 1 || data?.version === 2) &&
        typeof data.taskId === "string" &&
        typeof data.projectId === "string" &&
        typeof data.runId === "string" &&
        typeof data.state === "string" &&
        typeof data.agentPrincipalId === "string" &&
        typeof data.hostId === "string" &&
        typeof data.branchName === "string" &&
        Array.isArray(data.scope) &&
        data.scope.every((item) => typeof item === "string") &&
        typeof data.updatedAt === "string"
      ) {
        this.lastPersisted = data as PersistedExecutionState;
        return;
      }
    }
  }

  stop(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
    // Deliberately do not release the lease on session shutdown. A restart
    // must not silently mutate server state; the server expiry/orphan path is
    // authoritative, and the next session can reconcile before reclaiming.
    this.activeLease = null;
  }

    /** T5/T4: parent tools need the host-configured principal identity. */
  async getConfig(): Promise<ExecutionConfig | null> {
    try {
      return await this.readExecutionConfig();
    } catch {
      return null;
    }
  }

  async getContext(taskIdInput: string, projectIdInput?: string, signal?: AbortSignal): Promise<ExecutionContextPack> {
    const taskId = safeId(taskIdInput, "task id");
    const task = await this.client.getKaneoTask(taskId, signal);
    const projectId = safeId(task.projectId, "project id");
    if (projectIdInput && projectIdInput !== projectId) {
      throw new Error("kaneo-execution: supplied projectId does not match the task");
    }

    const [manifest, relations, agents, runs] = await Promise.all([
      this.client.getExecutionManifest(projectId, signal),
      this.client.getTaskRelations(taskId, signal),
      this.client.listExecutionAgents(projectId, signal),
      this.client.listTaskRuns(taskId, signal),
    ]);
    const repository = `${manifest.repositoryOwner}/${manifest.repositoryName}`;
    let hostBinding: HostBindingResult;
    let config: ExecutionConfig | null = null;
    let configBlocker: string | null = null;
    try {
      config = await this.readExecutionConfig();
      hostBinding = await this.resolveHostBinding(config, projectId, repository, signal);
    } catch (error) {
      configBlocker = errorMessage(error);
      hostBinding = {
        status: "blocked",
        hostId: config?.hostId ?? null,
        projectId,
        repository,
        reason: configBlocker,
      };
    }
    const configuredAgent = config
      ? agents.find((agent) => agent.id === config?.agentPrincipalId)
      : undefined;
    const principalBlocker = config && !configuredAgent
      ? "Configured agent principal is not active or is not allowed by this project manifest"
      : null;
    const configuredHostBlocker = config && configuredAgent && (
      configuredAgent.hostId !== config.hostId || configuredAgent.runtimeId !== config.hostId
    )
      ? "Server principal runtimeId/hostId does not match the canonical host-local identity"
      : null;
    const blocker = configBlocker || principalBlocker || configuredHostBlocker;
    const lastRunForTask = this.lastPersisted?.taskId === taskId ? this.lastPersisted : null;
    const safeRuns = runs.map(sanitizeRun);
    const currentRunId = this.activeLease?.run.id ?? lastRunForTask?.runId;
    const currentRun = currentRunId
      ? safeRuns.find((run) => run.id === currentRunId) ?? null
      : null;

    return {
      task: sanitizeTask(task),
      manifest: sanitizeManifest(manifest),
      agents: agents.map(sanitizeAgent),
      runs: safeRuns,
      relations,
      currentRun,
      verification: {
        profile: manifest.verificationProfile,
        docs: [...manifest.docs],
        policy: { ...manifest.policy },
      },
      hostBinding,
      worker: {
        configuredAgentPrincipalId: config?.agentPrincipalId ?? null,
        configuredHostId: config?.hostId ?? null,
        configuredRuntimeId: configuredAgent?.runtimeId ?? null,
        resumeRequired: Boolean(lastRunForTask && !this.activeLease),
        blocker,
      },
    };
  }

  async getReview(
    taskIdInput: string,
    runIdInput: string,
    signal?: AbortSignal,
  ): Promise<{
    run: Omit<KaneoTaskRunRecord, "leaseToken">;
    evidence: KaneoTaskRunEvidenceRecord[];
  }> {
    const taskId = safeId(taskIdInput, "task id");
    const runId = safeId(runIdInput, "run id");
    const [run, evidence] = await Promise.all([
      this.client.getTaskRun(taskId, runId, signal),
      this.client.listTaskRunEvidence(taskId, runId, signal),
    ]);
    if (run.taskId !== taskId || run.id !== runId) {
      throw new Error("kaneo-execution: server returned a review record for another task/run");
    }
    return { run: sanitizeRun(run), evidence };
  }

  // -------------------------------------------------------------------------
  // FULL-run phase protocol (SPEC-kaneo-phase-cards-full-run-runtime-v0-1)
  // runId/leaseEpoch/leaseToken derive from the in-memory ActiveLease; the
  // model never supplies or sees them.
  // -------------------------------------------------------------------------

  /** Bounded getter: phase map snapshot + progress ledger for the active run. */
  async getPhaseLedger(taskIdInput: string, signal?: AbortSignal): Promise<PhaseProgressSnapshot> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    return this.client.getPhaseProgress(taskId, active.run.id, signal);
  }

  private async postPhaseProgressFenced(
    taskId: string,
    body: Record<string, unknown>,
    requestKey: string,
    signal?: AbortSignal,
  ): Promise<PhaseProgressSnapshot> {
    const active = this.requireActive(taskId);
    try {
      return await this.client.postPhaseProgress(
        taskId,
        active.run.id,
        active.run.leaseEpoch,
        active.leaseToken,
        body,
        requestKey,
        signal,
      );
    } catch (error) {
      if (this.isLeaseFenceError(error)) this.markLeaseLost(error);
      throw error;
    }
  }

  async beginPhase(taskIdInput: string, phaseId: string, signal?: AbortSignal): Promise<PhaseProgressSnapshot> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    const expectedRunRevision = typeof active.run.runRevision === "number" ? active.run.runRevision : undefined;
    return this.postPhaseProgressFenced(
      taskId,
      {
        phaseId,
        action: "begin",
        ...(expectedRunRevision === undefined ? {} : { expectedRunRevision }),
      },
      phaseBeginKey(active.run.id, phaseId),
      signal,
    );
  }

  async completePhase(
    taskIdInput: string,
    phaseId: string,
    checkpointId: string,
    signal?: AbortSignal,
  ): Promise<PhaseProgressSnapshot> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    const expectedRunRevision = typeof active.run.runRevision === "number" ? active.run.runRevision : undefined;
    return this.postPhaseProgressFenced(
      taskId,
      {
        phaseId,
        action: "complete",
        checkpointId,
        ...(expectedRunRevision === undefined ? {} : { expectedRunRevision }),
      },
      phaseCompleteKey(active.run.id, phaseId, checkpointId),
      signal,
    );
  }

  /** Atomic block: blocker + evidence + lease release + run blocked in one
   * fenced server transaction. Never split into legacy report + release. */
  async blockPhase(
    taskIdInput: string,
    phaseId: string,
    failureKind: string,
    reason?: string,
    retryAt?: string,
    signal?: AbortSignal,
  ): Promise<PhaseProgressSnapshot> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    const expectedRunRevision = typeof active.run.runRevision === "number" ? active.run.runRevision : undefined;
    return this.postPhaseProgressFenced(
      taskId,
      {
        phaseId,
        action: "block",
        failureKind,
        ...(reason ? { reason } : {}),
        ...(retryAt ? { retryAt } : {}),
        ...(expectedRunRevision === undefined ? {} : { expectedRunRevision }),
      },
      phaseBlockKey(active.run.id, phaseId, failureKind),
      signal,
    );
  }

  /** Dedicated phase checkpoint: runtime fetches the map snapshot for
   * specSha256/sourcePhaseMapSha256, adds lease epoch/token from ActiveLease,
   * and requires checkpointId in the response (also on stored replay). */
  async createPhaseCheckpoint(
    taskIdInput: string,
    input: Record<string, unknown>,
    signal?: AbortSignal,
  ): Promise<PhaseCheckpointRecord> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    const phaseId = input.phaseId;
    if (typeof phaseId !== "string" || !PHASE_ID_RUNTIME_PATTERN.test(phaseId)) {
      throw new Error("kaneo-execution: phase checkpoint requires phaseId matching P<number>");
    }
    const headSha = safeSha(input.headSha, "headSha");
    const commitSha = safeSha(input.commitSha, "commitSha");
    if (headSha.toLowerCase() !== commitSha.toLowerCase()) {
      throw new Error("kaneo-execution: phase checkpoint headSha must equal commitSha");
    }
    const baseSha = safeSha(input.baseSha ?? active.run.baseSha, "baseSha");
    const guardReceipt = validateGuardReceipt(input.guardReceipt);
    if (
      guardReceipt.remoteRef !== active.run.branchName ||
      guardReceipt.headSha.toLowerCase() !== headSha.toLowerCase() ||
      guardReceipt.commitSha.toLowerCase() !== commitSha.toLowerCase()
    ) {
      throw new Error("kaneo-execution: phase checkpoint receipt does not bind this run branch and commit");
    }
    const commands = boundedStringArray(input.commands, "phase checkpoint commands");
    const artifactHashes = boundedRecord(input.artifactHashes, "phase checkpoint artifactHashes");

    // Runtime-derived hashes: never model-supplied, taken from the map snapshot.
    const snapshot = await this.client.getPhaseProgress(taskId, active.run.id, signal);
    const specSha256 = typeof snapshot.specSha256 === "string" ? snapshot.specSha256 : "";
    const sourcePhaseMapSha256 = typeof snapshot.sourcePhaseMapSha256 === "string" ? snapshot.sourcePhaseMapSha256 : "";
    if (!/^[0-9a-f]{64}$/i.test(specSha256) || !/^[0-9a-f]{64}$/i.test(sourcePhaseMapSha256)) {
      throw new Error("kaneo-execution: phase progress snapshot did not provide specSha256/sourcePhaseMapSha256");
    }
    const expectedRunRevision = typeof active.run.runRevision === "number" ? active.run.runRevision : undefined;
    try {
      const record = await this.client.createPhaseCheckpoint(
        taskId,
        active.run.id,
        active.run.leaseEpoch,
        active.leaseToken,
        {
          phaseId,
          headSha,
          commitSha,
          baseSha,
          guardReceipt,
          commands,
          artifactHashes,
          specSha256,
          sourcePhaseMapSha256,
          ...(expectedRunRevision === undefined ? {} : { expectedRunRevision }),
        },
        phaseCheckpointKey(active.run.id, phaseId, commitSha),
        signal,
      );
      if (typeof record.checkpointId !== "string" || !SAFE_ID_PATTERN.test(record.checkpointId)) {
        throw new Error("kaneo-execution: phase checkpoint response missing checkpointId");
      }
      return record;
    } catch (error) {
      if (this.isLeaseFenceError(error)) this.markLeaseLost(error);
      throw error;
    }
  }

  /** Deterministic resume request key: `resume:<taskId>:<sourceRunId>:
   * <sourceLeaseEpoch>:<sourceCheckpointId>` — the runtime GETs the run to
   * read the current epoch + latest checkpoint; empty segments become `none`. */
  async buildResumeRequestKey(taskIdInput: string, runIdInput: string, signal?: AbortSignal): Promise<string> {
    const taskId = safeId(taskIdInput, "task id");
    const runId = safeId(runIdInput, "run id");
    const run = await this.client.getTaskRun(taskId, runId, signal);
    const record = run as KaneoTaskRunRecord & { lastCheckpointId?: unknown };
    const epoch = typeof run.leaseEpoch === "number" ? run.leaseEpoch : null;
    const checkpointId = typeof record.lastCheckpointId === "string" && record.lastCheckpointId
      ? record.lastCheckpointId
      : null;
    return resumeTaskRunKey(taskId, runId, epoch, checkpointId);
  }

  async review(
    taskIdInput: string,
    runIdInput: string,
    input: Record<string, unknown>,
    signal?: AbortSignal,
  ): Promise<{
    run: Omit<KaneoTaskRunRecord, "leaseToken">;
    verification?: GuardResult;
  }> {
    const taskId = safeId(taskIdInput, "task id");
    const runId = safeId(runIdInput, "run id");
    const decision = input.decision;
    if (decision !== "approve" && decision !== "reject") {
      throw new Error("kaneo-execution: review decision must be approve or reject");
    }
    const action = input.action;
    if (action !== undefined && action !== "none" && action !== "create_pr" && action !== "merge") {
      throw new Error("kaneo-execution: review action must be none, create_pr or merge");
    }
    const review = await this.getReview(taskId, runId, signal);
    const reviewScope = review.run.scope;
    const reviewBranch = review.run.branchName;
    const reviewBaseBranch = review.run.baseBranch;
    if (
      !Array.isArray(reviewScope) ||
      !reviewScope.every((scope) => typeof scope === "string") ||
      typeof reviewBranch !== "string" ||
      typeof reviewBaseBranch !== "string"
    ) {
      throw new Error("kaneo-execution: server returned incomplete review branch/scope data");
    }
    let verification: GuardResult | undefined;
    let apiVerification: Record<string, unknown> | undefined;
    let apiPrResult: Record<string, unknown> | undefined;
    if (decision === "approve") {
      const context = await this.getContext(taskId, undefined, signal);
      const worker = context.agents.find((agent) => agent.id === review.run.agentPrincipalId);
      if (!worker) throw new Error("kaneo-execution: review worker principal is not active in this project");
      if (context.hostBinding.status !== "configured") {
        throw new Error(`kaneo-execution: parent diff review blocked: ${context.hostBinding.reason ?? "host binding unavailable"}`);
      }
      const config = await this.readExecutionConfig();
      // Refresh refs before inspecting the immutable base...worker range. This
      // is read-only Git metadata work; the guard still owns path/branch gates.
      await this.runGuard("fetch", {
        config,
        projectId: context.manifest.projectId,
        repository: context.hostBinding.repository,
        scope: reviewScope,
        yes: true,
        signal,
      });
      verification = await this.runGuard("review", {
        config,
        projectId: context.manifest.projectId,
        repository: context.hostBinding.repository,
        agent: worker.runtimeId,
        taskId,
        runId,
        branch: reviewBranch,
        baseBranch: reviewBaseBranch,
        scope: reviewScope,
        signal,
      });
      if (
        !verification.base_sha ||
        !verification.commit_sha ||
        !verification.changed_files?.length ||
        verification.diff_within_scope !== true ||
        verification.branch_valid !== true
      ) {
        throw new Error("kaneo-execution: parent Git review returned incomplete evidence");
      }
      if (input.testsPassed !== true) {
        throw new Error("kaneo-execution: parent approval requires testsPassed=true");
      }
      const rawCommands = input.testCommands;
      if (
        !Array.isArray(rawCommands) ||
        rawCommands.length === 0 ||
        rawCommands.some((command) => typeof command !== "string" || !command.trim())
      ) {
        throw new Error("kaneo-execution: parent approval requires bounded testCommands evidence");
      }
      const testCommands = rawCommands.map((command) => command.trim()).slice(0, 100);
      apiVerification = {
        verificationProfile: context.manifest.verificationProfile,
        baseSha: verification.base_sha,
        commitSha: verification.commit_sha,
        changedFiles: verification.changed_files,
        commands: [...(verification.commands ?? []), ...testCommands].slice(0, 100),
        diffWithinScope: true,
        branchValid: true,
        testsPassed: true,
      };
      if (action && action !== "none" && context.manifest.policy[action === "create_pr" ? "allowPrCreate" : "allowMerge"] === true) {
        let existingPrNumber = typeof review.run.prNumber === "number" ? review.run.prNumber : undefined;
        // SPEC-kaneo-wavefix-v0-2 (T13): one finalize call — merge without a
        // PR auto-creates it through the same guard instead of failing with
        // pr_conflict. A create failure surfaces as a BLOCKED prResult.
        if (action === "merge" && (!existingPrNumber || existingPrNumber < 1)) {
          if (!config.prGuardPath || context.manifest.policy.allowPrCreate !== true) {
            apiPrResult = {
              status: "BLOCKED",
              operation: action,
              blocker: "policy_blocked",
              reason: "merge requires a PR but allowPrCreate is not enabled",
            };
          } else {
            const createAdapter = await this.runPrGuard("create_pr", {
              config,
              projectId: context.manifest.projectId,
              repository: context.hostBinding.repository,
              agent: worker.runtimeId,
              taskId,
              runId,
              branch: reviewBranch,
              baseBranch: reviewBaseBranch,
              prNumber: undefined,
              signal,
            });
            if (
              createAdapter.status === "PASS" &&
              typeof createAdapter.pr_number === "number" &&
              createAdapter.pr_number > 0
            ) {
              existingPrNumber = createAdapter.pr_number;
            } else {
              apiPrResult = {
                status: createAdapter.status,
                operation: action,
                prNumber: createAdapter.pr_number,
                prUrl: createAdapter.pr_url,
                prState: createAdapter.pr_state,
                blocker:
                  createAdapter.blocker === "merge_conflict"
                    ? "pr_create_failed"
                    : createAdapter.blocker ?? "pr_create_failed",
                reason: createAdapter.reason,
              };
            }
          }
        }
        if (apiPrResult === undefined && config.prGuardPath) {
          const adapter = await this.runPrGuard(action, {
            config,
            projectId: context.manifest.projectId,
            repository: context.hostBinding.repository,
            agent: worker.runtimeId,
            taskId,
            runId,
            branch: reviewBranch,
            baseBranch: reviewBaseBranch,
            prNumber: existingPrNumber,
            signal,
          });
          if (adapter.status !== "PASS" && adapter.status !== "BLOCKED") {
            throw new Error("kaneo-execution: PR adapter returned an invalid status");
          }
          if (
            action === "merge" &&
            adapter.status === "PASS" &&
            !adapter.merge_commit_sha
          ) {
            throw new Error("kaneo-execution: PR adapter returned no merge commit SHA");
          }
          apiPrResult = {
            status: adapter.status,
            operation: action,
            prNumber: adapter.pr_number,
            prUrl: adapter.pr_url,
            prState: adapter.pr_state,
            mergeCommitSha: adapter.merge_commit_sha,
            blocker: adapter.blocker,
            reason: adapter.reason,
          };
        }
      }
    } else if (typeof input.reason !== "string" || !input.reason.trim()) {
      throw new Error("kaneo-execution: parent rejection requires a reason");
    }

    const reviewHeadSha =
      decision === "approve"
        ? verification?.commit_sha
        : typeof review.run.commitSha === "string"
          ? review.run.commitSha
          : undefined;
    if (decision === "reject" && !reviewHeadSha) {
      throw new Error("kaneo-execution: parent rejection requires the reviewed run commit SHA");
    }
    if (decision === "approve" && action === "merge" && !reviewHeadSha) {
      throw new Error("kaneo-execution: parent merge requires the reviewed run commit SHA");
    }

    const updated = await this.client.reviewTaskRun(
      taskId,
      runId,
      {
        decision,
        action: action as "none" | "create_pr" | "merge" | undefined,
        reason: typeof input.reason === "string" ? input.reason.trim() : undefined,
        verification: apiVerification,
        prResult: apiPrResult,
        reviewHeadSha,
      },
      requestKey("review", taskId),
      signal,
    );
    const task = await this.client.getKaneoTask(taskId, signal);
    this.persistRun(updated, task.projectId);
    return { run: sanitizeRun(updated), verification };
  }

  async claim(taskIdInput: string, scopeInput: string[], signal?: AbortSignal): Promise<Omit<KaneoTaskRunRecord, "leaseToken">> {
    const taskId = safeId(taskIdInput, "task id");
    const scope = validateScope(scopeInput);
    if (this.activeLease) {
      if (this.activeLease.run.taskId === taskId) return sanitizeRun(this.activeLease.run);
      throw new Error("kaneo-execution: another task run is already active in this Pi process");
    }

    const config = await this.readExecutionConfig();
    const context = await this.getContext(taskId, undefined, signal);
    if (context.hostBinding.status !== "configured") {
      throw new Error(`kaneo-execution: host binding blocked: ${context.hostBinding.reason ?? "unknown blocker"}`);
    }
    if (context.worker.blocker) throw new Error(`kaneo-execution: claim blocked: ${context.worker.blocker}`);
    const principal = context.agents.find((agent) => agent.id === config.agentPrincipalId);
    if (!principal || !principal.scopes.includes("run:claim") || !principal.isActive) {
      throw new Error("kaneo-execution: configured principal cannot claim this task");
    }

    const claimed = await this.client.claimTaskRun(
      taskId,
      config.agentPrincipalId,
      scope,
      requestKey("claim", taskId),
      signal,
    );
    if (!claimed.leaseToken) {
      throw new Error("kaneo-execution: server did not return a one-time lease token; refusing to continue");
    }
    if (
      claimed.taskId !== taskId ||
      claimed.agentPrincipalId !== config.agentPrincipalId ||
      claimed.hostId !== config.hostId ||
      claimed.leaseActive !== true
    ) {
      await this.tryRelease(claimed, claimed.leaseToken, "failed", taskId);
      throw new Error("kaneo-execution: server returned a run outside the configured principal/host fence");
    }

    try {
      await this.runGuard("validate", {
        config,
        projectId: context.manifest.projectId,
        repository: context.hostBinding.repository,
        agent: principal.runtimeId,
        taskId,
        runId: claimed.id,
        branch: claimed.branchName,
        baseBranch: claimed.baseBranch,
        scope: claimed.scope,
        signal,
      });
    } catch (error) {
      await this.tryRelease(claimed, claimed.leaseToken, "failed", taskId);
      throw new Error(`kaneo-execution: claimed run failed local Git guard: ${errorMessage(error)}`);
    }

    this.activeLease = {
      run: claimed,
      leaseToken: claimed.leaseToken,
      runtimeId: principal.runtimeId,
      projectId: context.manifest.projectId,
      worktreePath: null,
    };
    this.heartbeatFailureNotified = false;
    this.persistRun(claimed, context.manifest.projectId);
    this.startHeartbeat();
    // SPEC-kaneo-wavefix-v0-2 (T9): machine-enforced progress marker. The
    // E2E proved an LLM cannot be trusted to post it. Best-effort: a failed
    // comment API call must never block the run; the next heartbeat retry
    // happens naturally because the marker is tied to the active lease.
    void this.client
      .createTaskComment(
        taskId,
        `[⭕ DOING] ${claimed.id} epoch ${claimed.leaseEpoch} claimed by ${config.agentPrincipalId} — starting implementation`,
      )
      .catch(() => {});
    return sanitizeRun(claimed);
  }

  async prepareCheckout(
    taskIdInput: string,
    signal?: AbortSignal,
  ): Promise<{
    run: Omit<KaneoTaskRunRecord, "leaseToken">;
    checkoutReady: true;
    currentBranch: string;
    worktreePath: string | null;
  }> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    const config = await this.readExecutionConfig();
    const repository = `${active.run.repositoryOwner}/${active.run.repositoryName}`;
    const currentStatus = await this.runGuard("status", {
      config,
      projectId: active.projectId,
      repository,
      scope: active.run.scope,
      signal,
    });
    const currentBranch = parseCurrentBranch(currentStatus.output);
    if (currentBranch === active.run.branchName) {
      // Legacy checkout already on the run branch (pre-worktree run).
      return { run: sanitizeRun(active.run), checkoutReady: true, currentBranch, worktreePath: null };
    }
    const hostBinding = await this.resolveHostBinding(config, active.projectId, repository, signal);
    if (hostBinding.status !== "configured" || !hostBinding.worktreeRoot) {
      throw new Error("kaneo-execution: host binding has no worktreeRoot; worker runs require a run worktree");
    }
    if (currentBranch !== active.run.baseBranch) {
      throw new Error(`kaneo-execution: checkout is on ${currentBranch || "an unknown branch"}; expected the manifest base branch or this run branch`);
    }

    await this.runGuard("fetch", {
      config,
      projectId: active.projectId,
      repository,
      scope: active.run.scope,
      yes: true,
      signal,
    });
    const created = await this.runGuard("worktree-add", {
      config,
      projectId: active.projectId,
      repository,
      agent: active.runtimeId,
      taskId,
      runId: active.run.id,
      branch: active.run.branchName,
      baseBranch: active.run.baseBranch,
      // SPEC-kaneo-native-telegram-control-v0-1: branch from the exact bound
      // SHA (claim head or resumed checkpoint), never from mutable base.
      startSha: active.run.baseSha ?? undefined,
      yes: true,
      signal,
    });
    if (!created.worktree_path) {
      throw new Error("kaneo-execution: worktree-add did not return the run worktree path");
    }
    if (this.activeLease && this.activeLease.run.id === active.run.id) {
      this.activeLease.worktreePath = created.worktree_path;
    }
    this.persistRun(active.run, active.projectId, created.worktree_path);
    return {
      run: sanitizeRun(active.run),
      checkoutReady: true,
      currentBranch: active.run.branchName,
      worktreePath: created.worktree_path,
    };
  }

  async commitTaskBranch(
    taskIdInput: string,
    messageInput: string,
    signal?: AbortSignal,
  ): Promise<GitMutationResult> {
    return this.runGitMutation("commit", taskIdInput, messageInput, signal);
  }

  async pushTaskBranch(
    taskIdInput: string,
    signal?: AbortSignal,
  ): Promise<GitMutationResult> {
    return this.runGitMutation("push", taskIdInput, undefined, signal);
  }

  async checkpointTaskRun(
    taskIdInput: string,
    input: Record<string, unknown>,
    signal?: AbortSignal,
  ): Promise<CheckpointResult> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    const suppliedHead = input.headSha;
    const suppliedCommit = input.commitSha;
    const suppliedReceipt = input.guardReceipt;
    const hasSuppliedDurability = suppliedHead !== undefined || suppliedCommit !== undefined || suppliedReceipt !== undefined;

    let baseSha: string;
    let commitSha: string;
    let guardReceipt: GuardReceipt;
    if (hasSuppliedDurability) {
      if (suppliedHead === undefined || suppliedCommit === undefined || !isRecord(suppliedReceipt)) {
        throw new Error("kaneo-execution: checkpoint retry requires headSha, commitSha and guardReceipt together");
      }
      baseSha = safeSha(input.baseSha ?? active.run.baseSha, "baseSha");
      commitSha = safeSha(suppliedCommit, "commitSha");
      const headSha = safeSha(suppliedHead, "headSha");
      if (headSha.toLowerCase() !== commitSha.toLowerCase()) {
        throw new Error("kaneo-execution: checkpoint headSha must equal commitSha");
      }
      guardReceipt = validateGuardReceipt(suppliedReceipt);
      if (
        guardReceipt.remoteRef !== active.run.branchName ||
        guardReceipt.headSha.toLowerCase() !== headSha.toLowerCase() ||
        guardReceipt.commitSha.toLowerCase() !== commitSha.toLowerCase()
      ) {
        throw new Error("kaneo-execution: checkpoint receipt does not bind this run branch and commit");
      }
    } else {
      if (typeof input.message !== "string" || !input.message.trim()) {
        throw new Error("kaneo-execution: checkpoint message is required for a new checkpoint");
      }
      const committed = await this.commitTaskBranch(taskId, input.message, signal);
      const pushed = await this.pushTaskBranch(taskId, signal);
      if (!pushed.guardReceipt) {
        throw new Error("kaneo-execution: checkpoint push did not return a durability receipt");
      }
      baseSha = committed.baseSha;
      commitSha = pushed.commitSha;
      guardReceipt = validateGuardReceipt(pushed.guardReceipt);
    }

    const commands = boundedStringArray(input.commands, "checkpoint commands");
    const artifactHashes = boundedRecord(input.artifactHashes, "checkpoint artifactHashes");
    const verifyResult = boundedRecord(input.verifyResult, "checkpoint verifyResult");

    const current = this.requireActive(taskId);
    const expectedRunRevision = typeof current.run.runRevision === "number" ? current.run.runRevision : undefined;
    const updated = await this.client.createTaskRunCheckpoint(
      taskId,
      current.run.id,
      current.run.leaseEpoch,
      current.leaseToken,
      {
        baseSha,
        headSha: commitSha,
        commitSha,
        guardReceipt,
        commands,
        artifactHashes,
        verifyResult,
        ...(expectedRunRevision === undefined ? {} : { expectedRunRevision }),
      },
      `pi-execution-checkpoint-${current.run.id}-${commitSha}`,
      signal,
    );
    this.assertReturnedLease(current, updated, taskId);
    current.run = { ...updated, leaseToken: current.leaseToken };
    this.persistRun(updated, current.projectId, current.worktreePath);

    const phase = typeof verifyResult.phase === "string" && verifyResult.phase.trim()
      ? verifyResult.phase.replace(/\s+/g, " ").trim().slice(0, 120)
      : "checkpoint";
    const marker = `[kaneo-checkpoint:${current.run.id}:${commitSha}]`;
    let commentCreated = false;
    let commentId: string | undefined;
    try {
      const comments = await this.client.listTaskComments(taskId, signal);
      const existing = comments.find((comment) => typeof comment.content === "string" && comment.content.includes(marker));
      if (existing) {
        commentId = existing.id;
      } else {
        const comment = await this.client.createTaskComment(
          taskId,
          `${marker}\n\n[Kaneo] Checkpoint\nPhase: ${phase}\nBranch: ${current.run.branchName}\nCommit: ${commitSha}`,
          `pi-execution-checkpoint-comment-${current.run.id}-${commitSha}`,
          signal,
        );
        commentId = comment.id;
        commentCreated = true;
      }
    } catch (error) {
      this.ctx.ui.notify(`Kaneo checkpoint đã durable nhưng comment milestone lỗi: ${errorMessage(error)}`, "warning");
    }

    return {
      run: sanitizeRun(updated),
      baseSha,
      commitSha,
      branch: current.run.branchName,
      guardReceipt,
      commentCreated,
      ...(commentId ? { commentId } : {}),
    };
  }

  async heartbeat(taskIdInput: string, signal?: AbortSignal): Promise<Omit<KaneoTaskRunRecord, "leaseToken">> {
    const taskId = safeId(taskIdInput, "task id");
    const active = this.requireActive(taskId);
    let updated: KaneoTaskRunRecord;
    try {
      updated = await this.client.heartbeatTaskRun(
        taskId,
        active.run.id,
        active.run.leaseEpoch,
        active.leaseToken,
        requestKey("heartbeat", taskId),
        signal,
      );
    } catch (error) {
      if (this.isLeaseFenceError(error)) this.markLeaseLost(error);
      throw error;
    }
    this.assertReturnedLease(active, updated, taskId);
    active.run = { ...updated, leaseToken: active.leaseToken };
    this.heartbeatFailureNotified = false;
    return sanitizeRun(updated);
  }

  async report(
    taskIdInput: string,
    input: Record<string, unknown>,
    signal?: AbortSignal,
  ): Promise<Omit<KaneoTaskRunRecord, "leaseToken">> {
    const taskId = safeId(taskIdInput, "task id");
    const state = input.state;
    if (typeof state !== "string" || !WORKER_REPORT_STATES.has(state)) {
      throw new Error(
        "kaneo-execution: worker may report only in_progress, in_review, blocked_quota, blocked_input, blocked_clarification, blocked_branch_drift or failed",
      );
    }
    const active = this.requireActive(taskId);
    const reportInput: Record<string, unknown> = {};
    for (const field of REPORT_FIELDS) {
      if (input[field] !== undefined) reportInput[field] = input[field];
    }
    let updated: KaneoTaskRunRecord;
    try {
      updated = await this.client.reportTaskRun(
        taskId,
        active.run.id,
        active.run.leaseEpoch,
        active.leaseToken,
        { state, ...reportInput },
        requestKey("report", taskId),
        signal,
      );
    } catch (error) {
      if (this.isLeaseFenceError(error)) this.markLeaseLost(error);
      throw error;
    }
    this.assertReturnedLease(active, updated, taskId, state === "in_review");
    if (state === "in_review") {
      this.persistRun(updated, active.projectId);
      this.stop();
      // SPEC-kaneo-wavefix-v0-2 (T9b): terminal/lane-change fallback marker,
      // machine-enforced like the DOING marker. Best-effort, never blocks.
      void this.client
        .createTaskComment(
          taskId,
          `[✅ DONE] ${active.run.id} epoch ${active.run.leaseEpoch} reported in_review by ${active.run.agentPrincipalId} — awaiting parent review`,
        )
        .catch(() => {});
      // RPC workers stay alive until explicitly shut down. Request graceful
      // shutdown after the terminal worker report so the runner writes its
      // exit receipt and does not leak an idle tmux/Pi process.
      if (typeof this.ctx.shutdown === "function") this.ctx.shutdown();
      return sanitizeRun(updated);
    }
    if (state === "failed") {
      this.persistRun(updated, active.projectId);
      void this.client
        .createTaskComment(
          taskId,
          `[❌ FAILED] ${active.run.id} epoch ${active.run.leaseEpoch} reported failed by ${active.run.agentPrincipalId} — see notification for details`,
        )
        .catch(() => {});
      if (typeof this.ctx.shutdown === "function") this.ctx.shutdown();
    }
    active.run = { ...updated, leaseToken: active.leaseToken };
    this.persistRun(updated, active.projectId);
    return sanitizeRun(updated);
  }

  async release(
    taskIdInput: string,
    state: string | undefined,
    signal?: AbortSignal,
  ): Promise<Omit<KaneoTaskRunRecord, "leaseToken">> {
    const taskId = safeId(taskIdInput, "task id");
    if (
      state &&
      !new Set([
        "blocked_quota",
        "blocked_input",
        "blocked_clarification",
        "blocked_branch_drift",
        "failed",
        "cancelled",
        "superseded",
        "orphaned",
        "in_progress",
        "in_review",
      ]).has(state)
    ) {
      throw new Error("kaneo-execution: release state is not a worker state");
    }
    const active = this.requireActive(taskId);
    let updated: KaneoTaskRunRecord;
    try {
      updated = await this.client.releaseTaskRun(
        taskId,
        active.run.id,
        active.run.leaseEpoch,
        active.leaseToken,
        state,
        requestKey("release", taskId),
        signal,
      );
    } catch (error) {
      if (this.isLeaseFenceError(error)) this.markLeaseLost(error);
      throw error;
    }
    this.persistRun(updated, active.projectId);
    this.stop();
    return sanitizeRun(updated);
  }

  private requireActive(taskId: string): ActiveLease {
    if (!this.activeLease) {
      if (this.lastPersisted?.taskId === taskId) {
        throw new Error("kaneo-execution: this session has a previous run but no lease token; reconcile and reclaim after server expiry instead of duplicating it");
      }
      throw new Error("kaneo-execution: no active in-memory worker lease; claim the task first");
    }
    if (this.activeLease.run.taskId !== taskId) {
      throw new Error("kaneo-execution: requested task is not the active worker lease");
    }
    return this.activeLease;
  }

  private assertReturnedLease(
    active: ActiveLease,
    updated: KaneoTaskRunRecord,
    taskId: string,
    allowInactive = false,
  ): void {
    if (
      updated.id !== active.run.id ||
      updated.taskId !== taskId ||
      updated.leaseEpoch !== active.run.leaseEpoch ||
      (!allowInactive && updated.leaseActive !== true)
    ) {
      this.stop();
      throw new Error("kaneo-execution: server returned a stale or mismatched lease fence");
    }
  }

  private async readExecutionConfig(): Promise<ExecutionConfig> {
    const secret = await this.client.readSecret();
    if (!secret.agentPrincipalId) throw new Error("host execution config missing KANEO_AGENT_PRINCIPAL_ID");
    if (!secret.hostId || !NATIVE_HOSTS.has(secret.hostId)) {
      throw new Error("host execution config requires KANEO_HOST_ID=pi-laptop or pi-prodesk");
    }
    if (!secret.gitAllowlistPath || !isAbsolute(secret.gitAllowlistPath)) {
      throw new Error("host execution config requires an absolute KANEO_GIT_ALLOWLIST_PATH");
    }
    if (!secret.gitGuardPath || !isAbsolute(secret.gitGuardPath)) {
      throw new Error("host execution config requires an absolute KANEO_GIT_GUARD_PATH");
    }
    if (secret.prGuardPath && !isAbsolute(secret.prGuardPath)) {
      throw new Error("host execution config requires an absolute KANEO_PR_GUARD_PATH when configured");
    }
    return {
      agentPrincipalId: safeId(secret.agentPrincipalId, "agent principal id"),
      hostId: secret.hostId as ExecutionConfig["hostId"],
      gitAllowlistPath: secret.gitAllowlistPath,
      gitGuardPath: secret.gitGuardPath,
      fenceBaseUrl: secret.endpoint,
      prGuardPath: secret.prGuardPath,
    };
  }

  private async resolveHostBinding(
    config: ExecutionConfig,
    projectId: string,
    repository: string,
    signal?: AbortSignal,
  ): Promise<HostBindingResult> {
    const result = await this.runGuard("resolve", {
      config,
      projectId,
      repository,
      signal,
    });
    return {
      status: "configured",
      hostId: config.hostId,
      projectId,
      repository,
      checkoutRoot: result.checkout_root,
      worktreeRoot: result.worktree_root ?? null,
    };
  }

  private async runPrGuard(
    operation: "create_pr" | "merge",
    input: {
      config: ExecutionConfig;
      projectId: string;
      repository: string;
      agent: string;
      taskId: string;
      runId: string;
      branch: string;
      baseBranch: string;
      prNumber?: number;
      signal?: AbortSignal;
    },
  ): Promise<PrGuardResult> {
    if (!input.config.prGuardPath) {
      throw new Error("kaneo-execution: PR adapter is not configured on this host");
    }
    const python = process.platform === "win32" ? "py" : "python3";
    const pythonArgs = process.platform === "win32" ? ["-3.13", input.config.prGuardPath] : [input.config.prGuardPath];
    const args = [
      ...pythonArgs,
      "--operation",
      operation === "create_pr" ? "create" : "merge",
      "--repo",
      input.repository,
      "--host-id",
      input.config.hostId,
      "--project-id",
      input.projectId,
      "--agent",
      input.agent,
      "--task-id",
      input.taskId,
      "--run-id",
      input.runId,
      "--base-branch",
      input.baseBranch,
      "--head-branch",
      input.branch,
      operation === "create_pr" ? "--allow-pr-create" : "--allow-merge",
      "--yes",
      "--json",
    ];
    if (input.prNumber !== undefined) args.push("--pr-number", String(input.prNumber));
    const result = await this.pi.exec(python, args, {
      signal: input.signal,
      timeout: 60_000,
    });
    const raw = (result.stdout || result.stderr || "").trim();
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      throw new Error(`kaneo-execution: PR adapter returned invalid JSON: ${raw.slice(0, 300)}`);
    }
    if (!parsed || typeof parsed !== "object") {
      throw new Error("kaneo-execution: PR adapter returned an invalid result");
    }
    const value = parsed as Record<string, unknown>;
    const status = value.status;
    if (status !== "PASS" && status !== "BLOCKED") {
      throw new Error("kaneo-execution: PR adapter returned no fail-closed status");
    }
    if (result.code !== 0 && status !== "BLOCKED") {
      throw new Error("kaneo-execution: PR adapter failed without a blocked result");
    }
    return {
      status,
      operation: typeof value.operation === "string" ? value.operation : undefined,
      blocker: typeof value.blocker === "string" ? value.blocker : undefined,
      reason: typeof value.reason === "string" ? value.reason.slice(0, 500) : undefined,
      pr_number: typeof value.pr_number === "number" ? value.pr_number : undefined,
      pr_url: typeof value.pr_url === "string" ? value.pr_url : undefined,
      pr_state: typeof value.pr_state === "string" ? value.pr_state : undefined,
      merge_commit_sha:
        typeof value.merge_commit_sha === "string" ? value.merge_commit_sha : undefined,
      branch: typeof value.branch === "string" ? value.branch : undefined,
      base_branch: typeof value.base_branch === "string" ? value.base_branch : undefined,
    };
  }

  private async runGuard(
    operation: "resolve" | "status" | "validate" | "fetch" | "branch" | "review" | "commit" | "push" | "worktree-add" | "worktree-remove",
    input: {
      config: ExecutionConfig;
      projectId: string;
      repository: string;
      agent?: string;
      taskId?: string;
      runId?: string;
      leaseEpoch?: number;
      fenceBaseUrl?: string;
      apiKeyFile?: string;
      leaseTokenFile?: string;
      branch?: string;
      baseBranch?: string;
      startSha?: string;
      scope?: string[];
      message?: string;
      worktree?: boolean;
      yes?: boolean;
      signal?: AbortSignal;
    },
  ): Promise<GuardResult> {
    const python = process.platform === "win32" ? "py" : "python3";
    const pythonArgs = process.platform === "win32" ? ["-3.13", input.config.gitGuardPath] : [input.config.gitGuardPath];
    const args = [
      ...pythonArgs,
      "--operation",
      operation,
      "--repo",
      input.repository,
      "--allowlist",
      input.config.gitAllowlistPath,
      "--host-id",
      input.config.hostId,
      "--project-id",
      input.projectId,
      "--json",
    ];
    if (input.agent) args.push("--agent", input.agent);
    if (input.taskId) args.push("--task-id", input.taskId);
    if (input.runId) args.push("--run-id", input.runId);
    if (input.branch) args.push("--branch", input.branch);
    if (input.baseBranch) args.push("--base-branch", input.baseBranch);
    if (input.startSha) args.push("--start-sha", input.startSha);
    for (const scope of input.scope ?? []) args.push("--scope", scope);
    if (input.message) args.push("--message", input.message);
    if (input.worktree) args.push("--worktree");
    if (operation === "commit" || operation === "push") {
      if (
        !input.runId ||
        input.leaseEpoch === undefined ||
        !input.fenceBaseUrl ||
        !input.apiKeyFile ||
        !input.leaseTokenFile
      ) {
        throw new Error("kaneo-execution: fenced Git mutation requires the active run lease");
      }
      args.push(
        "--lease-epoch",
        String(input.leaseEpoch),
        "--fence-base-url",
        input.fenceBaseUrl,
        "--api-key-file",
        input.apiKeyFile,
        "--lease-token-file",
        input.leaseTokenFile,
      );
    }
    if (input.yes) args.push("--yes");

    const result = await this.pi.exec(python, args, {
      signal: input.signal,
      timeout: 15_000,
    });
    if (result.code !== 0) {
      throw new Error(`host Git guard rejected the request: ${(result.stderr || result.stdout || "no reason").slice(0, 500)}`);
    }
    let parsed: {
      status?: unknown;
      checkout_root?: unknown;
      worktree_root?: unknown;
      worktree_path?: unknown;
      worktree_created?: unknown;
      output?: unknown;
      base_sha?: unknown;
      commit_sha?: unknown;
      changed_files?: unknown;
      diff_within_scope?: unknown;
      branch_valid?: unknown;
      base_ancestor?: unknown;
      commands?: unknown;
      guard_receipt?: unknown;
    };
    try {
      parsed = JSON.parse(result.stdout.trim()) as typeof parsed;
    } catch {
      throw new Error("host Git guard returned invalid JSON");
    }
    if (parsed.status !== "PASS") throw new Error("host Git guard did not return PASS");
    if (operation === "resolve" && typeof parsed.checkout_root !== "string") {
      throw new Error("host Git guard did not return a checkout root");
    }
    return {
      status: "PASS",
      checkout_root: typeof parsed.checkout_root === "string" ? parsed.checkout_root : undefined,
      worktree_root: typeof parsed.worktree_root === "string" ? parsed.worktree_root : undefined,
      worktree_path: typeof parsed.worktree_path === "string" ? parsed.worktree_path : undefined,
      worktree_created: parsed.worktree_created === true ? true : parsed.worktree_created === false ? false : undefined,
      output: typeof parsed.output === "string" ? parsed.output : undefined,
      base_sha: typeof parsed.base_sha === "string" ? parsed.base_sha : undefined,
      commit_sha: typeof parsed.commit_sha === "string" ? parsed.commit_sha : undefined,
      changed_files: Array.isArray(parsed.changed_files) && parsed.changed_files.every((path) => typeof path === "string")
        ? parsed.changed_files as string[]
        : undefined,
      diff_within_scope: parsed.diff_within_scope === true ? true : undefined,
      branch_valid: parsed.branch_valid === true ? true : undefined,
      base_ancestor: parsed.base_ancestor === true ? true : undefined,
      commands: Array.isArray(parsed.commands) && parsed.commands.every((command) => typeof command === "string")
        ? parsed.commands as string[]
        : undefined,
      guard_receipt: isRecord(parsed.guard_receipt) ? parsed.guard_receipt as GuardReceipt : undefined,
    };
  }

  private async runGitMutation(
    operation: "commit" | "push",
    taskIdInput: string,
    messageInput?: string,
    signal?: AbortSignal,
  ): Promise<GitMutationResult> {
    const previous = this.gitMutationTail;
    let release!: () => void;
    this.gitMutationTail = new Promise<void>((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await this.runGitMutationExclusive(operation, taskIdInput, messageInput, signal);
    } finally {
      release();
    }
  }

  private async runGitMutationExclusive(
    operation: "commit" | "push",
    taskIdInput: string,
    messageInput?: string,
    signal?: AbortSignal,
  ): Promise<GitMutationResult> {
    const taskId = safeId(taskIdInput, "task id");
    const message = messageInput?.trim();
    if (operation === "commit") {
      if (!message) throw new Error("kaneo-execution: commit message is required");
      if (message.length > 500 || /[\r\n]/.test(message)) {
        throw new Error("kaneo-execution: commit message is invalid");
      }
    }

    this.requireActive(taskId);
    await this.heartbeat(taskId, signal);
    const active = this.requireActive(taskId);
    const config = await this.readExecutionConfig();
    const repository = `${active.run.repositoryOwner}/${active.run.repositoryName}`;

    const mutationResult = await this.withFenceFiles(active, async ({ apiKeyFile, leaseTokenFile }) => {
      return this.runGuard(operation, {
        config,
        projectId: active.projectId,
        repository,
        agent: active.runtimeId,
        taskId,
        runId: active.run.id,
        leaseEpoch: active.run.leaseEpoch,
        fenceBaseUrl: config.fenceBaseUrl,
        apiKeyFile,
        leaseTokenFile,
        branch: active.run.branchName,
        baseBranch: active.run.baseBranch,
        scope: active.run.scope,
        message,
        worktree: true,
        yes: true,
        signal,
      });
    });

    const verification = await this.runGuard("review", {
      config,
      projectId: active.projectId,
      repository,
      agent: active.runtimeId,
      taskId,
      runId: active.run.id,
      branch: active.run.branchName,
      baseBranch: active.run.baseBranch,
      scope: active.run.scope,
      signal,
    });
    if (
      !verification.base_sha ||
      !verification.commit_sha ||
      verification.diff_within_scope !== true ||
      verification.branch_valid !== true
    ) {
      throw new Error("kaneo-execution: Git mutation returned incomplete scope evidence");
    }

    let guardReceipt: GuardReceipt | undefined;
    if (operation === "push") {
      const receipt = mutationResult.guard_receipt;
      if (
        !isRecord(receipt) ||
        typeof receipt.receiptId !== "string" ||
        typeof receipt.remoteRef !== "string" ||
        typeof receipt.headSha !== "string" ||
        typeof receipt.commitSha !== "string" ||
        typeof receipt.receiptHash !== "string"
      ) {
        throw new Error("kaneo-execution: Git push returned no complete remote durability receipt");
      }
      if (
        receipt.remoteRef !== active.run.branchName ||
        receipt.headSha.toLowerCase() !== verification.commit_sha.toLowerCase() ||
        receipt.commitSha.toLowerCase() !== verification.commit_sha.toLowerCase()
      ) {
        throw new Error("kaneo-execution: Git push receipt does not bind the reviewed remote branch HEAD");
      }
      guardReceipt = receipt;
    }

    active.run = { ...active.run, commitSha: verification.commit_sha };
    return {
      operation,
      run: sanitizeRun(active.run),
      baseSha: verification.base_sha,
      commitSha: verification.commit_sha,
      changedFiles: verification.changed_files ?? [],
      diffWithinScope: true,
      branchValid: true,
      commands: verification.commands ?? [],
      guardReceipt,
    };
  }

  private async withFenceFiles<T>(
    active: ActiveLease,
    callback: (files: { apiKeyFile: string; leaseTokenFile: string }) => Promise<T>,
  ): Promise<T> {
    const secret = await this.client.readSecret();
    const directory = await mkdtemp(join(tmpdir(), "kaneo-git-"));
    const apiKeyFile = join(directory, "api-key");
    const leaseTokenFile = join(directory, "lease-token");
    try {
      await writeFile(apiKeyFile, secret.apiKey, { encoding: "utf8", mode: 0o600 });
      await writeFile(leaseTokenFile, active.leaseToken, { encoding: "utf8", mode: 0o600 });
      return await callback({ apiKeyFile, leaseTokenFile });
    } finally {
      try {
        await rm(directory, { recursive: true, force: true });
      } catch {
        throw new Error("kaneo-execution: failed to remove temporary Git credential files");
      }
    }
  }

  private persistRun(run: KaneoTaskRunRecord, projectId: string, worktreePath?: string | null): void {
    const persisted: PersistedExecutionState = {
      version: 2,
      taskId: run.taskId,
      projectId,
      runId: run.id,
      state: run.state,
      agentPrincipalId: run.agentPrincipalId,
      hostId: run.hostId,
      branchName: run.branchName,
      scope: [...run.scope],
      worktreePath:
        worktreePath !== undefined
          ? worktreePath
          : this.activeLease && this.activeLease.run.id === run.id
            ? this.activeLease.worktreePath
            : this.lastPersisted?.runId === run.id
              ? this.lastPersisted.worktreePath ?? null
              : null,
      updatedAt: new Date().toISOString(),
    };
    this.lastPersisted = persisted;
    this.pi.appendEntry(EXECUTION_STATE_ENTRY, persisted);
  }

  private startHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = setInterval(() => {
      const activeTaskId = this.activeLease?.run.taskId;
      if (!activeTaskId) return;
      void this.heartbeat(activeTaskId).catch((error) => {
        if (this.isLeaseFenceError(error)) {
          this.markLeaseLost(error);
          return;
        }
        if (!this.heartbeatFailureNotified) {
          this.heartbeatFailureNotified = true;
          this.ctx.ui.notify(`Kaneo worker heartbeat lỗi: ${errorMessage(error)}`, "error");
        }
      });
    }, HEARTBEAT_INTERVAL_MS);
    this.heartbeatTimer.unref?.();
  }

  private isLeaseFenceError(error: unknown): boolean {
    return error instanceof KaneoApiError && [401, 403, 404].includes(error.status);
  }

  /**
   * A 409 from execution endpoints is NOT always a lost lease. CAS drifts
   * (`stale_fence: run revision drifted`, stale expectedRunRevision) are
   * transient: the lease may still be valid, so the token must be kept and
   * the caller should refresh run state and retry. Only ownership-transfer
   * messages mean this worker genuinely lost the lease.
   */
  private isLeaseOwnershipError(error: unknown): boolean {
    if (!(error instanceof KaneoApiError) || error.status !== 409) return false;
    const msg = String((error as { message?: string }).message ?? "");
    return /lease changed|before lease recovery|run changed before lease|lease expired|lease taken/i.test(msg);
  }

  private markLeaseLost(error: unknown): void {
    const active = this.activeLease;
    if (!active) return;
    this.activeLease = null;
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
    this.persistRun(
      {
        ...active.run,
        state: "lease_lost",
        leaseActive: false,
        blocker: "Server lease fence rejected the worker heartbeat/report",
      },
      active.projectId,
    );
    this.ctx.ui.notify(`Kaneo worker lease bị fence: ${errorMessage(error)}`, "error");
  }

  private async tryRelease(
    run: KaneoTaskRunRecord,
    leaseToken: string,
    state: string,
    taskId: string,
  ): Promise<void> {
    try {
      await this.client.releaseTaskRun(
        taskId,
        run.id,
        run.leaseEpoch,
        leaseToken,
        state,
        requestKey("cleanup", taskId),
      );
    } catch {
      // The run remains server-visible and will reconcile through lease expiry.
    }
  }
}

// ---------------------------------------------------------------------------
// CLI — pure phase-protocol helpers for tests (no network, no secrets).
//   node --experimental-transform-types execution-runtime.ts phase-keys \
//     --run-id <runId> --phase-id <P1> [--checkpoint-id <id>] [--failure-kind <k>] \
//     [--commit-sha <sha>] [--resume --task-id <T> --source-run-id <R> \
//      --source-epoch <n|none> --source-checkpoint-id <id|none>]
//   node --experimental-transform-types execution-runtime.ts phase-args '<json>'
//   node --experimental-transform-types execution-runtime.ts phase-request-hash '<json>'
// ---------------------------------------------------------------------------

function isExecutionRuntimeMainModule(): boolean {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return realpathSync(entry) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

function readCliFlag(flags: Map<string, string>, name: string): string | null {
  return flags.get(name) ?? null;
}

async function executionRuntimeCliMain(): Promise<void> {
  const [command, ...rest] = process.argv.slice(2);
  const flags = new Map<string, string>();
  for (let i = 0; i < rest.length; i += 1) {
    const token = rest[i]!;
    if (!token.startsWith("--")) continue;
    const name = token.slice(2);
    const next = rest[i + 1];
    if (name === "resume") {
      flags.set(name, "true");
      continue;
    }
    if (next !== undefined && !next.startsWith("--")) {
      flags.set(name, next);
      i += 1;
    } else {
      flags.set(name, "");
    }
  }

  if (command === "phase-keys") {
    const runId = readCliFlag(flags, "run-id") ?? "run";
    const phaseId = readCliFlag(flags, "phase-id") ?? "P1";
    const output: Record<string, unknown> = {
      begin: phaseBeginKey(runId, phaseId),
      block: phaseBlockKey(runId, phaseId, readCliFlag(flags, "failure-kind") ?? "provider_quota"),
      checkpoint: phaseCheckpointKey(runId, phaseId, readCliFlag(flags, "commit-sha") ?? "0".repeat(40)),
      resume: resumeTaskRunKey(
        readCliFlag(flags, "task-id") ?? "task",
        readCliFlag(flags, "source-run-id") ?? "run",
        readCliFlag(flags, "source-epoch"),
        readCliFlag(flags, "source-checkpoint-id"),
      ),
    };
    const checkpointId = readCliFlag(flags, "checkpoint-id");
    if (checkpointId) output.complete = phaseCompleteKey(runId, phaseId, checkpointId);
    console.log(JSON.stringify(output));
    return;
  }

  if (command === "phase-args") {
    const args = JSON.parse(rest[0] ?? "{}") as Record<string, unknown>;
    console.log(JSON.stringify(validatePhaseProgressArgs(args)));
    return;
  }

  if (command === "phase-request-hash") {
    const parsed = JSON.parse(rest[0] ?? "{}") as { action?: string; body?: Record<string, unknown> };
    const action = parsed.action as PhaseProgressAction;
    const body = parsed.body ?? {};
    console.log(
      JSON.stringify({
        canonical: canonicalPhaseProgressRequest(action, body),
        hash: canonicalPhaseProgressRequestHash(action, body),
      }),
    );
    return;
  }

  console.error(
    "Usage: execution-runtime.ts phase-keys|phase-args|phase-request-hash ...",
  );
  process.exit(2);
}

if (isExecutionRuntimeMainModule()) {
  await executionRuntimeCliMain();
}
