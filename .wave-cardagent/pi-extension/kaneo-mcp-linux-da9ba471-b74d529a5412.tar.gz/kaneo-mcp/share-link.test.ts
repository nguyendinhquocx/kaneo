// Tests for the kaneo-mcp share-link reader (SPEC-2026-10-21).
// Run: node --experimental-strip-types --experimental-transform-types --test share-link.test.ts
import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

import {
  DEFAULT_KANEO_ENDPOINT,
  MAX_ASSET_LOOKUPS,
  MAX_FINAL_TEXT_BYTES,
  MAX_IMAGES,
  MAX_JSON_BYTES,
  SHARE_PREAMBLE,
  ShareAssetLedger,
  capFinalText,
  fetchShareAsset,
  fetchShareJson,
  maskShareUrlTokens,
  maskTokens,
  parseContentDispositionFilename,
  parseShareLinkUrl,
  readShareLink,
  renderActivityComment,
  renderDocument,
  renderGoal,
  renderProject,
  renderTaskDescription,
  rewriteContentAssetRefs,
  sanitizeFilename,
  tokenizeAssetRefs,
  type ParsedShareLink,
  type ShareFailure,
} from "./share-link.ts";

const ORIGIN = "https://kaneo.quoc.app";
const TOKEN = "aB3-_xYz1234567890aB3-_xYz1234567890aB3-_xY"; // 43 chars base64url
const TYPES = ["project", "document", "task", "task_description", "activity_comment", "goal"] as const;

function shareUrl(resourceType: string): string {
  return `${ORIGIN}/share/${resourceType}/${TOKEN}`;
}

function apiUrl(resourceType: string, suffix = ""): string {
  return `${ORIGIN}/api/share/${resourceType}/${TOKEN}${suffix}`;
}

function linkOf(resourceType: string): ParsedShareLink {
  const parsed = parseShareLinkUrl(shareUrl(resourceType), ORIGIN);
  assert.ok(parsed.ok, `fixture link for ${resourceType} should parse`);
  return parsed.ok ? parsed.link : (null as never);
}

interface RecordedCall {
  url: string;
  init: RequestInit | undefined;
}

function errorMessage(failure: ShareFailure): string {
  return failure.kind === "error" ? failure.message : failure.kind;
}

function makeFetch(
  handler: (url: string, init: RequestInit | undefined) => Response | Promise<Response>,
): { fetchImpl: typeof fetch; calls: RecordedCall[] } {
  const calls: RecordedCall[] = [];
  const impl = (async (input: string | URL | Request, init?: RequestInit) => {
    const href =
      typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    calls.push({ url: href, init });
    return handler(href, init);
  }) as unknown as typeof fetch;
  return { fetchImpl: impl, calls };
}

interface StreamOptions {
  status: number;
  headers?: Record<string, string>;
  chunks?: Uint8Array[];
  onCancel?: () => void;
}

function streamResponse(options: StreamOptions): Response {
  const { status, headers = {}, chunks = [], onCancel } = options;
  // Pull-based: chunks stream lazily so a cap-triggered cancel happens while
  // the stream is still open (like a real network body), not after close.
  const queue = [...chunks];
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) {
      const chunk = queue.shift();
      if (chunk) controller.enqueue(chunk);
      else controller.close();
    },
    cancel() {
      onCancel?.();
    },
  });
  return new Response(stream, { status, headers });
}

function utf8(text: string): Uint8Array {
  return new TextEncoder().encode(text);
}

// ---------------------------------------------------------------------------
// Parser
// ---------------------------------------------------------------------------

test("parser accepts all six share resource types", () => {
  for (const resourceType of TYPES) {
    const parsed = parseShareLinkUrl(shareUrl(resourceType), ORIGIN);
    assert.ok(parsed.ok, resourceType);
    if (parsed.ok) {
      assert.equal(parsed.link.resourceType, resourceType);
      assert.equal(parsed.link.token, TOKEN);
      assert.equal(parsed.link.origin, ORIGIN);
    }
  }
});

test("parser rejects malformed URLs before any network call", () => {
  const cases: Array<[string, string]> = [
    [`http://${ORIGIN.slice("https://".length)}/share/document/${TOKEN}`, "protocol"],
    [`https://example.com/share/document/${TOKEN}`, "foreign host"],
    [`https://kaneo.quoc.app:8443/share/document/${TOKEN}`, "port"],
    [`https://user:pass@kaneo.quoc.app/share/document/${TOKEN}`, "credentials"],
    [`${shareUrl("document")}?utm=x`, "query"],
    [`${shareUrl("document")}#frag`, "fragment"],
    [`${shareUrl("document")}/extra`, "extra path segment"],
    [`${shareUrl("document")}/`, "trailing slash"],
    [`https://kaneo.quoc.app/share/document/${TOKEN.slice(0, 42)}`, "short token"],
    [`https://kaneo.quoc.app/share/document/${TOKEN}/${TOKEN}`, "long token"],
    [`https://kaneo.quoc.app/share/document/short`, "non-token path"],
    [`https://kaneo.quoc.app/share/dashboard/${TOKEN}`, "unknown type"],
    [`https://kaneo.quoc.app/share/document/a%2Fb${TOKEN.slice(4)}`, "encoded slash"],
    ["not a url", "garbage"],
    ["", "empty"],
  ];
  for (const [input, label] of cases) {
    const parsed = parseShareLinkUrl(input, ORIGIN);
    assert.ok(!parsed.ok, `should reject: ${label}`);
  }
});

test("parser rejects userinfo-only URLs and hostname trailing dot", () => {
  assert.ok(!parseShareLinkUrl(`https://kaneo.quoc.app./share/document/${TOKEN}`, ORIGIN).ok);
  const userPass = parseShareLinkUrl(`https://user:pass@${ORIGIN.slice("https://".length)}/share/document/${TOKEN}`, ORIGIN);
  assert.ok(!userPass.ok);
});

// ---------------------------------------------------------------------------
// Tokenizer / ref guard
// ---------------------------------------------------------------------------

test("tokenizer parses absolute URL spans before local refs", () => {
  const link = linkOf("document");
  const canonical = apiUrl("document", "/asset/abc123");
  const content = `see ${canonical} and ![x](/asset/local1) plus https://example.com/asset/foreign`;
  const tokens = tokenizeAssetRefs(content, link);
  const assets = tokens.filter((t) => t.kind === "asset");
  assert.equal(assets.length, 2);
  assert.deepEqual(
    assets.map((t) => (t.kind === "asset" ? [t.assetId, t.source] : null)),
    [
      ["abc123", "canonical"],
      ["local1", "local"],
    ],
  );
});

test("tokenizer never extracts asset refs from foreign absolute URLs", () => {
  const link = linkOf("document");
  const contents = [
    `https://example.com/asset/abc`,
    `https://example.com/api/asset/abc`,
    `https://example.com/page?next=/asset/abc`,
    `https://example.com/page?q=https://kaneo.quoc.app/api/share/document/${TOKEN}/asset/abc`,
    `https://kaneo.quoc.app./asset/abc`,
    `https://evil.example.com/share/document/${TOKEN}/asset/abc`,
    `${ORIGIN.replace("document", "document")}/api/share/goal/${TOKEN}/asset/abc`.replace(
      "/api/share/goal/",
      "/api/share/goal/",
    ),
    apiUrl("task_description", "/asset/abc"), // right type+origin, wrong token link context
  ];
  for (const content of contents) {
    const tokens = tokenizeAssetRefs(content, link);
    const assets = tokens.filter((t) => t.kind === "asset");
    assert.equal(assets.length, 0, `should not fetch from: ${content}`);
  }
});

test("tokenizer matches canonical asset URL only for exact origin+type+token", () => {
  const link = linkOf("document");
  const good = tokenizeAssetRefs(apiUrl("document", "/asset/ok1"), link);
  assert.equal(good.filter((t) => t.kind === "asset").length, 1);
  const otherToken = apiUrl("document", "/asset/ok1").replace(TOKEN, "b".repeat(43));
  assert.equal(tokenizeAssetRefs(otherToken, link).filter((t) => t.kind === "asset").length, 0);
  const otherType = apiUrl("goal", "/asset/ok1");
  assert.equal(tokenizeAssetRefs(otherType, link).filter((t) => t.kind === "asset").length, 0);
});

test("tokenizer ignores non-path asset mentions", () => {
  const link = linkOf("document");
  const tokens = tokenizeAssetRefs("uploads/asset/y and asset/z but /uploads/asset/w", link);
  assert.equal(tokens.filter((t) => t.kind === "asset").length, 0);
});

test("rewrite honors allowFetch=false (project-scope descriptions)", () => {
  const ledger = new ShareAssetLedger();
  const out = rewriteContentAssetRefs("img /asset/abc123 here", linkOf("document"), ledger, {
    allowFetch: false,
  });
  assert.equal(out, "img [Asset unavailable in this share scope] here");
  assert.equal(ledger.ids.length, 0);
});

test("ledger dedupes and caps lookups", () => {
  const ledger = new ShareAssetLedger();
  for (let i = 0; i < MAX_ASSET_LOOKUPS + 3; i += 1) {
    ledger.register(`asset-${i}`);
  }
  assert.equal(ledger.ids.length, MAX_ASSET_LOOKUPS);
  assert.equal(ledger.register("asset-0"), 1); // dedupe still works
  assert.equal(ledger.register("overflow"), null);
});

// ---------------------------------------------------------------------------
// Renderers (golden)
// ---------------------------------------------------------------------------

test("renderDocument: title + verbatim content with asset markers", () => {
  const ledger = new ShareAssetLedger();
  const out = renderDocument(
    {
      id: "doc-1",
      title: "Spec notes",
      content: "Intro\n\n- item one\n\n![shot](/asset/img1)\n",
      revision: 3,
      updatedAt: "2026-10-21T00:00:00.000Z",
      scope: "view",
    },
    linkOf("document"),
    ledger,
  );
  assert.equal(out, `# Spec notes\n\nIntro\n\n- item one\n\n${ledger.markerFor(1)}\n`);
  assert.deepEqual(ledger.ids, ["img1"]);
});

test("renderTaskDescription: empty content keeps heading only", () => {
  const ledger = ShareAssetLedger;
  const out = renderTaskDescription(
    { title: "Only title", content: null, scope: "view" },
    linkOf("task_description"),
    new ledger(),
  );
  assert.equal(out, "# Only title\n\n");
});

test("renderActivityComment: metadata line then content", () => {
  const ledger = new ShareAssetLedger();
  const out = renderActivityComment(
    {
      content: "Looks good [/api/asset/file9](/api/asset/file9)",
      createdAt: "2026-10-21T01:02:03.000Z",
      scope: "view",
    },
    linkOf("activity_comment"),
    ledger,
  );
  assert.equal(
    out,
    `> Created at: 2026-10-21T01:02:03.000Z\n\nLooks good ${ledger.markerFor(1)}`,
  );
  assert.deepEqual(ledger.ids, ["file9"]);
});

function projectPayload() {
  return {
    id: "proj-123",
    name: "Launch plan",
    slug: "launch-plan",
    icon: null,
    description: "Summary with /asset/proj-diagram embedded",
    isPublic: false,
    columns: [
      {
        id: "todo",
        slug: "todo",
        name: "To do",
        icon: null,
        isFinal: false,
        tasks: [
          {
            id: "t-1",
            projectId: "proj-123",
            number: 7,
            title: "First task",
            description: "See ![a](/asset/task-img-a)",
            status: "todo",
            priority: "high",
            startDate: "2026-10-01T00:00:00.000Z",
            dueDate: "2026-10-30T00:00:00.000Z",
            position: 1,
            createdAt: "2026-09-30T00:00:00.000Z",
            labels: [
              { id: "l-2", name: "Beta", color: null },
              { id: "l-1", name: "Alpha", color: null },
              { id: "l-0", name: "Alpha", color: null },
            ],
          },
          {
            id: "t-2",
            projectId: "proj-123",
            number: null,
            title: "No number, no description",
            description: null,
            status: "todo",
            priority: null,
            startDate: null,
            dueDate: null,
            position: 2,
            createdAt: "2026-09-30T00:00:00.000Z",
            labels: [],
          },
          {
            id: "t-arch",
            projectId: "proj-123",
            number: 9,
            title: "Should stay out of columns",
            description: "hidden",
            status: "archived",
            priority: null,
            startDate: null,
            dueDate: null,
            position: 3,
            createdAt: "2026-09-30T00:00:00.000Z",
            labels: [],
          },
        ],
      },
      {
        id: "done",
        slug: "done",
        name: "Done",
        icon: null,
        isFinal: true,
        tasks: [],
      },
    ],
    archivedTasks: [
      {
        id: "t-arch",
        projectId: "proj-123",
        number: 9,
        title: "Archived once only",
        description: null,
        status: "archived",
        priority: null,
        startDate: null,
        dueDate: null,
        position: 3,
        createdAt: "2026-09-30T00:00:00.000Z",
        labels: [],
      },
    ],
    plannedTasks: [
      {
        id: "t-1",
        projectId: "proj-123",
        number: 7,
        title: "Duplicate of column task",
        description: null,
        status: "planned",
        priority: null,
        startDate: null,
        dueDate: null,
        position: 0,
        createdAt: "2026-09-30T00:00:00.000Z",
        labels: [],
      },
      {
        id: "t-plan",
        projectId: "proj-123",
        number: 11,
        title: "Planned task",
        description: null,
        status: "planned",
        priority: null,
        startDate: null,
        dueDate: null,
        position: 4,
        createdAt: "2026-09-30T00:00:00.000Z",
        labels: [],
      },
    ],
  };
}

test("renderProject golden: sections, dedupe, redaction, stable labels", () => {
  const ledger = new ShareAssetLedger();
  const out = renderProject(projectPayload(), linkOf("project"), ledger);

  assert.ok(out.startsWith("# Launch plan\n"));
  // Project-level description asset ref: scope note, no fetch.
  assert.ok(out.includes("[Asset unavailable in this share scope]"));
  assert.ok(!ledger.ids.includes("proj-diagram"));

  // Columns render in payload order; archived/planned kept out of columns.
  assert.ok(out.includes("## To do"));
  assert.ok(out.includes("## Done"));
  const todoSection = out.slice(out.indexOf("## To do"), out.indexOf("## Archived tasks"));
  assert.ok(!todoSection.includes("### #9 "));

  // Numbered + unnumbered headings.
  assert.ok(out.includes("### #7 First task"));
  assert.ok(out.includes("### No number, no description"));

  // Metadata lines in fixed order, labels sorted by name then internal id.
  assert.ok(out.includes("- Status: todo"));
  assert.ok(out.includes("- Priority: high"));
  assert.ok(out.includes("- Start: 2026-10-01"));
  assert.ok(out.includes("- Due: 2026-10-30"));
  assert.ok(out.includes("- Labels: Alpha, Alpha, Beta"));

  // Null description -> generic placeholder, no agent-control reasoning.
  assert.ok(out.includes("Description unavailable."));

  // Special sections exist; duplicate ids appear exactly once.
  assert.ok(out.includes("## Archived tasks"));
  assert.ok(out.includes("## Planned tasks"));
  assert.equal(out.split("Archived once only").length - 1, 1);
  assert.equal(out.split("### #7 First task").length - 1, 1);

  // No internal ids, project/scope/workspace/assignee leakage.
  assert.ok(!out.includes("proj-123"));
  assert.ok(!out.includes("t-1"));
  assert.ok(!out.includes("l-1"));
  assert.ok(!out.includes("view")); // scope value never rendered
  assert.ok(!out.includes("assignee"));
  assert.ok(!out.includes("workspaceId"));

  // Task-embedded asset ref was registered for fetch.
  assert.deepEqual(ledger.ids, ["task-img-a"]);
});

test("renderProject: labels sort stable regardless of payload order", () => {
  const base = projectPayload();
  const shuffled = structuredClone(base);
  const labels = shuffled.columns[0].tasks[0].labels;
  labels.reverse();
  const ledgerA = new ShareAssetLedger();
  const ledgerB = new ShareAssetLedger();
  const link = linkOf("project");
  const a = renderProject(base, link, ledgerA);
  const b = renderProject(shuffled, link, ledgerB);
  assert.equal(a, b);
});

test("renderGoal golden: metadata and check-ins with note refs", () => {
  const ledger = new ShareAssetLedger();
  const out = renderGoal(
    {
      id: "goal-1",
      name: "Ship weekly",
      timezone: "Asia/Ho_Chi_Minh",
      targetPerWeek: 5,
      archivedAt: null,
      scope: "view",
      checkins: [
        {
          id: "c1",
          checkInDate: "2026-10-20",
          completed: true,
          note: "done ![e](/asset/evi1)",
          noteRevision: 1,
        },
        { id: "c2", checkInDate: "2026-10-21", completed: false, note: null, noteRevision: 0 },
      ],
    },
    linkOf("goal"),
    ledger,
  );
  assert.ok(out.startsWith("# Goal: Ship weekly\nTimezone: Asia/Ho_Chi_Minh\nTarget per week: 5"));
  assert.ok(out.includes("## Check-ins"));
  assert.ok(out.includes("### 2026-10-20 — completed"));
  assert.ok(out.includes(ledger.markerFor(1)));
  assert.ok(out.includes("### 2026-10-21 — not completed"));
  assert.deepEqual(ledger.ids, ["evi1"]);
  assert.ok(!out.includes("goal-1"));
  assert.ok(!out.includes("scope"));
});

test("renderGoal: no check-ins placeholder", () => {
  const out = renderGoal(
    { name: "Empty", timezone: null, targetPerWeek: null, checkins: [] },
    linkOf("goal"),
    new ShareAssetLedger(),
  );
  assert.ok(out.includes("No check-ins."));
});

// ---------------------------------------------------------------------------
// Network guards
// ---------------------------------------------------------------------------

test("fetchShareJson: request shape is GET, manual redirect, no auth header", async () => {
  const { fetchImpl, calls } = makeFetch(() =>
    streamResponse({ status: 200, headers: { "content-type": "application/json" }, chunks: [utf8("{}")] }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(result.ok);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].init?.method, "GET");
  assert.equal(calls[0].init?.redirect, "manual");
  const headers = calls[0].init?.headers as Record<string, string>;
  assert.ok(headers && "accept" in headers);
  assert.ok(!("authorization" in headers));
  assert.ok(!Object.values(headers).some((v) => v.toLowerCase().includes("bearer")));
});

test("fetchShareJson: redirects are rejected and body cancelled, never followed", async () => {
  let cancelled = false;
  const { fetchImpl } = makeFetch(() =>
    streamResponse({
      status: 302,
      headers: { location: "https://evil.example.com/steal" },
      chunks: [utf8("redirect body")],
      onCancel: () => {
        cancelled = true;
      },
    }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  if (!result.ok) {
    assert.equal(result.failure.kind, "error");
    assert.match((result.failure as Extract<ShareFailure, { kind: "error" }>).message, /redirect/i);
    assert.ok(!result.failure.message.includes("evil.example.com"));
  }
  assert.ok(cancelled);
});

test("fetchShareJson: 404 maps to generic not_found", async () => {
  let cancelled = false;
  const { fetchImpl } = makeFetch(() =>
    streamResponse({ status: 404, chunks: [utf8("Not found")], onCancel: () => (cancelled = true) }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.equal(!result.ok && result.failure.kind, "not_found");
  assert.ok(cancelled);
});

test("fetchShareJson: 429 keeps Retry-After and does not auto-retry", async () => {
  let hits = 0;
  const { fetchImpl } = makeFetch(() => {
    hits += 1;
    return streamResponse({ status: 429, headers: { "retry-after": "30" } });
  });
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.equal(!result.ok && result.failure.kind, "rate_limited");
  assert.equal(!result.ok && (result.failure as { retryAfterSeconds?: number }).retryAfterSeconds, 30);
  assert.equal(hits, 1);
});

test("fetchShareJson: 5xx errors stay compact (no body, no URL, no token)", async () => {
  const secret = "LEAKME-SECRET-BODY";
  const { fetchImpl } = makeFetch(() =>
    streamResponse({ status: 502, chunks: [utf8(secret)] }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  if (!result.ok) {
    assert.equal(result.failure.kind, "error");
    assert.ok(!result.failure.message.includes(secret));
    assert.ok(!result.failure.message.includes(TOKEN));
    assert.ok(!result.failure.message.includes("kaneo.quoc.app"));
  }
});

test("fetchShareJson: wrong content type cancels body without parsing", async () => {
  let cancelled = false;
  const { fetchImpl } = makeFetch(() =>
    streamResponse({
      status: 200,
      headers: { "content-type": "text/html; charset=utf-8" },
      chunks: [utf8("<h1>hi</h1>")],
      onCancel: () => (cancelled = true),
    }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.ok(cancelled);
});

test("fetchShareJson: content-length over cap rejects before reading", async () => {
  let cancelled = false;
  let pulls = 0;
  const { fetchImpl } = makeFetch(() => {
    const stream = new ReadableStream<Uint8Array>({
      pull(controller) {
        pulls += 1;
        controller.enqueue(utf8("{}"));
        controller.close();
      },
      cancel() {
        cancelled = true;
      },
    });
    return new Response(stream, {
      status: 200,
      headers: { "content-type": "application/json", "content-length": String(MAX_JSON_BYTES + 1) },
    });
  });
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.match(errorMessage(!result.ok ? result.failure : { kind: "error", message: "" }), /limit/i);
  assert.ok(cancelled);
  // Node's Response impl may pull one chunk on its own, but it must never
  // drain the body for a content-length that is already over the cap.
  assert.ok(pulls <= 1, `body was drained: ${pulls} pulls`);
});

test("fetchShareJson: streamed body over cap is cancelled mid-stream", async () => {
  let cancelled = false;
  // Four chunks: the cap trips during chunk 3 while chunk 4 is still queued,
  // so the stream is provably cancelled before its natural close.
  const bigChunk = new Uint8Array(512 * 1024);
  const { fetchImpl } = makeFetch(() =>
    streamResponse({
      status: 200,
      headers: { "content-type": "application/json" },
      chunks: [bigChunk, bigChunk, bigChunk, bigChunk],
      onCancel: () => (cancelled = true),
    }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.match(errorMessage(!result.ok ? result.failure : { kind: "error", message: "" }), /limit/i);
  assert.ok(cancelled);
});

test("fetchShareJson: invalid JSON becomes a generic error", async () => {
  const { fetchImpl } = makeFetch(() =>
    streamResponse({ status: 200, headers: { "content-type": "application/json" }, chunks: [utf8("{nope")] }),
  );
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.match(errorMessage(!result.ok ? result.failure : { kind: "error", message: "" }), /valid JSON/i);
});

test("fetchShareJson: transport failure becomes compact timeout/failed error", async () => {
  const { fetchImpl } = makeFetch(() => {
    throw new Error("TimeoutError: The operation was aborted due to timeout");
  });
  const result = await fetchShareJson(fetchImpl, apiUrl("document"));
  assert.ok(!result.ok);
  assert.match(errorMessage(!result.ok ? result.failure : { kind: "error", message: "" }), /timed out|failed/i);
});

test("fetchShareAsset: valid PNG becomes base64 image with normalized mime", async () => {
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47]);
  const { fetchImpl, calls } = makeFetch(() =>
    streamResponse({
      status: 200,
      headers: { "content-type": "image/png", "content-disposition": 'inline; filename="shot.png"' },
      chunks: [png],
    }),
  );
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a1"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 3,
  });
  assert.equal(result.kind, "image");
  if (result.kind === "image") {
    assert.equal(result.mimeType, "image/png");
    assert.equal(result.filename, "shot.png");
    assert.equal(Buffer.from(result.data, "base64").byteLength, png.byteLength);
    assert.equal(result.bytes, png.byteLength);
  }
  assert.equal(calls[0].init?.redirect, "manual");
});

test("fetchShareAsset: image/jpg normalized to image/jpeg", async () => {
  const { fetchImpl } = makeFetch(() =>
    streamResponse({ status: 200, headers: { "content-type": "image/jpg" }, chunks: [utf8("x")] }),
  );
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a2"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 3,
  });
  assert.equal(result.kind, "image");
  assert.equal(result.kind === "image" ? result.mimeType : "", "image/jpeg");
});

test("fetchShareAsset: oversized image cancelled with cap note", async () => {
  let cancelled = false;
  const half = new Uint8Array(1024 * 1024 + 1);
  const { fetchImpl } = makeFetch(() =>
    streamResponse({
      status: 200,
      headers: { "content-type": "image/png" },
      chunks: [half, half, half],
      onCancel: () => (cancelled = true),
    }),
  );
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a3"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 3,
  });
  assert.equal(result.kind, "error");
  assert.match(result.kind === "error" ? result.note : "", /2 MiB/);
  assert.ok(cancelled);
});

test("fetchShareAsset: total budget exhaustion produces budget note", async () => {
  const { fetchImpl } = makeFetch(() =>
    streamResponse({ status: 200, headers: { "content-type": "image/jpeg" }, chunks: [utf8("x")] }),
  );
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a4"), {
    remainingImageBudget: 1024,
    imageSlotsRemaining: 2,
  });
  assert.equal(result.kind, "error");
  assert.match(result.kind === "error" ? result.note : "", /budget/i);
});

test("fetchShareAsset: image slots exhausted produces image-limit note without download", async () => {
  let cancelled = false;
  const { fetchImpl } = makeFetch(() =>
    streamResponse({
      status: 200,
      headers: { "content-type": "image/png" },
      chunks: [utf8("x")],
      onCancel: () => (cancelled = true),
    }),
  );
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a5"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 0,
  });
  assert.equal(result.kind, "error");
  assert.match(result.kind === "error" ? result.note : "", /limit reached/i);
  assert.ok(cancelled);
});

test("fetchShareAsset: unsupported image mime is skipped with MIME note", async () => {
  let cancelled = false;
  const { fetchImpl } = makeFetch(() =>
    streamResponse({
      status: 200,
      headers: { "content-type": "image/tiff" },
      chunks: [utf8("II* ")],
      onCancel: () => (cancelled = true),
    }),
  );
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a6"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 2,
  });
  assert.equal(result.kind, "error");
  assert.match(result.kind === "error" ? result.note : "", /image\/tiff/);
  assert.ok(cancelled);
});

test("fetchShareAsset: non-image file reads headers only and cancels body", async () => {
  let cancelled = false;
  let enqueued = false;
  const { fetchImpl } = makeFetch(() => {
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        enqueued = true;
        controller.enqueue(utf8("%PDF-1.7 should never be read"));
        controller.close();
      },
      cancel() {
        cancelled = true;
      },
    });
    return new Response(stream, {
      status: 200,
      headers: {
        "content-type": "application/pdf",
        "content-disposition": 'attachment; filename="report (final).pdf"',
      },
    });
  });
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a7"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 2,
  });
  assert.equal(result.kind, "file");
  assert.equal(result.kind === "file" ? result.filename : "", "report (final).pdf");
  assert.ok(cancelled);
  assert.ok(enqueued); // body existed; we just never read it
});

test("fetchShareAsset: per-asset failure notes never contain the URL or token", async () => {
  const { fetchImpl } = makeFetch(() => streamResponse({ status: 500, chunks: [utf8("boom")] }));
  const result = await fetchShareAsset(fetchImpl, apiUrl("document", "/asset/a8"), {
    remainingImageBudget: 8 * 1024 * 1024,
    imageSlotsRemaining: 2,
  });
  assert.equal(result.kind, "error");
  if (result.kind === "error") {
    assert.ok(!result.note.includes(TOKEN));
    assert.ok(!result.note.includes("kaneo.quoc.app"));
    assert.ok(!result.note.includes("boom"));
  }
});

// ---------------------------------------------------------------------------
// Filename handling
// ---------------------------------------------------------------------------

test("sanitizeFilename strips paths, control chars, and caps length", () => {
  assert.equal(sanitizeFilename("..%2F..%2Fetc%2Fpasswd"), "etc passwd");
  assert.equal(sanitizeFilename('c:\\evil\\path"?.png'), "c evil path .png");
  assert.equal(sanitizeFilename("a".repeat(200)).length, 120);
  assert.equal(sanitizeFilename("   "), "attachment");
  assert.equal(sanitizeFilename(""), "attachment");
});

test("parseContentDispositionFilename handles plain and extended forms", () => {
  assert.equal(parseContentDispositionFilename('attachment; filename="a b.png"'), "a b.png");
  assert.equal(parseContentDispositionFilename("filename*=UTF-8''t%C3%A9%20st.png"), "té st.png");
  assert.equal(parseContentDispositionFilename(null), null);
  assert.equal(parseContentDispositionFilename("inline"), null);
});

// ---------------------------------------------------------------------------
// Text cap
// ---------------------------------------------------------------------------

test("capFinalText passes through short text", () => {
  const result = capFinalText(SHARE_PREAMBLE + "\n\nshort");
  assert.equal(result.truncated, false);
});

test("capFinalText cuts at newline boundary, byte-safe, with note, within limit", () => {
  const filler = "giới hạn".repeat(4000); // multibyte Vietnamese
  const long = `${SHARE_PREAMBLE}\n\n${filler}\nTAIL-MARKER-X`;
  const result = capFinalText(long);
  assert.equal(result.truncated, true);
  const bytes = Buffer.byteLength(result.text, "utf8");
  assert.ok(bytes <= MAX_FINAL_TEXT_BYTES, `bytes ${bytes} must be <= ${MAX_FINAL_TEXT_BYTES}`);
  assert.ok(result.text.endsWith("[Output truncated: share content exceeds 32 KiB.]"));
  assert.ok(!result.text.includes("TAIL-MARKER-X"));
  assert.ok(!result.text.includes("\uFFFD"), "must not contain replacement chars");
});

// ---------------------------------------------------------------------------
// Orchestration
// ---------------------------------------------------------------------------

function jsonRoute(body: unknown, extraHeaders: Record<string, string> = {}): Response {
  return streamResponse({
    status: 200,
    headers: { "content-type": "application/json", ...extraHeaders },
    chunks: [utf8(JSON.stringify(body))],
  });
}

function pngRoute(bytes = 16): Response {
  return streamResponse({
    status: 200,
    headers: { "content-type": "image/png", "content-disposition": 'inline; filename="img.png"' },
    chunks: [new Uint8Array(bytes)],
  });
}

test("readShareLink: document text + image blocks, preamble, no token echo", async () => {
  const { fetchImpl, calls } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "Doc", content: "body ![i](/asset/x1)" });
    if (url === apiUrl("document", "/asset/x1")) return pngRoute();
    throw new Error(`unexpected url ${url}`);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.equal(result.resourceType, "document");
  assert.ok(result.text.startsWith(SHARE_PREAMBLE));
  assert.ok(result.text.includes("# Doc"));
  assert.ok(result.text.includes("[Image 1: img.png]"));
  assert.equal(result.images.length, 1);
  assert.equal(result.imagesIncluded, 1);
  assert.equal(result.images[0].mimeType, "image/png");
  assert.equal(result.lookups, 1);
  assert.ok(!result.text.includes(TOKEN));
  assert.ok(!calls.some((c) => c.init?.headers && JSON.stringify(c.init.headers).toLowerCase().includes("authorization")));
});

test("readShareLink: task card capability renders a bounded untrusted card snapshot", async () => {
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("task")) {
      return jsonRoute({
        permission: "view",
        rootTaskId: "task_root",
        root: {
          id: "task_root",
          number: 42,
          title: "Card title",
          description: "Card details ![chart](/asset/task-image)",
          status: "in-progress",
          statusLabel: "In progress",
          contentRevision: 3,
        },
        subtasks: [{ id: "child", title: "Child", status: "to-do" }],
        commentsPage: {
          items: [{ authorName: "Guest", content: "comment text" }],
          nextCursor: null,
        },
      });
    }
    if (url === apiUrl("task", "/asset/task-image")) return pngRoute();
    throw new Error(`unexpected url ${url}`);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("task") });
  assert.equal(result.resourceType, "task");
  assert.ok(result.text.includes("#42 Card title"));
  assert.ok(result.text.includes("Content revision: 3"));
  assert.ok(result.text.includes("### Subtasks"));
  assert.ok(result.text.includes("comment text"));
  assert.ok(result.text.includes("untrusted reference data"));
  assert.ok(!result.text.includes(TOKEN));
  assert.equal(result.images.length, 1);
});

test("readShareLink: unsupported share URL throws before any network call", async () => {
  let hits = 0;
  const { fetchImpl } = makeFetch(() => {
    hits += 1;
    return jsonRoute({});
  });
  await assert.rejects(
    readShareLink({ fetchImpl, endpoint: ORIGIN, url: "https://evil.example.com/share/document/x" }),
    /Unsupported Kaneo share URL/,
  );
  await assert.rejects(
    readShareLink({ fetchImpl, endpoint: ORIGIN, url: `${shareUrl("document")}?x=1` }),
    /Unsupported Kaneo share URL/,
  );
  assert.equal(hits, 0);
});

test("readShareLink: top-level 404 produces one generic message", async () => {
  const { fetchImpl } = makeFetch(() => streamResponse({ status: 404 }));
  await assert.rejects(
    readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("goal") }),
    (error: Error) => {
      assert.match(error.message, /invalid, expired, revoked/);
      assert.ok(!error.message.includes(TOKEN));
      return true;
    },
  );
});

test("readShareLink: rate limit surfaces retry-after without retrying", async () => {
  let hits = 0;
  const { fetchImpl } = makeFetch(() => {
    hits += 1;
    return streamResponse({ status: 429, headers: { "retry-after": "12" } });
  });
  await assert.rejects(
    readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") }),
    /retry after 12s/,
  );
  assert.equal(hits, 1);
});

test("readShareLink: per-asset failure keeps text and other images", async () => {
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) {
      return jsonRoute({ title: "D", content: "![a](/asset/ok) then ![b](/asset/bad)" });
    }
    if (url === apiUrl("document", "/asset/ok")) return pngRoute();
    return streamResponse({ status: 500 });
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.ok(result.text.includes("[Image 1: img.png]"));
  assert.ok(result.text.includes("(not loaded:"));
  assert.equal(result.images.length, 1);
  assert.equal(result.imagesIncluded, 1);
});

test("readShareLink: non-image asset becomes attachment note, no image block", async () => {
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("task_description")) {
      return jsonRoute({ title: "T", content: "file /asset/doc1" });
    }
    return streamResponse({
      status: 200,
      headers: {
        "content-type": "application/zip",
        "content-disposition": 'attachment; filename="bundle.zip"',
      },
    });
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("task_description") });
  assert.ok(result.text.includes("[Attachment: bundle.zip]"));
  assert.ok(!result.text.includes("[Image 1:"));
  assert.equal(result.images.length, 0);
});

test("readShareLink: image count capped at 8, lookups capped at 12", async () => {
  const refs = Array.from({ length: 12 }, (_, i) => `![i${i}](/asset/img${i})`).join(" ");
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "D", content: refs });
    return pngRoute();
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.equal(result.lookups, 12);
  assert.equal(result.images.length, MAX_IMAGES);
  assert.equal(result.imagesIncluded, MAX_IMAGES);
  assert.ok(result.text.includes("image limit reached"));
});

test("readShareLink: truncated output drops image blocks whose markers were cut", async () => {
  const filler = "nội dung dài ".repeat(4000);
  const content = `${filler}\n\n![late](/asset/late-img)`;
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "Big", content });
    return pngRoute();
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.equal(result.truncated, true);
  assert.ok(Buffer.byteLength(result.text, "utf8") <= MAX_FINAL_TEXT_BYTES);
  assert.ok(!result.text.includes("[Image 1:"));
  assert.equal(result.images.length, 0);
  assert.equal(result.imagesIncluded, 0);
});

test("readShareLink: fake image placeholder cannot keep a truncated image block", async () => {
  const content = `[Image 1: fake]\n${"x".repeat(34_000)}\n![late](/asset/late)`;
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "Spoof", content });
    if (url === apiUrl("document", "/asset/late")) return pngRoute();
    throw new Error(`unexpected url ${url}`);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.equal(result.truncated, true);
  assert.ok(result.text.includes("[Image 1: fake]"), "literal attacker marker remains in truncated text");
  assert.ok(!result.text.includes("[Image 1: img.png]"), "real image marker is beyond the cap");
  assert.equal(result.images.length, 0, "a fake visible marker must not retain the real image block");
  assert.equal(result.imagesIncluded, 0);
});

test("readShareLink: project description refs stay unfetched, nested task refs fetch", async () => {
  const payload = projectPayload();
  const { fetchImpl, calls } = makeFetch((url) => {
    if (url === apiUrl("project")) return jsonRoute(payload);
    if (url === apiUrl("project", "/asset/task-img-a")) return pngRoute();
    throw new Error(`unexpected ${url}`);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("project") });
  assert.ok(result.text.includes("[Asset unavailable in this share scope]"));
  assert.equal(result.images.length, 1);
  assert.ok(!calls.some((c) => c.url.includes("proj-diagram")));
});

test("maskTokens redacts 43-char tokens but keeps normal text", () => {
  const masked = maskTokens(`failed for ${TOKEN} and normal words`);
  assert.ok(!masked.includes(TOKEN));
  assert.ok(masked.includes("[redacted]"));
  assert.ok(masked.includes("normal words"));
});

test("readShareLink: non-image asset before an image must not drop the image block", async () => {
  // Regression for the finalImages index misalignment: a text-note asset at
  // marker 1 used to shift the keep-image filter and silently drop marker 2.
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) {
      return jsonRoute({ title: "Mix", content: "file /asset/pdf1 then ![pic](/asset/pic1)" });
    }
    if (url === apiUrl("document", "/asset/pic1")) return pngRoute();
    return streamResponse({
      status: 200,
      headers: { "content-type": "application/pdf", "content-disposition": "attachment; filename=\"a.pdf\"" },
    });
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.ok(result.text.includes("[Attachment: a.pdf]"));
  assert.ok(result.text.includes("[Image 2: img.png]"));
  assert.equal(result.images.length, 1);
  assert.equal(result.imagesIncluded, 1);
  if (result.images.length === 1) assert.equal(result.images[0].mimeType, "image/png");
});

test("readShareLink: failed asset before an image keeps the image block", async () => {
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) {
      return jsonRoute({ title: "Mix", content: "![dead](/asset/dead) then ![live](/asset/live)" });
    }
    if (url === apiUrl("document", "/asset/live")) return pngRoute();
    return streamResponse({ status: 500 });
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.ok(result.text.includes("[Image 1: asset] (not loaded:"));
  assert.ok(result.text.includes("[Image 2: img.png]"));
  assert.equal(result.images.length, 1);
});

test("maskShareUrlTokens redacts raw and encoded 43-unit prefixes with suffixes", () => {
  const rawPrefix = "A".repeat(43);
  const encodedPrefix = "%41".repeat(43);
  assert.equal(
    maskShareUrlTokens(`/share/project/${rawPrefix}x`),
    "/share/project/[redacted]x",
  );
  assert.equal(
    maskShareUrlTokens(`/share/project/${encodedPrefix}%42`),
    "/share/project/[redacted]%42",
  );
});

test("readShareLink: raw and percent-encoded share tokens in content are masked", async () => {
  const otherToken = "zZ9_-".repeat(9).slice(0, 43); // exactly 43 base64url chars
  const encodedToken = "%42".repeat(43);
  const content =
    `see https://kaneo.quoc.app/share/project/${otherToken} and https://kaneo.quoc.app/share/goal/${encodedToken} plus trailing canonical ${apiUrl("document", "/asset/zz.")}`;
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "Leaks", content });
    if (url === apiUrl("document", "/asset/zz")) return pngRoute();
    throw new Error(`unexpected ${url}`);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.ok(!result.text.includes(otherToken), "foreign share token must be masked");
  assert.ok(!result.text.includes(encodedToken), "percent-encoded share token must be masked");
  assert.ok(!result.text.includes(TOKEN), "own share token must never appear as URL text");
  assert.ok(result.text.includes("/share/project/[redacted]"));
  assert.ok(result.text.includes("/share/goal/[redacted]"));
});

// ---------------------------------------------------------------------------
// Registration / prompt-injection regression (source contract)
// ---------------------------------------------------------------------------

test("reader is registered standalone and excluded from the toggle-managed group", async () => {
  const indexSource = await readFile(new URL("./index.ts", import.meta.url), "utf8");
  const toolsSource = await readFile(new URL("./tools.ts", import.meta.url), "utf8");

  // Registered as its own native tool.
  assert.ok(indexSource.includes('name: "kaneo_read_share_link"'));

  // Not part of KANEO_TOOL_NAMES (the set kaneo_toggle adds/removes).
  const namesStart = indexSource.indexOf("const KANEO_TOOL_NAMES");
  assert.ok(namesStart > 0);
  const namesBlock = indexSource.slice(
    indexSource.indexOf("const KANEO_TOOL_NAMES"),
    indexSource.indexOf("];", indexSource.indexOf("const KANEO_TOOL_NAMES")),
  );
  assert.ok(!namesBlock.includes("read_share_link"));
  assert.ok(!toolsSource.includes("read_share_link"));

  // Toggle guidance must not activate the group for share links.
  assert.match(indexSource, /Do NOT call kaneo_toggle just because the user pastes a Kaneo share link/);

  // Untrusted-content warning exists in the tool description and preamble.
  assert.match(indexSource, /untrusted reference data/);
  assert.match(SHARE_PREAMBLE, /Untrusted Kaneo share content/);
});

test("default endpoint is the reviewed production origin", () => {
  assert.equal(DEFAULT_KANEO_ENDPOINT, "https://kaneo.quoc.app");
});

// ---------------------------------------------------------------------------
// Attachment reading amendment (owner-approved scope extension)
// ---------------------------------------------------------------------------

function fileRoute(headers: Record<string, string>, chunks: Uint8Array[] = []): Response {
  return streamResponse({ status: 200, headers, chunks });
}

test("readShareLink: text-like attachment is inlined under its marker", async () => {
  const csv = "date,weight\n2026-10-21,72.5\n";
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("task_description")) {
      return jsonRoute({ title: "T", content: "log:\n\n/asset/data1" });
    }
    return fileRoute({
      "content-type": "text/csv",
      "content-disposition": 'attachment; filename="notes.csv"',
    }, [utf8(csv)]);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("task_description") });
  assert.ok(result.text.includes('[Attachment: notes.csv] (text, 28 bytes)'));
  assert.ok(result.text.includes("2026-10-21,72.5"));
  assert.equal(result.attachmentsInlined, 1);
  assert.equal(result.attachmentsSaved.length, 0);
  assert.ok(!result.text.includes(TOKEN));
});

test("readShareLink: oversized text attachment is truncated with a note", async () => {
  const big = "x".repeat(20_000);
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "D", content: "/asset/big1" });
    return fileRoute({ "content-type": "text/plain" }, [utf8(big)]);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.ok(result.text.includes("truncated at 16384 bytes"));
  assert.ok(result.attachmentsInlined === 1);
  assert.ok(Buffer.byteLength(result.text, "utf8") <= MAX_FINAL_TEXT_BYTES);
});

test("readShareLink: inline fence grows when attachment contains backtick runs", async () => {
  const sneaky = "intro\n```\nevil fence\n```\n";
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "D", content: "/asset/f1" });
    return fileRoute({ "content-type": "text/markdown" }, [utf8(sneaky)]);
  });
  const result = await readShareLink({ fetchImpl, endpoint: ORIGIN, url: shareUrl("document") });
  assert.ok(result.text.includes("````"), "outer fence must exceed the content's ``` run");
  const outside = result.text.split("````")[0] ?? "";
  assert.ok(!outside.includes("evil fence"), "content must stay inside the outer fence");
});

test("readShareLink: binary attachment is saved via saveFile and marker carries the path", async () => {
  const bytes = new Uint8Array([1, 2, 3, 4]);
  const saved: Array<{ filename: string; bytes: Uint8Array }> = [];
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "D", content: "see /asset/bin1" });
    return fileRoute({
      "content-type": "application/pdf",
      "content-disposition": 'attachment; filename="report.pdf"',
    }, [bytes]);
  });
  const result = await readShareLink({
    fetchImpl,
    endpoint: ORIGIN,
    url: shareUrl("document"),
    savePath: "/tmp/kaneo-uat",
    saveFile: (filename, data) => {
      saved.push({ filename, bytes: data });
      return `/tmp/kaneo-uat/${filename}`;
    },
  });
  assert.ok(result.text.includes("[Attachment: report.pdf -> /tmp/kaneo-uat/report.pdf]"));
  assert.equal(result.attachmentsSaved.length, 1);
  assert.equal(result.attachmentsSaved[0]?.filename, "report.pdf");
  assert.equal(result.attachmentsSaved[0]?.bytes, 4);
  assert.deepEqual(saved[0]?.bytes, bytes);
});

test("readShareLink: binary over the 20 MiB save cap is skipped with a note", async () => {
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) return jsonRoute({ title: "D", content: "/asset/huge1" });
    return fileRoute({
      "content-type": "application/zip",
      "content-length": String(21 * 1024 * 1024),
      "content-disposition": 'attachment; filename="huge.zip"',
    });
  });
  const result = await readShareLink({
    fetchImpl,
    endpoint: ORIGIN,
    url: shareUrl("document"),
    savePath: "/tmp/kaneo-uat",
    saveFile: () => "/tmp/kaneo-uat/huge.zip",
  });
  assert.ok(result.text.includes("file exceeds the 20 MiB save limit"));
  assert.ok(result.text.includes("(not loaded:"), "oversize note surfaces via the generic error branch");
  assert.equal(result.attachmentsSaved.length, 0);
});

test("readShareLink: mixed image/text/binary refs keep marker order and kinds", async () => {
  const { fetchImpl } = makeFetch((url) => {
    if (url === apiUrl("document")) {
      return jsonRoute({ title: "Mix", content: "![a](/asset/i1) then /asset/t2 then /asset/b3" });
    }
    if (url.endsWith("/asset/i1")) return pngRoute();
    if (url.endsWith("/asset/t2")) {
      return fileRoute({ "content-type": "text/plain" }, [utf8("hello")]);
    }
    return fileRoute({ "content-type": "application/zip" }, [new Uint8Array([9])]);
  });
  const result = await readShareLink({
    fetchImpl,
    endpoint: ORIGIN,
    url: shareUrl("document"),
    savePath: "/tmp/kaneo-uat",
    saveFile: (filename) => `/tmp/kaneo-uat/${filename}`,
  });
  const imageAt = result.text.indexOf("[Image 1: img.png]");
  const textAt = result.text.indexOf("[Attachment: attachment] (text, 5 bytes)");
  const binaryAt = result.text.indexOf("[Attachment: attachment -> /tmp/kaneo-uat/attachment]");
  assert.ok(imageAt >= 0 && textAt > imageAt && binaryAt > textAt, "markers stay in content order");
  assert.equal(result.images.length, 1);
  assert.equal(result.attachmentsInlined, 1);
  assert.equal(result.attachmentsSaved.length, 1);
});
