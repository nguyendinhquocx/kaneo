// Kaneo MCP bridge client for the kaneo-mcp Pi extension.
//
// Reads the API key + endpoint from a 0600 secret file under the Pi data dir
// (resolved via os.homedir(), never a hard-coded drive letter), then exposes a
// lazy single-session MCP JSON-RPC client. Each tool call goes through the
// reviewed Kaneo /api/mcp endpoint so auth, workspace membership and schema
// validation stay single-source-of-truth on the Kaneo side.
import { execFile, spawn } from "child_process";
import { promisify } from "node:util";
import { readFile, stat } from "node:fs/promises";
import { homedir, platform } from "node:os";
import { basename, join } from "node:path";

const execFileAsync = promisify(execFile);

function escapeCurlConfigValue(value: string): string {
  if (/[\r\n]/.test(value)) {
    throw new Error("kaneo-mcp: API key contains an invalid newline");
  }
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

// Keep the API key out of curl argv/env/logs. curl reads this one sensitive
// header from stdin as a config fragment; all other request arguments remain
// ordinary argv values. Output is bounded like execFile's maxBuffer.
function execCurlWithSecret(
  args: string[],
  apiKey: string,
  maxBuffer: number,
): Promise<{ stdout: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn("curl", [...args, "--config", "-"], {
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    let outputBytes = 0;
    let settled = false;

    const fail = (error: unknown) => {
      if (settled) return;
      settled = true;
      child.kill();
      reject(error instanceof Error ? error : new Error(String(error)));
    };

    const collect = (target: "stdout" | "stderr", chunk: string) => {
      outputBytes += Buffer.byteLength(chunk, "utf8");
      if (outputBytes > maxBuffer) {
        fail(new Error("kaneo-mcp: curl output exceeded the configured limit"));
        return;
      }
      if (target === "stdout") stdout += chunk;
      else stderr += chunk;
    };

    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => collect("stdout", chunk));
    child.stderr.on("data", (chunk: string) => collect("stderr", chunk));
    child.stdin.on("error", fail);
    child.on("error", fail);
    child.on("close", (code, signal) => {
      if (settled) return;
      if (code !== 0) {
        settled = true;
        const reason = code === null ? signal || "unknown" : String(code);
        reject(new Error(`kaneo-mcp: curl failed (${reason}): ${stderr.slice(0, 300)}`));
        return;
      }
      settled = true;
      resolve({ stdout });
    });

    try {
      child.stdin.end(`header = "Authorization: Bearer ${escapeCurlConfigValue(apiKey)}"\n`);
    } catch (error) {
      fail(error);
    }
  });
}

// Upload a local file as a Kaneo task asset via the presigned R2 flow.
// This bypasses MCP (Kaneo MCP does not expose uploads) and drives the REST
// flow directly: PUT presign -> PUT object -> POST finalize.
export interface UploadAssetResult {
  assetId: string;
  url: string;
  filename: string;
  size: number;
  contentType: string;
}

export async function uploadTaskAsset(
  filePath: string,
  taskId: string,
  surface: "comment" | "description",
  filenameOverride?: string,
  contentTypeOverride?: string,
): Promise<UploadAssetResult> {
  const secret = await readSecret();
  let info;
  try {
    info = await stat(filePath);
  } catch {
    throw new Error(`kaneo-mcp: upload file not found: ${filePath}`);
  }
  if (!info.isFile()) {
    throw new Error(`kaneo-mcp: upload path is not a regular file: ${filePath}`);
  }
  const size = info.size;
  const filename = filenameOverride || basename(filePath);
  const contentType = contentTypeOverride || "application/octet-stream";

  // 1. Presign: PUT /api/task/image-upload/:taskId
  const presignBody = JSON.stringify({ filename, contentType, size, surface });
  const presignRes = await execCurlWithSecret(
    [
      "-sS", "-X", "PUT",
      "-H", "Content-Type: application/json",
      "-H", "Accept: application/json",
      "--max-time", "30",
      `${secret.endpoint}/api/task/image-upload/${encodeURIComponent(taskId)}`,
      "-d", presignBody,
    ],
    secret.apiKey,
    1024 * 1024,
  );
  let presign: { uploadUrl?: string; key?: string; message?: string };
  try {
    presign = JSON.parse(presignRes.stdout);
  } catch {
    throw new Error(`kaneo-mcp: presign response unparseable: ${presignRes.stdout.slice(0, 300)}`);
  }
  if (!presign.uploadUrl || !presign.key) {
    throw new Error(`kaneo-mcp: presign failed: ${presign.message || presignRes.stdout.slice(0, 300)}`);
  }

  // 2. PUT object bytes to the presigned R2 URL.
  const putRes = await execFileAsync(
    "curl",
    [
      "-sS", "-X", "PUT",
      "-H", `Content-Type: ${contentType}`,
      "--max-time", "180",
      "--data-binary", `@${filePath}`,
      "-w", "\n__HTTP_STATUS__:%{http_code}",
      presign.uploadUrl,
    ],
    { maxBuffer: 100 * 1024 * 1024, windowsHide: true },
  );
  const putMatch = putRes.stdout.match(/__HTTP_STATUS__:(\d+)\s*$/);
  const putStatus = putMatch ? Number.parseInt(putMatch[1], 10) : 0;
  if (putStatus < 200 || putStatus >= 300) {
    throw new Error(`kaneo-mcp: R2 PUT failed (status ${putStatus}): ${putRes.stdout.slice(0, 300)}`);
  }

  // 3. Finalize: POST /api/task/image-upload/:taskId/finalize
  const finalizeBody = JSON.stringify({ key: presign.key, filename, contentType, size, surface });
  const finalizeRes = await execCurlWithSecret(
    [
      "-sS", "-X", "POST",
      "-H", "Content-Type: application/json",
      "-H", "Accept: application/json",
      "--max-time", "30",
      `${secret.endpoint}/api/task/image-upload/${encodeURIComponent(taskId)}/finalize`,
      "-d", finalizeBody,
    ],
    secret.apiKey,
    1024 * 1024,
  );
  let finalized: { id?: string; message?: string };
  try {
    finalized = JSON.parse(finalizeRes.stdout);
  } catch {
    throw new Error(`kaneo-mcp: finalize response unparseable: ${finalizeRes.stdout.slice(0, 300)}`);
  }
  if (!finalized.id) {
    throw new Error(`kaneo-mcp: finalize failed: ${finalized.message || finalizeRes.stdout.slice(0, 300)}`);
  }
  return {
    assetId: finalized.id,
    url: `${secret.endpoint}/api/asset/${finalized.id}`,
    filename,
    size,
    contentType,
  };
}

// Read/download a task asset by ID from the private /api/asset/:id endpoint.
// Text/JSON assets can be returned inline (text); binary assets should set
// savePath so curl writes the file directly (binary-safe). The API key stays
// out of argv/logs via the same secret-config stdin channel as uploads.
export interface GetAssetResult {
  assetId: string;
  url: string;
  contentType: string;
  size: number;
  text: string | null;
  savedTo: string | null;
}

export async function getTaskAsset(
  assetId: string,
  savePath?: string,
): Promise<GetAssetResult> {
  if (!/^[a-z0-9]{20,}$/i.test(assetId)) {
    throw new Error(`kaneo-mcp: invalid asset id: ${assetId}`);
  }
  const secret = await readSecret();
  const url = `${secret.endpoint}/api/asset/${encodeURIComponent(assetId)}`;
  const args = [
    "-sS", "-X", "GET",
    "-H", "Accept: application/octet-stream",
    "--max-time", "60",
  ];
  if (savePath) {
    // Binary-safe download: body goes to the file via -o, metadata comes back
    // via -w write-out (curl -i would dump headers+body together into the file).
    args.push("-o", savePath, "-w", "\n__META__:%{http_code}|%{content_type}|%{size_download}");
  } else {
    args.push("-i");
  }
  args.push(url);

  let stdout: string;
  try {
    const result = await execCurlWithSecret(args, secret.apiKey, 16 * 1024 * 1024);
    stdout = result.stdout;
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    throw new Error(`kaneo-mcp: asset download failed (${message})`);
  }

  if (savePath) {
    // Binary-safe path: body was written to savePath by curl -o; metadata
    // comes back via the __META__ write-out line (no header parsing needed).
    const metaMatch = stdout.match(/__META__:(\d+)\|([^|]*)\|(\d+)\s*$/);
    if (!metaMatch) {
      throw new Error(`kaneo-mcp: asset download missing write-out metadata: ${stdout.slice(0, 300)}`);
    }
    const status = Number.parseInt(metaMatch[1], 10);
    if (status === 401) {
      throw new Error(`kaneo-mcp: 401 unauthorized downloading asset — check KANEO_API_KEY in ${secretPath()}`);
    }
    if (status === 403) {
      throw new Error(`kaneo-mcp: 403 forbidden — API key lacks access to this asset`);
    }
    if (status !== 200) {
      throw new Error(`kaneo-mcp: HTTP ${status} downloading asset ${assetId}`);
    }
    return {
      assetId,
      url,
      contentType: metaMatch[2] || "application/octet-stream",
      size: Number.parseInt(metaMatch[3], 10) || 0,
      text: null,
      savedTo: savePath,
    };
  }

  const crlfIdx = stdout.indexOf("\r\n\r\n");
  const lfIdx = stdout.indexOf("\n\n");
  let headerBlock: string;
  if (crlfIdx >= 0 && (lfIdx < 0 || crlfIdx < lfIdx)) {
    headerBlock = stdout.slice(0, crlfIdx);
  } else if (lfIdx >= 0) {
    headerBlock = stdout.slice(0, lfIdx);
  } else {
    throw new Error(`kaneo-mcp: asset response has no header/body separator: ${stdout.slice(0, 300)}`);
  }

  const statusMatch = headerBlock.match(/^HTTP\/[\d.]+ (\d+)/m);
  const status = statusMatch ? Number.parseInt(statusMatch[1], 10) : 0;
  if (status === 401) {
    throw new Error(`kaneo-mcp: 401 unauthorized downloading asset — check KANEO_API_KEY in ${secretPath()}`);
  }
  if (status === 403) {
    throw new Error(`kaneo-mcp: 403 forbidden — API key lacks access to this asset`);
  }
  if (status !== 200) {
    throw new Error(`kaneo-mcp: HTTP ${status} downloading asset ${assetId}`);
  }

  let contentType: string;
  let size: number;
  contentType =
    (headerBlock.match(/^content-type:\s*(.+)$/im) || [])[1]?.trim() || "application/octet-stream";
  const sizeMatch = (headerBlock.match(/^content-length:\s*(\d+)$/im) || [])[1];
  size = sizeMatch ? Number.parseInt(sizeMatch, 10) : 0;
  // Inline mode: body follows the header separator (only safe for text-ish).
  const body = crlfIdx >= 0 && (lfIdx < 0 || crlfIdx < lfIdx)
    ? stdout.slice(crlfIdx + 4)
    : stdout.slice(lfIdx + 2);
  const text = Buffer.from(body, "utf8").toString("utf8");
  return { assetId, url, contentType, size, text, savedTo: null };
}
const MCP_PROTOCOL_VERSION = "2025-03-26";
const CLIENT_NAME = "pi-kaneo-mcp";
const CLIENT_VERSION = "1.0.0";
const DEFAULT_ENDPOINT = "https://kaneo.quoc.app";

export interface SecretConfig {
  apiKey: string;
  endpoint: string;
  agentPrincipalId?: string;
  hostId?: string;
  gitAllowlistPath?: string;
  gitGuardPath?: string;
  prGuardPath?: string;
}

export interface McpToolResult {
  jsonrpc: string;
  id?: number | string;
  result?: {
    content?: Array<{ type: string; text?: string }>;
    isError?: boolean;
    [key: string]: unknown;
  };
  error?: { code: number; message: string; data?: unknown };
}

interface CachedSession {
  endpoint: string;
  apiKey: string;
  sessionId: string;
}

let cachedSecret: SecretConfig | null = null;
let cachedSession: CachedSession | null = null;
let nextRequestId = 1;

function secretPath(): string {
  return process.env.KANEO_SECRET_PATH || join(homedir(), ".pi", "agent", "secrets", "kaneo.env");
}

export async function readSecret(): Promise<SecretConfig> {
  if (cachedSecret) return cachedSecret;
  const path = secretPath();
  let info;
  try {
    info = await stat(path);
  } catch {
    throw new Error(
      `kaneo-mcp: secret file missing at ${path}. Create it (mode 0600) with KANEO_API_KEY=... and optional KANEO_ENDPOINT=...`,
    );
  }
  // Reject world/group readable secret files on POSIX. Windows has no real
  // unix mode (Node always reports 0666); ACL/icacls is the enforcement there.
  if (platform() !== "win32") {
    const mode = info.mode & 0o777;
    if (mode !== 0o600) {
      throw new Error(
        `kaneo-mcp: secret file ${path} must be mode 0600 (got ${mode.toString(8)}). Fix with: chmod 600 "${path}"`,
      );
    }
  }
  const raw = await readFile(path, "utf8");
  const map: Record<string, string> = {};
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq < 0) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if (
      value.length >= 2 &&
      ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'")))
    ) {
      value = value.slice(1, -1);
    }
    if (key) map[key] = value;
  }
  const apiKey = map.KANEO_API_KEY;
  if (!apiKey) {
    throw new Error(`kaneo-mcp: KANEO_API_KEY missing in ${path}`);
  }
  cachedSecret = {
    apiKey,
    endpoint: (map.KANEO_ENDPOINT || DEFAULT_ENDPOINT).replace(/\/+$/, ""),
    agentPrincipalId: map.KANEO_AGENT_PRINCIPAL_ID || undefined,
    hostId: map.KANEO_HOST_ID || undefined,
    gitAllowlistPath: map.KANEO_GIT_ALLOWLIST_PATH || undefined,
    gitGuardPath: map.KANEO_GIT_GUARD_PATH || undefined,
    prGuardPath: map.KANEO_PR_GUARD_PATH || undefined,
  };
  return cachedSecret;
}

export class KaneoApiError extends Error {
  readonly status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "KaneoApiError";
    this.status = status;
  }
}

export interface KaneoApiRequestOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  idempotencyKey?: string;
  leaseToken?: string;
  changeSetId?: string;
  signal?: AbortSignal;
}

/**
 * Call a private REST endpoint without exposing API/lease credentials to argv,
 * task text, or tool output. Execution endpoints are REST-only; MCP is kept
 * for ordinary task/project tools.
 */
export async function callKaneoApi<T>(
  apiPath: string,
  options: KaneoApiRequestOptions = {},
): Promise<T> {
  if (!apiPath.startsWith("/api/") || /[\r\n]/.test(apiPath) || apiPath.includes("://")) {
    throw new Error("kaneo-mcp: REST path must be an internal /api path");
  }
  const secret = await readSecret();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);
  const abort = () => controller.abort();
  if (options.signal?.aborted) controller.abort();
  else options.signal?.addEventListener("abort", abort, { once: true });

  try {
    const headers: Record<string, string> = {
      Accept: "application/json",
      Authorization: `Bearer ${secret.apiKey}`,
    };
    if (secret.agentPrincipalId) {
      headers["X-Kaneo-Agent-Principal"] = secret.agentPrincipalId;
    }
    if (options.body !== undefined) headers["Content-Type"] = "application/json";
    if (options.idempotencyKey) headers["Idempotency-Key"] = options.idempotencyKey;
    if (options.leaseToken) headers["X-Kaneo-Lease-Token"] = options.leaseToken;
    if (options.changeSetId) headers["X-Kaneo-Change-Set"] = options.changeSetId;
    const response = await fetch(`${secret.endpoint}${apiPath}`, {
      method: options.method ?? "GET",
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal,
      redirect: "error",
    });
    const raw = await response.text();
    if (raw.length > 1_048_576) {
      throw new KaneoApiError("kaneo-mcp: REST response exceeded the 1 MiB limit", response.status);
    }
    if (response.status === 401) {
      cachedSession = null;
      cachedSecret = null;
    }
    if (!response.ok) {
      let message = raw.slice(0, 500);
      try {
        const parsed = JSON.parse(raw) as { error?: unknown; message?: unknown };
        if (typeof parsed.error === "string") message = parsed.error;
        else if (typeof parsed.message === "string") message = parsed.message;
      } catch {
        // Keep the bounded response prefix.
      }
      throw new KaneoApiError(`kaneo-mcp: REST HTTP ${response.status}: ${message}`, response.status);
    }
    if (!raw.trim()) return undefined as T;
    try {
      return JSON.parse(raw) as T;
    } catch {
      throw new KaneoApiError("kaneo-mcp: REST response was not valid JSON", response.status);
    }
  } catch (error) {
    if (error instanceof KaneoApiError) throw error;
    if (controller.signal.aborted) {
      throw new Error("kaneo-mcp: REST request timed out or was cancelled");
    }
    throw new Error(`kaneo-mcp: REST request failed: ${error instanceof Error ? error.message : String(error)}`);
  } finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener("abort", abort);
  }
}

export interface KaneoTaskRecord {
  id: string;
  projectId: string;
  title: string;
  description?: string | null;
  status?: string;
  priority?: string;
  [key: string]: unknown;
}

export interface KaneoTaskCommentRecord {
  id: string;
  taskId?: string;
  content?: string;
  [key: string]: unknown;
}

export interface KaneoExecutionManifestRecord {
  id: string;
  projectId: string;
  repositoryOwner: string;
  repositoryName: string;
  baseBranch: string;
  docs: string[];
  verificationProfile: string;
  allowedAgentIds: string[];
  policy: Record<string, unknown>;
  manifestVersion: number;
  protocolVersion: number;
  [key: string]: unknown;
}

export interface KaneoTaskRelationRecord {
  id: string;
  sourceTaskId: string;
  targetTaskId: string;
  relationType: string;
  sourceTask?: Record<string, unknown> | null;
  targetTask?: Record<string, unknown> | null;
  [key: string]: unknown;
}

export interface KaneoAgentPrincipalRecord {
  id: string;
  userId: string;
  runtimeId: string;
  hostId: string;
  scopes: string[];
  isActive: boolean;
  [key: string]: unknown;
}

export interface KaneoTaskRunEvidenceRecord {
  id: string;
  runId: string;
  agentPrincipalId?: string | null;
  kind: string;
  payload: Record<string, unknown>;
  createdAt: string;
  [key: string]: unknown;
}

export interface KaneoTaskRunRecord {
  id: string;
  taskId: string;
  manifestId: string;
  manifestVersion: number;
  protocolVersion: number;
  repositoryOwner: string;
  repositoryName: string;
  baseBranch: string;
  state: string;
  role: string;
  agentPrincipalId: string;
  hostId: string;
  branchName: string;
  scope: string[];
  baseSha?: string | null;
  commitSha?: string | null;
  prNumber?: number | null;
  prUrl?: string | null;
  prState?: string | null;
  evidence?: Record<string, unknown> | null;
  blocker?: string | null;
  nextAction?: string | null;
  leaseEpoch: number;
  leaseActive: boolean;
  leaseExpiresAt?: string | null;
  lastHeartbeatAt?: string | null;
  leaseToken?: string;
  [key: string]: unknown;
}

export async function getKaneoTask(taskId: string, signal?: AbortSignal): Promise<KaneoTaskRecord> {
  return callKaneoApi<KaneoTaskRecord>(`/api/task/${encodeURIComponent(taskId)}`, { signal });
}

export async function listTaskComments(
  taskId: string,
  signal?: AbortSignal,
): Promise<KaneoTaskCommentRecord[]> {
  return callKaneoApi<KaneoTaskCommentRecord[]>(
    `/api/comment/${encodeURIComponent(taskId)}`,
    { signal },
  );
}

export async function createTaskComment(
  taskId: string,
  content: string,
  requestKey?: string,
  signal?: AbortSignal,
): Promise<KaneoTaskCommentRecord> {
  return callKaneoApi<KaneoTaskCommentRecord>(
    `/api/comment/${encodeURIComponent(taskId)}`,
    {
      method: "POST",
      body: { content },
      idempotencyKey: requestKey,
      signal,
    },
  );
}

export async function getExecutionManifest(
  projectId: string,
  signal?: AbortSignal,
): Promise<KaneoExecutionManifestRecord> {
  return callKaneoApi<KaneoExecutionManifestRecord>(
    `/api/execution/project/${encodeURIComponent(projectId)}/manifest`,
    { signal },
  );
}

export async function listExecutionAgents(
  projectId: string,
  signal?: AbortSignal,
): Promise<KaneoAgentPrincipalRecord[]> {
  return callKaneoApi<KaneoAgentPrincipalRecord[]>(
    `/api/execution/project/${encodeURIComponent(projectId)}/agents`,
    { signal },
  );
}

export async function listTaskRuns(taskId: string, signal?: AbortSignal): Promise<KaneoTaskRunRecord[]> {
  return callKaneoApi<KaneoTaskRunRecord[]>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs`,
    { signal },
  );
}

export async function getTaskRun(
  taskId: string,
  runId: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}`,
    { signal },
  );
}

export async function listTaskRunEvidence(
  taskId: string,
  runId: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunEvidenceRecord[]> {
  return callKaneoApi<KaneoTaskRunEvidenceRecord[]>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/evidence`,
    { signal },
  );
}

export async function getTaskRelations(
  taskId: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRelationRecord[]> {
  return callKaneoApi<KaneoTaskRelationRecord[]>(
    `/api/task-relation/${encodeURIComponent(taskId)}`,
    { signal },
  );
}

export async function claimTaskRun(
  taskId: string,
  agentPrincipalId: string,
  scope: string[],
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/claim`,
    {
      method: "POST",
      body: { agentPrincipalId, scope },
      idempotencyKey: requestKey,
      signal,
    },
  );
}

/** SPEC-kaneo-native-telegram-control-v0-1 (T2): parent-only schedule
 * creation. The request body is produced by confirmSchedulePlan after the
 * parent confirms the preview; idempotencyKey derives from the plan hash. */
export async function updateExecutionSchedule(
  scheduleId: string,
  body: Record<string, unknown>,
  signal?: AbortSignal,
): Promise<{ id: string; scheduleRevision: number }> {
  return callKaneoApi<{ id: string; scheduleRevision: number }>(
    `/api/execution/schedules/${encodeURIComponent(scheduleId)}`,
    { method: "PATCH", body, signal },
  );
}

export async function cancelExecutionSchedule(
  scheduleId: string,
  body: Record<string, unknown>,
  signal?: AbortSignal,
): Promise<{ id: string; scheduleRevision: number }> {
  return callKaneoApi<{ id: string; scheduleRevision: number }>(
    `/api/execution/schedules/${encodeURIComponent(scheduleId)}/cancel`,
    { method: "POST", body, signal },
  );
}

export async function resumeRunAttempt(
  taskId: string,
  runId: string,
  body: Record<string, unknown>,
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/resume`,
    { method: "POST", body, idempotencyKey: requestKey, signal },
  );
}

// ---------------------------------------------------------------------------
// FULL-run graph + phase protocol client
// (SPEC-kaneo-phase-cards-full-run-v0-4 / runtime v0-1)
// ---------------------------------------------------------------------------

export interface FullRunPhaseDescriptor {
  phaseId: string;
  parserTaskId: string;
  ordinal: number;
  required: boolean;
  title: string;
  description: string;
  files: string[];
  verify: string[];
}

export interface FullRunGraphPublishBody {
  planHash: string;
  expectedProjectRevision: number;
  changeSetId: string;
  specId: string;
  specSha256: string;
  sourcePhaseMapSha256: string;
  baseBranch: string;
  full: {
    title: string;
    description: string;
    scope: string[];
    verify: string[];
    taskExecutionState: "published";
  };
  phases: FullRunPhaseDescriptor[];
}

export interface FullRunGraphReceipt {
  schemaVersion: number | string;
  graphId: string;
  projectId: string;
  projectRevision: number;
  fullTaskId: string;
  phaseCards: Array<{
    phaseId: string;
    parserTaskId: string;
    childTaskId: string;
    ordinal: number;
    required: boolean;
  }>;
  sourcePhaseMapSha256: string;
  graphMapSha256: string;
  specSha256: string;
  changeSetId: string;
  planHash: string;
  taskRevision: number;
  receiptSha256: string;
  [key: string]: unknown;
}

export interface PhaseProgressSnapshot {
  taskId?: string;
  runId?: string;
  executionMode?: string;
  phaseMapVersion?: number;
  specSha256?: string;
  sourcePhaseMapSha256?: string;
  graphId?: string;
  phases?: Array<{
    phaseId?: string;
    ordinal?: number;
    required?: boolean;
    title?: string;
    status?: string;
    checkpointId?: string | null;
    childTaskId?: string | null;
    [key: string]: unknown;
  }>;
  ledger?: Array<Record<string, unknown>>;
  projection?: Record<string, unknown>;
  [key: string]: unknown;
}

export interface PhaseCheckpointRecord {
  checkpointId: string;
  runId?: string;
  phaseId?: string;
  commitSha?: string;
  headSha?: string;
  baseSha?: string;
  receiptHash?: string;
  [key: string]: unknown;
}

/** Legacy worker-contract JSON (schema:1) first, phase map JSON block after —
 * exact order required by the server graph transaction. */
export function buildFullRunDescription(
  contract: Record<string, unknown>,
  phaseMap: Record<string, unknown>,
): string {
  return `${JSON.stringify(contract)}\n${JSON.stringify(phaseMap, null, 2)}`;
}

/** Parent graph publish: ONE server operation. No generic create-task
 * fallback; response-loss reconciles via graphId or by-request reads. */
export async function publishFullRunGraph(
  projectId: string,
  body: FullRunGraphPublishBody,
  idempotencyKey: string,
  signal?: AbortSignal,
): Promise<FullRunGraphReceipt> {
  return callKaneoApi<FullRunGraphReceipt>(
    `/api/execution/project/${encodeURIComponent(projectId)}/full-run-graphs`,
    {
      method: "POST",
      body,
      idempotencyKey,
      changeSetId: body.changeSetId,
      signal,
    },
  );
}

export async function getFullRunGraph(
  projectId: string,
  graphId: string,
  signal?: AbortSignal,
): Promise<FullRunGraphReceipt> {
  return callKaneoApi<FullRunGraphReceipt>(
    `/api/execution/project/${encodeURIComponent(projectId)}/full-run-graphs/${encodeURIComponent(graphId)}`,
    { signal },
  );
}

/** Response-loss reconcile: requestKey is the original Idempotency-Key of the
 * POST graph publish, URL-encoded server-side mapping requestKey → receipt. */
export async function getFullRunGraphByRequest(
  projectId: string,
  requestKey: string,
  signal?: AbortSignal,
): Promise<FullRunGraphReceipt> {
  return callKaneoApi<FullRunGraphReceipt>(
    `/api/execution/project/${encodeURIComponent(projectId)}/full-run-graphs/by-request?requestKey=${encodeURIComponent(requestKey)}`,
    { signal },
  );
}

/** Parent ready-CAS: only a pass moves FULL from published to ready. */
export async function readyFullRunGraph(
  projectId: string,
  graphId: string,
  body: {
    planHash: string;
    expectedProjectRevision: number;
    expectedTaskRevision: number;
  },
  idempotencyKey: string,
  signal?: AbortSignal,
): Promise<FullRunGraphReceipt> {
  return callKaneoApi<FullRunGraphReceipt>(
    `/api/execution/project/${encodeURIComponent(projectId)}/full-run-graphs/${encodeURIComponent(graphId)}/ready`,
    { method: "POST", body, idempotencyKey, signal },
  );
}

export async function getPhaseProgress(
  taskId: string,
  runId: string,
  signal?: AbortSignal,
): Promise<PhaseProgressSnapshot> {
  return callKaneoApi<PhaseProgressSnapshot>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/phase-progress`,
    { signal },
  );
}

export async function postPhaseProgress(
  taskId: string,
  runId: string,
  leaseEpoch: number,
  leaseToken: string,
  body: Record<string, unknown>,
  requestKey: string,
  signal?: AbortSignal,
): Promise<PhaseProgressSnapshot> {
  return callKaneoApi<PhaseProgressSnapshot>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/phase-progress`,
    {
      method: "POST",
      body: { ...body, leaseEpoch },
      idempotencyKey: requestKey,
      leaseToken,
      signal,
    },
  );
}

/** Dedicated fenced phase checkpoint route; the generic /checkpoints route is
 * rejected by the server on FULL mapped runs. Runtime adds token/epoch and
 * spec/source-map hashes; response and stored replay carry checkpointId. */
export async function createPhaseCheckpoint(
  taskId: string,
  runId: string,
  leaseEpoch: number,
  leaseToken: string,
  body: Record<string, unknown>,
  requestKey: string,
  signal?: AbortSignal,
): Promise<PhaseCheckpointRecord> {
  return callKaneoApi<PhaseCheckpointRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/phase-checkpoints`,
    {
      method: "POST",
      body: { ...body, leaseEpoch },
      idempotencyKey: requestKey,
      leaseToken,
      signal,
    },
  );
}

/** SPEC #15 chain pause/re-kick. The pause flag is a global kill-switch; the
 * resume sweep is project-scoped. */
export async function setChainPaused(
  paused: boolean,
  signal?: AbortSignal,
): Promise<{ name: string; enabled: boolean }> {
  return callKaneoApi<{ name: string; enabled: boolean }>(
    `/api/execution/flags/chain_paused`,
    { method: "PUT", body: { enabled: paused }, signal },
  );
}

export async function getChainPaused(
  signal?: AbortSignal,
): Promise<boolean> {
  const flags = await callKaneoApi<
    Array<{ name: string; enabled: boolean }>
  >(`/api/execution/flags`, { signal });
  const flag = Array.isArray(flags)
    ? flags.find((entry) => entry.name === "chain_paused")
    : undefined;
  return flag?.enabled === true;
}

export async function resumeChainSchedules(
  projectId: string,
  signal?: AbortSignal,
): Promise<{ scheduledTaskIds: string[] }> {
  return callKaneoApi<{ scheduledTaskIds: string[] }>(
    `/api/execution/project/${encodeURIComponent(projectId)}/chain/resume`,
    { method: "POST", body: {}, signal },
  );
}

export async function createExecutionSchedule(
  taskId: string,
  body: Record<string, unknown>,
  idempotencyKey: string,
  signal?: AbortSignal,
): Promise<{ id: string }> {
  return callKaneoApi<{ id: string }>(
    `/api/execution/task/${encodeURIComponent(taskId)}/schedules`,
    {
      method: "POST",
      body,
      idempotencyKey,
      signal,
    },
  );
}

export async function heartbeatTaskRun(
  taskId: string,
  runId: string,
  leaseEpoch: number,
  leaseToken: string,
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/heartbeat`,
    {
      method: "POST",
      body: { leaseEpoch },
      idempotencyKey: requestKey,
      leaseToken,
      signal,
    },
  );
}

export async function reportTaskRun(
  taskId: string,
  runId: string,
  leaseEpoch: number,
  leaseToken: string,
  input: Record<string, unknown>,
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/report`,
    {
      method: "POST",
      body: { ...input, leaseEpoch },
      idempotencyKey: requestKey,
      leaseToken,
      signal,
    },
  );
}

export async function createTaskRunCheckpoint(
  taskId: string,
  runId: string,
  leaseEpoch: number,
  leaseToken: string,
  input: Record<string, unknown>,
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/checkpoints`,
    {
      method: "POST",
      body: { ...input, leaseEpoch },
      idempotencyKey: requestKey,
      leaseToken,
      signal,
    },
  );
}

export async function releaseTaskRun(
  taskId: string,
  runId: string,
  leaseEpoch: number,
  leaseToken: string,
  state: string | undefined,
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/release`,
    {
      method: "POST",
      body: state ? { leaseEpoch, state } : { leaseEpoch },
      idempotencyKey: requestKey,
      leaseToken,
      signal,
    },
  );
}

export async function reviewTaskRun(
  taskId: string,
  runId: string,
  input: {
    decision: "approve" | "reject";
    action?: "none" | "create_pr" | "merge";
    reason?: string;
    verification?: Record<string, unknown>;
    prResult?: Record<string, unknown>;
    reviewHeadSha?: string;
  },
  requestKey: string,
  signal?: AbortSignal,
): Promise<KaneoTaskRunRecord> {
  return callKaneoApi<KaneoTaskRunRecord>(
    `/api/execution/task/${encodeURIComponent(taskId)}/runs/${encodeURIComponent(runId)}/review`,
    {
      method: "POST",
      body: input,
      idempotencyKey: requestKey,
      signal,
    },
  );
}

function parsePayload(raw: string): unknown {
  const text = raw.trim();
  if (text.startsWith("{") || text.startsWith("[")) {
    try {
      return JSON.parse(text);
    } catch {
      /* fall through to SSE */
    }
  }
  for (const line of text.split(/\r?\n/)) {
    if (line.startsWith("data:")) {
      try {
        return JSON.parse(line.slice(5).trim());
      } catch {
        /* keep scanning */
      }
    }
  }
  throw new Error(`kaneo-mcp: MCP response unparseable (len=${text.length}): ${text.slice(0, 300)}`);
}

async function rpc(
  endpoint: string,
  apiKey: string,
  body: Record<string, unknown>,
  sessionId?: string,
): Promise<{ payload: unknown; sessionId: string | null }> {
  const args = [
    "-sS", "-i", "-X", "POST",
    "-H", "Content-Type: application/json",
    "-H", "Accept: application/json, text/event-stream",
    "--max-time", "30",
  ];
  if (sessionId) args.push("-H", `mcp-session-id: ${sessionId}`);
  args.push(`${endpoint}/api/mcp`, "-d", JSON.stringify(body));

  let stdout: string;
  try {
    const result = await execCurlWithSecret(args, apiKey, 16 * 1024 * 1024);
    stdout = result.stdout;
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    throw new Error(`kaneo-mcp: curl failed reaching ${endpoint} (${message})`);
  }

  // Split headers / body at the first blank line (CRLF or LF).
  const crlfIdx = stdout.indexOf("\r\n\r\n");
  const lfIdx = stdout.indexOf("\n\n");
  let headerBlock: string;
  let text: string;
  if (crlfIdx >= 0 && (lfIdx < 0 || crlfIdx < lfIdx)) {
    headerBlock = stdout.slice(0, crlfIdx);
    text = stdout.slice(crlfIdx + 4);
  } else if (lfIdx >= 0) {
    headerBlock = stdout.slice(0, lfIdx);
    text = stdout.slice(lfIdx + 2);
  } else {
    throw new Error(`kaneo-mcp: curl response has no header/body separator (len=${stdout.length}): ${stdout.slice(0, 300)}`);
  }

  const statusMatch = headerBlock.match(/^HTTP\/[\d.]+ (\d+)/m);
  const status = statusMatch ? Number.parseInt(statusMatch[1], 10) : 0;
  const sessionMatch = headerBlock.match(/^mcp-session-id:\s*(.+)$/im);
  const nextSessionId = sessionMatch ? sessionMatch[1].trim() : sessionId || null;
  if (status === 401) {
    cachedSession = null;
    cachedSecret = null;
    throw new Error(`kaneo-mcp: 401 unauthorized — check KANEO_API_KEY in ${secretPath()}`);
  }
  if (status === 403) {
    throw new Error(`kaneo-mcp: 403 forbidden — API key lacks access to this workspace or operation`);
  }
  // 202/204 are MCP notification acks (no body). Only 200 carries a JSON-RPC payload.
  if (status !== 200) {
    if (status === 202 || status === 204) {
      return { payload: null, sessionId: nextSessionId };
    }
    throw new Error(`kaneo-mcp: HTTP ${status} from ${endpoint}/api/mcp: ${text.slice(0, 500)}`);
  }

  const payload = parsePayload(text);
  return { payload, sessionId: nextSessionId };
}

async function ensureSession(secret: SecretConfig): Promise<CachedSession> {
  if (cachedSession && cachedSession.endpoint === secret.endpoint && cachedSession.apiKey === secret.apiKey) {
    return cachedSession;
  }
  const { payload, sessionId } = await rpc(secret.endpoint, secret.apiKey, {
    jsonrpc: "2.0",
    id: nextRequestId++,
    method: "initialize",
    params: {
      protocolVersion: MCP_PROTOCOL_VERSION,
      capabilities: {},
      clientInfo: { name: CLIENT_NAME, version: CLIENT_VERSION },
    },
  });
  if (!sessionId) {
    throw new Error("kaneo-mcp: initialize response missing mcp-session-id header");
  }
  const init = payload as { error?: { message?: string } };
  if (init?.error?.message) {
    throw new Error(`kaneo-mcp: initialize error — ${init.error.message}`);
  }
  // Acknowledge the session before any tools/call (MCP handshake requirement).
  await rpc(secret.endpoint, secret.apiKey, {
    jsonrpc: "2.0",
    method: "notifications/initialized",
  }, sessionId);
  cachedSession = { endpoint: secret.endpoint, apiKey: secret.apiKey, sessionId };
  return cachedSession;
}

// Call one Kaneo MCP tool by name. The session is lazily initialized and
// reused for the lifetime of the Pi process; a 401 resets it so the next call
// re-reads the secret file and re-initializes. An API restart invalidates the
// cached session (404 "Session not found"); we clear the cache and retry once
// with a fresh initialize instead of surfacing a stale-session error.
export async function callKaneoTool(toolName: string, args: Record<string, unknown>): Promise<unknown> {
  const secret = await readSecret();
  for (let attempt = 0; attempt < 2; attempt++) {
    const session = await ensureSession(secret);
    try {
      const { payload } = await rpc(
        secret.endpoint,
        secret.apiKey,
        {
          jsonrpc: "2.0",
          id: nextRequestId++,
          method: "tools/call",
          params: { name: toolName, arguments: args },
        },
        session.sessionId,
      );
      return unwrapToolResult(toolName, payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      // API restart kills the server-side session; clear cache and retry once.
      if (attempt === 0 && message.includes("HTTP 404") && message.includes("Session not found")) {
        cachedSession = null;
        continue;
      }
      throw error;
    }
  }
  throw new Error(`kaneo-mcp: ${toolName} exhausted session retry`);
}

function unwrapToolResult(toolName: string, payload: unknown): unknown {
  const result = payload as McpToolResult;
  if (result?.error) {
    throw new Error(`kaneo-mcp: ${toolName} RPC error ${result.error.code} — ${result.error.message}`);
  }
  const inner = result?.result;
  if (!inner) {
    throw new Error(`kaneo-mcp: ${toolName} returned no result object`);
  }
  if (inner.isError) {
    const text = (inner.content || []).map((c) => c.text || "").join("\n");
    throw new Error(`kaneo-mcp: ${toolName} tool error — ${text || "no message"}`);
  }
  // Unwrap the text content block: Kaneo MCP returns [{type:"text", text: "<json>"}].
  const block = (inner.content || []).find((c) => c.type === "text" && typeof c.text === "string");
  if (!block?.text) {
    return inner;
  }
  try {
    return JSON.parse(block.text);
  } catch {
    return block.text;
  }
}
